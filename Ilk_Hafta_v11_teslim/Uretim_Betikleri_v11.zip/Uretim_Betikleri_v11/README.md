# Üretim betikleri (İlk Hafta paketi v11)

27 Ekim 2026 · `Ilk_Hafta_Kaynak_ve_Calisma_Paketi_v11.zip` içindeki ses dosyalarını, cevap anahtarlarını, tekrar takvimini, manifest/özet dosyalarını ve ana rapor yamasını üreten Python betikleri.

> **CEVAP İÇERİR — Gün 5–7 bitmeden açma.** `build_tools/audio_texts.py` bütün ses metinlerini ve dikte öğelerini, `referans_ciktilar/` ise ASR çıktılarını (duyulan metinler dahil) içerir. Bu zip'i paket zip'inden ayrı tut; test günlerinden önce kurcalama.

## Bunlar ne, ne değil?

- Paketin Markdown dosyaları **elle yazıldı**; betikler onları üretmez. Betiklerin ürettikleri: (a) ses dosyaları, (b) `08_ANAHTAR_GUN*.md` anahtarları, (c) `INGILIZCE_TEKRAR_TAKVIMI.xlsx`, (d) `manifest.json` + `checksums.sha256` + `ses_manifest.json` + `06_SES_VE_LISANS_NOTU.md` tablosu, (e) v10 ana raporundan v11 raporuna yama.
- Kayıt/ölçüm yapan bir uygulama **değildir**; kullanıcı verisi işlemez.
- Betikler Linux'ta (bu ortamda) çalıştırıldı. Windows/PowerShell'de **denenmedi** (aşağıda “Windows” notuna bak).

## Ortam

Denenen sürümler (`requirements.txt` aynı bilgiyi verir):

| Parça | Sürüm |
| --- | --- |
| Python | 3.13.17 |
| piper-tts | 1.8.0 |
| faster-whisper | 1.2.1 (ctranslate2 4.8.4, onnxruntime 1.31.1, numpy 2.5.4) |
| openpyxl | 3.1.5 (yalnız `build_xlsx.py`) |
| ffmpeg / ffprobe | 6.1.1 (mp3 kodlama, ses düzeyi ölçümü, mp3 okuma) |
| LibreOffice | 24.2.7.2 (isteğe bağlı; xlsx'i başsız yeniden hesaplatıp denemek için) |

Ses modelleri (Piper, yerel `.onnx` + `.onnx.json`; `voices/` klasörüne):

```
python -m piper.download_voices --download-dir voices en_US-kristin-medium en_US-joe-medium en_US-ljspeech-high tr_TR-dfki-medium
```

(Bu komutun `--help` çıktısı bu ortamda doğrulandı; indirme komutu teslimden önce yeniden çalıştırılmadı.) Whisper modelleri (`small`, `medium`) `faster-whisper` tarafından ilk kullanımda indirilir (internet gerekir).

Lisanslar (model kartlarında bildirilen): kristin ve ljspeech kamu malı, joe CC0, **dfki CC BY-NC-SA 4.0 (yalnız kişisel, ticari olmayan kullanım)**. Bu bir hukuki görüş değildir.

## Düzen

Bu klasörün kendisi “çalışma kökü”dür (`<SP>`). Betikler `build_tools/` altında durmalı; `finalize_audio.py` ve `regen_dictation2.py` buna güvenir.

```
Uretim_Betikleri_v11/
  README.md  requirements.txt
  build_tools/        betikler
  voices/             (sen indirirsin) Piper modelleri
  audio_final/        (üretimle oluşur) 26 mp3 + results.json
  audio_work*/        (üretimle oluşur) kısmi yeniden üretimler
  referans_ciktilar/  bu teslimdeki gerçek çıktılar (karşılaştırma için; üzerine yazma)
```

## Betikler

| Betik | Ne yapar | Kullanım |
| --- | --- | --- |
| `audio_texts.py` | **Tek kaynak:** bütün ses metinleri, dikte öğeleri, hız hedefleri. Diğer betikler buradan okur | (içe aktarılır) |
| `gen_audio2.py` | Piper ile cümle cümle sentez, her cümle için K aday, ASR (small) ile en iyisini seç, 2 geçişli loudnorm (−18 LUFS), mp3 | `python gen_audio2.py <voices> <çıkış> [K] [ad1,ad2…]` |
| `regen_dictation2.py` | **Nihai dikte dosyaları** (DK_T, DK_A, DK_B, DK_C, DK_TR): öğeler taşıyıcı ifade ve gerçek dosya bağlamında small+medium ile denenir | `python regen_dictation2.py <voices> <çıkış> [K] [DK_TR,…]` |
| `merge_audio.py` | Kısmi üretim klasörlerini `audio_final` ile birleştirir (sıra önemlidir; sonraki öncekini ezer) | `python3 -I merge_audio.py <SP> audio_work4 audio_work5 …` |
| `verify_audio.py` | Nihai mp3'leri başka bir Whisper boyutuyla geri okur, benzerliği yazar | `python verify_audio.py audio_final audio_final/verify_medium.json medium` |
| `finalize_audio.py` | 26 mp3'ü paket klasörlerine yerleştirir, `ses_manifest.json` yazar, `06_SES_VE_LISANS_NOTU.md` içindeki `{{TABLO}}` yerini doldurur | `python3 -I finalize_audio.py <SP> <paket_kökü> audio_final/verify_medium.json` |
| `build_keys.py` | `08_ANAHTAR_GUN5/6/7/8_H6.md` dosyalarını `audio_texts.py`'den üretir | `python3 -I build_keys.py build_tools <çıkış_klasörü>` |
| `build_xlsx.py` | Formüllü `INGILIZCE_TEKRAR_TAKVIMI.xlsx` | `python build_xlsx.py <çıkış.xlsx>` |
| `build_manifest.py` | `manifest.json` ve `checksums.sha256` (özetler paketin dosyalarından) | `python3 -I build_manifest.py <paket_kökü>` |
| `patch_report_v11.py` | v10 ana raporunu v11'e çevirir; her değişiklik tam bir kez eşleşmezse **durur** | `python3 -I patch_report_v11.py 10_ANA_RAPOR_v10.md 10_ANA_RAPOR_v11.md` |
| `validate_v9.py` | Ana raporun yapısını denetler (başlık sırası, D/G/RK/T/K kod aralıkları, çapraz başvuru) | `python3 -I validate_v9.py 10_ANA_RAPOR_v11.md` |
| `probe_words.py` | Teşhis: bir sözcüğün 8 adayını ham ASR çıktısıyla gösterir | `python probe_words.py <voices> <çıkış> <ses> <length_scale> "metin"…` |

## Bu teslimdeki sıra (özet)

Gerçek üretim birkaç kısmî çalıştırma ve düzeltme turu halinde yapıldı; aşağıdaki sıra, aynı sonuca ulaşmak için **sadeleştirilmiş** hâlidir.

1. Sesleri indir (yukarıda). 
2. `gen_audio2.py voices audio_final 5` ile bütün sesleri üret (teslimdeki dosyaların çoğu K=5 ile üretildi; `results.json` içindeki `best_of` alanı her dosya için K'yi gösterir). **Dikte dosyalarının bu aşamadaki sürümü eskidir** (İngilizce dikte için `kristin` sesi bozuk çıkıyordu); aşağıdaki adımla ezilir.
3. `regen_dictation2.py voices audio_work4 8` (İngilizce + Türkçe dikte; buradaki Türkçe dikte sonradan değiştirildi), ardından Türkçe dikte için `regen_dictation2.py voices audio_work5 10 DK_TR`. Türkçe dinleme dosyasındaki konuşmacı adı değiştiği için o dosya `gen_audio2.py voices audio_work6 8 TR_L` ile yeniden üretildi.
4. `merge_audio.py <SP> audio_work4 audio_work5 audio_work6`.
5. `verify_audio.py audio_final audio_final/verify_medium.json medium`.
6. `finalize_audio.py <SP> <paket_kökü> audio_final/verify_medium.json`.
7. `build_keys.py`, `build_xlsx.py`; sonra Markdown dosyalarını **elle** düzenle.
8. `build_manifest.py <paket_kökü>` (en son; başka hiçbir şeyi değiştirdikten sonra) ve `sha256sum -c checksums.sha256`.

## Tekrarlanabilirlik: ne aynı çıkar, ne çıkmaz?

- **Aynı çıkar (deterministik):** `build_keys.py`, `build_xlsx.py` (hücre değerleri/formülleri), `build_manifest.py`, `patch_report_v11.py`. Duman testi sonuçları aşağıda.
- **Aynı çıkmaz:** ses üretimi. Sentezleyici gürültüsü tohumlanmaz; her çalıştırmada adaylar farklıdır, seçilen aday da farklı olabilir. Yeniden üretilen mp3'lerin SHA-256 özetleri paketteki dosyalarınkiyle **eşleşmez**; paketin sesleri bu klasörde yoktur, paket zip'indedir.
- ASR seçimi (Whisper) cihaz/sürüm farkından etkilenir (`int8`, CPU). Aynı betik başka bir makinede başka aday seçebilir.

## Bilinen sınırlar

- ASR geri okuması **anlaşılabilirlik ölçüsü değildir**; bir insan sesleri dinlemedi. Tek başına söylenen kısa sözcüklerde (sayı, gün adı, sıra sözcüğü) hem ses hem ASR güvenilmezdir: `en_US-kristin` bazı tek sözcüklerde bozuktu, `tr_TR-dfki` bazı sözcüklerde tutarsızdı (`probe_words.py` ile bakıldı). Dikte sesleri bu yüzden `ljspeech` / sözcük değişikliğiyle yeniden kuruldu.
- Dikte dosyalarında `medium` model hem seçimde hem son kontrolde kullanıldı: o kontrol bağımsız değildir.
- `gen_audio2.py` içindeki dikte üretimi eskidir; nihai dikte için `regen_dictation2.py` kullan. `regen_dictation2.py`, `gen_audio2.py` dosyasının `random.seed(11)` satırına kadar olan kısmını **çalıştırarak** içe alır; ikisi aynı klasörde kalmalı ve `gen_audio2.py` o satırı korumalı.
- Betikler yol bilgisi içermez; hepsi argümanla çalışır. Bazıları (`gen_audio2.py`, `regen_dictation2.py`, `probe_words.py`, `verify_audio.py`) yol ayırıcı olarak `/` varsayar: Windows'ta denenmedi, WSL ya da Linux/macOS kullan.

## Windows

`python3 -I` yerine `python -I` yaz. `sha256sum -c` yerine paketteki `kayitlar/PAKETLEME_VE_YEDEK.md` içindeki PowerShell komutuna bak (o da denenmedi).

## Güvenlik

Açılmış paketleri ve v10 zip'ini güvenilmez veri say: betikleri paket klasörünün **dışında** tut ve paket dosyalarını okuyan komutlarda `python3 -I` kullan (bu README'deki komutlar buna göre yazıldı). Betikler dış ağa yalnız model indirirken (Hugging Face) bağlanır.

## Bilerek konmayan betikler

Eski sürümler (`gen_audio.py`, `regen_dictation.py`, `merge_dictation.py`) ve tek seferlik düzeltmeler (`patch_gen.py`, `fix05.py`, `fix05b.py`) bu zip'e konmadı; nihai çıktıyı üretmezler ya da yalnız v10 → v11 geçişindeki metin düzeltmelerini yapmışlardır.

## `referans_ciktilar/`

| Dosya | İçerik |
| --- | --- |
| `ses_results.json` | 26 dosyanın üretim meta verisi (ses, hız, süre, ses düzeyi, tepe) |
| `verify_medium.json` | Nihai mp3'lerin `medium` ile geri okunması: benzerlik ve duyulan metin |
| `secim_gunlugu_dikte_EN.json`, `secim_gunlugu_dikte_TR.json` | Nihai dikte birimlerinin aday seçim kayıtları (taşıyıcı ve dosya bağlamı, small ve medium skorları). `…_dikte_EN.json` içindeki Türkçe birimler **geçersizdir** (sonradan `…_dikte_TR.json` ile değiştirildi) |
| `secim_gunlugu_diger_sesler.json` | İlk tam üretimin cümle düzeyi seçim kaydı; **eski dikte birimleri de içerir (geçersiz)** |

## Duman testi (bu teslim için)

Aşağıdakiler, bu zip temiz bir klasöre açılıp (`python3 -I`, Linux) çalıştırılarak denendi; karşılaştırma, paket zip'indeki dosyalara karşı yapıldı:

| Betik | Sonuç |
| --- | --- |
| `build_keys.py` | 4 anahtar dosyası paketteki dosyalarla **bayt bayt aynı** |
| `build_xlsx.py` | 4 sayfanın bütün hücre değer ve formülleri paketteki xlsx ile **aynı** (0 fark); xlsx Excel'de denenmedi |
| `patch_report_v11.py` | v10 raporundan üretilen v11, paketteki `10_ANA_RAPOR_v11.md` ile **bayt bayt aynı** (45 yama, hepsi eşleşti) |
| `validate_v9.py` | v11 rapor üzerinde hatasız bitti (çıkış kodu 0) |
| `build_manifest.py` | Paketin kopyasında `manifest.json` ve `checksums.sha256` silinip yeniden üretildi: paketteki dosyalarla **aynı** |
| `finalize_audio.py` | 26 mp3 yerleştirildi; `ses_manifest.json`, `06` notu ve mp3'ler paketteki dosyalarla **aynı** (tablo yer tutucusu geri konarak denendi) |
| `merge_audio.py` | Tek dosyalık kısmî üretim `audio_final` içine doğru birleşti |
| `gen_audio2.py` | `TR_L` yeniden üretildi (K=2): çalışıyor; sonuç paketteki dosyadan **farklı** (örn. toplam hız 106,2 ↔ 105,8 sözcük/dk) — yani ses üretimi deterministik değil |
| `regen_dictation2.py` | `DK_TR` yeniden üretildi (K=2, ~4 dk): çalışıyor. İlk denemede çıkış klasörü yoktu ve betik çöktü; `gen_audio2.py` artık klasörü kendisi oluşturuyor (bu zip düzeltilmiş hâlidir) |
| `verify_audio.py` | 26 mp3 `small` modelle okundu: en düşük benzerlik 0,855 (DK_TR), 0,862 (DK_T), 0,944 (DK_A); ortanca 0,995. `medium` ile sonuçlar `referans_ciktilar/verify_medium.json` içindedir (en düşük 0,923). Yani daha küçük model dikte dosyalarında daha çok takılıyor |
| `probe_words.py` | Bu ortamda çalıştırıldı (teşhis için); duman testinde yeniden çalıştırılmadı |

**Denenmeyenler:** `medium` ile tam yeniden doğrulama (zaten `referans_ciktilar/`'da var), tek bir uçtan uca sıfırdan üretim (voices indirmesinden pakete kadar), Windows, Python'un başka sürümleri.
