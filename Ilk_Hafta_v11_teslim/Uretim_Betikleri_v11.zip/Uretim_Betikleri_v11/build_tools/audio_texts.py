# Tek kaynak: ses metinleri. Hem ses üretimi hem Markdown doğrulaması buradan okur.
# Bu dosya paketin içinde DEĞİL; yalnız yapım aracıdır.

EN = {
    "EN-A": ("Maya", "kristin",
        "Hi, this is Maya. Our study group meets at the library on Tuesday. Please bring a notebook and a blue pen. "
        "The meeting starts at four, but I will arrive a little earlier. We planned to use the room near the stairs. "
        "That room is not available, so please wait for me at the front door. We can walk to the new room together."),
    "EN-B": ("Daniel", "joe",
        "Hello, this is Daniel. The science club has an activity at the school on Friday. Please bring a pencil and a bottle of water. "
        "We will begin at three. I want to get there before the activity starts. Our usual classroom is busy today. "
        "Please meet me next to the main gate. I will show you where the new classroom is."),
    "EN-C": ("Emma", "ljspeech",
        "Hi, this is Emma. I am going to the sports center on Wednesday. You can join me if you want. "
        "Bring comfortable shoes and a small towel. The class begins at five, so I plan to arrive early. "
        "The side entrance is closed this week. Please use the door beside the bus stop. "
        "I will wait inside and help you find our group."),
}

# hedef kelime/dakika: dosya adı eki -> (hedef wpm, cümle arası duraklama sn)
SPEEDS = {"yavas": (90, 1.10), "normal": (120, 0.70), "hizli": (150, 0.45)}

TR = {
    "TR-L": (
        "Merhaba, ben Burak. Perşembe günü kütüphanedeki çalışma grubuna gidiyorum. Yanına defterini ve siyah bir kalem al. "
        "Buluşma dörtte başlayacak. Merdivene yakın oda dolu olduğu için başka bir odada olacağız. "
        "Kapıda beni bekle; yeni odaya birlikte geçelim."),
    "C-A": (
        "Bir okul kulübü küçük bir sergi hazırlıyor. Fotoğraflar girişteki masaya, çizimler pencere yanındaki panoya konacak. "
        "Sergiden önce masadaki eski kağıtlar kaldırılacak. Kulüp üyeleri önce salonu düzenleyip sonra konukları karşılayacak."),
    "C-B": (
        "Bir arkadaş grubu kitap değişim günü hazırlıyor. Romanlar kapıya yakın masaya, dergiler köşedeki rafa konacak. "
        "Etkinlikten önce rafın üzerindeki kutular kaldırılacak. Grup önce kitapları yerleştirip sonra gelen kişileri karşılayacak."),
    "C-C": (
        "Bir atölye ekibi tanışma günü düzenliyor. Kalemler büyük kutuya, boş kağıtlar yanındaki sepete konacak. "
        "Çalışmadan önce masanın üzerindeki eski afişler kaldırılacak. Ekip önce malzemeleri hazırlayıp sonra yeni katılanları karşılayacak."),
    "C0-T": (
        "Bir mahalle grubu ortak bahçe için hazırlık yapıyor. Fidanlar kapının yanına, saksılar çatı altındaki rafa konacak. "
        "Bahçeye girmeden önce yoldaki eski tahtalar kaldırılacak. Grup üyeleri önce aletleri toplayıp sonra komşuları karşılayacak."),
    "H4-1": (
        "Şu üç adımı aklında tut: önce mavi kutuyu aç, sonra iki kâğıt al, en son lambayı kapat. "
        "Şimdi sesli olarak on, dokuz, sekiz diye geriye doğru say; sayma bitince üç adımı sırayla söyle."),
    "H4-2": (
        "Şu üç adımı aklında tut: önce yeşil dosyayı al, sonra üçüncü rafa koy, en son kapıyı kontrol et. "
        "Şimdi sesli olarak on, dokuz, sekiz diye geriye doğru say; sayma bitince üç adımı sırayla söyle."),
    "H4-3": (
        "Şu üç adımı aklında tut: önce kırmızı kalemi bul, sonra defterin ilk sayfasına yaz, en son pencereyi kapat. "
        "Şimdi sesli olarak on, dokuz, sekiz diye geriye doğru say; sayma bitince üç adımı sırayla söyle."),
    "H5-T": (
        "Bugün bulutların nasıl oluştuğunu anlatacağım. Konuyu üç parçada ele alacağız: önce buharlaşma, sonra soğuma, en sonunda yoğuşma. "
        "Güneş yüzeydeki suyu ısıtır ve su buharı yükselir. Yükseldikçe hava soğur ve buhar küçük damlacıklara dönüşür. "
        "Bu damlacıklar toz taneciklerinin çevresinde toplanır. Milyarlarca damlacık bir araya geldiğinde gözle görünen bir bulut oluşur."),
    "H5-A": (
        "Bugün mercan resiflerinin neden önemli olduğunu anlatacağım. Konuyu üç parçada ele alacağız: önce yaşam alanı, sonra kıyı koruması, en sonunda besin zinciri. "
        "Resifler birçok balığa barınak sağlar. Dalgaları yavaşlatarak kıyıyı korur. "
        "Küçük canlılar resiflerde beslenir ve onları daha büyük balıklar avlar. Sıcaklık yükselirse mercanlar renk kaybedebilir; bu duruma ağarma denir."),
    "H5-B": (
        "Bugün arıların çiçekleri neden ziyaret ettiğini anlatacağım. Konuyu üç parçada ele alacağız: önce nektar, sonra polen, en sonunda tozlaşma. "
        "Arılar çiçeklerden şekerli bir sıvı toplar. Ayrıca bacaklarına yapışan sarı toz taneciklerini taşır. "
        "Bu tanecikler başka bir çiçeğe değince meyve ve tohum oluşumuna yardım eder. Bir kovan günde binlerce çiçeği ziyaret edebilir."),
    "H6": (
        "Gezi cumartesi sabahı saat dokuzda, okulun arka kapısında toplanacak. "
        "Yanına bir şapka ve kırmızı bir su şişesi al. Otobüs yeşil renkli ve numarası on iki."),
}

# Dikte: (öğe listesi) ; her öğe "Number N." duyurusu + öğe + yazma boşluğu
DK_EN = {
    "DK-T": ["seven", "twenty-one", "Monday", "a green book", "Where is the bus stop?", "I live near the school."],
    "DK-A": ["fifteen", "Thursday", "a red bag", "forty-two", "Please open the door.", "My friend is at home."],
    "DK-B": ["thirteen", "Saturday", "a yellow pen", "sixty-five", "Please close the window.", "My brother is at school."],
    "DK-C": ["seventeen", "Sunday", "a black coat", "ninety-three", "Please wait at the gate.", "My teacher is in the room."],
}
DK_TR = {
    "DK-TR": ["on yedi", "Cumartesi", "kırmızı bir çanta", "yirmi iki", "Lütfen kapıyı aç.", "Arkadaşım evde."],
}
# dikte hız etiketi -> length_scale (öğe düzeyi; kelime/dk anlamsız)
DK_SPEED = {"DK-T": ("normal", 1.0), "DK-A": ("yavas", 1.20), "DK-B": ("normal", 1.0), "DK-C": ("hizli", 0.80), "DK-TR": ("normal", 1.0)}
DK_GAP_S = 6.0
