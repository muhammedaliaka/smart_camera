# Gün 5-7 (+Gün 8 H6) anahtar dosyalarını, ses metinlerinin tek kaynağından üretir.
import sys, importlib.util
tools, outdir = sys.argv[1], sys.argv[2]
spec = importlib.util.spec_from_file_location("audio_texts", f"{tools}/audio_texts.py")
T = importlib.util.module_from_spec(spec); spec.loader.exec_module(T)

def ordinal_lines(items, ords):
    return "\n".join(f"{i+1}. *{ords[i]}* → **{it}**" for i, it in enumerate(items))

ORD_EN = ["First.", "Second.", "Third.", "Fourth.", "Fifth.", "Sixth."]
ORD_TR = ["Birinci.", "İkinci.", "Üçüncü.", "Dördüncü.", "Beşinci.", "Altıncı."]

COMMON = """Bu anahtar **puan, yüzde, doğru/yanlış hükmü veya tanı üretmez**. Beklenen içerik bir kontrol listesidir; serbest yanıtlarda başka ifadeler de aynı noktayı taşıyabilir. İlk bağımsız yanıtın (A0) kayıtta aynen kalır; anahtara baktıktan sonra yaptığın düzeltme ayrı satırdır ve A2 olarak kodlanır. Anahtarı açınca **saatini** ve “elle” ya da “üçüncü gönderimde” diye yaz (`../kayitlar/YANIT_SABLONU.md`)."""

# ---------------------------------------------------------------- GÜN 5
g5 = f"""# Gün 5 anahtarı — yalnız Gün 5 görevlerini bitirince aç

{COMMON}

Gün 5 hafıza görevi (G05-H2-A) için **anahtar yoktur**: kontrol edilecek bilgi, `05_GUN5_GOREVLER.md` içinde gördüğün tek satırdır. Gün 12 kontrolü yapılmadan o satıra bir daha bakma; baktıysan saatini ve hangi kontrolden önce olduğunu yaz.

## G05-W1

Beklenen noktalar: kişinin tanıtılması, yaşadığı yer, bir ilgi, ortak etkinlik önerisi ve karşı tarafa soru. Örnek (kopyalamak gerekmez): **Hi, I'm Ada. I live in Türkiye. I like science and music. I want to join a study group. We can read a short article together. What do you like learning?** Daha kısa yanıt da kayıtta aynen korunur.

## G05-R1

1. Büyükannelerini ziyaret ediyorlar.
2. Büyükanne bir arkadaşında kalıyor.
3. Önce kütüphane, sonra spor merkezi.
4. İlk otobüs kütüphanenin yakınında durmuyor.
5. Kardeşi defterini unutuyor; Nora'nın defterini paylaşıyorlar.
6. Hayır; yalnız “gelecek ay” başka bir etkinlik olduğu söyleniyor.

Ana olay: iki kardeşin değişen cumartesi planı, kütüphanedeki etkinlik ve sonraki etkinlik tarihinin not edilmesi. Kapalı anlatımın bu noktaları hangi dilde içerdiği dış değerlendirici tarafından yorumlanır; anlatımın dili (İngilizce / Türkçe / karışık) kayıtta açıkça yazılır.

## G05-T1

1. Yeni insanlarla tanışmayı sevdiğim için İngilizce öğrenmek istiyorum.
2. Buluşma/toplantı okuldan sonra ama daha geç gelebilirim.
3. **I don't understand this word. Can you repeat it/that, please?** Anlamı koruyan başka ifade de olabilir.
4. **My friend isn't here today. / My friend is not here today.**

## G05-G1

Beklenen biçimler sırasıyla: **is, live, are, doesn't, were, help**. Bu liste cevap anahtarıdır; sistemin ya da raporun senin hakkında vereceği bir hüküm değildir.

## G05-H4 — duyduğun metinler

Üç deneme; her dosyada üç adım ve ardından geriye sayma yönergesi duyuldu. Hayalî adımlar şunlardı (ses, adımları bir kez söyler):

- **H4-1** (`G05_H4_1.mp3`): {T.TR["H4-1"].split(": ",1)[1].split(". Şimdi")[0]}.
- **H4-2** (`G05_H4_2.mp3`): {T.TR["H4-2"].split(": ",1)[1].split(". Şimdi")[0]}.
- **H4-3** (`G05_H4_3.mp3`): {T.TR["H4-3"].split(": ",1)[1].split(". Şimdi")[0]}.

Tam metin her dosyada: “Şu üç adımı aklında tut: … Şimdi sesli olarak on, dokuz, sekiz diye geriye doğru say; sayma bitince üç adımı sırayla söyle.”

Kayıtta aranan noktalar: adımların **sırası**, her adımdaki nesne ve eylem (örn. “mavi kutu”, “iki kâğıt”), sayma boyunca geçen süre (ses kaydından okunur). Eksik, yer değiştirmiş ya da yaklaşık söylenen adımlar kayıtta aynen kalır; “bilmiyorum” da geçerli bir kayıttır. Bu anahtardan puan çıkmaz ve üç deneme tek bir “bellek düzeyi” sayısına indirgenmez.
"""
# ---------------------------------------------------------------- GÜN 6
a, b, c = T.DK_EN["DK-A"], T.DK_EN["DK-B"], T.DK_EN["DK-C"]
tr = T.DK_TR["DK-TR"]
g6 = f"""# Gün 6 anahtarı — yalnız Gün 6 görevlerini ve A'nın ertesi gün kontrolünü bitirince aç

{COMMON}

Hafıza görevleri (G05-H2-A, G06-H2-B) için **anahtar yoktur**; kontrol edilecek bilgiler `05_GUN5_GOREVLER.md` (A) ve `05_GUN6_GOREVLER.md` (B) içinde gördüğün satırlardır. A'nın bir haftalık kontrolü Gün 12'de, B'nin ertesi gün kontrolü Gün 7'dedir; o kontroller bitmeden satırlara tekrar bakma.

## G06-S1 / G06-S2

Sesli okuma: özgün metin ile kaydın birlikte tutulması yeterlidir. Serbest konuşmada aranan işlevler: kendini tanıtma, ilgi belirtme, soru sorma, tekrar isteme. Dış değerlendirici örnekleri **dinleyerek** hangi gözlemi hangi kayda dayandırdığını söyler; sözcük sözcük transkript tek başına telaffuz değerlendirmesi olmaz.

## G06-B1 — dikte: söylenen öğeler

Her öğeden önce sıra numarası söylenir; öğe **bir kez** okunur ve ardından altı saniye boşluk bırakılır. Yazılışta sayılar rakamla (15) ya da sözcükle (fifteen) yazılabilir; büyük/küçük harf ve noktalama kaydedilir ama ayrı bir hata sayılmaz.

**Dikte 1** (`G06_B1_dikte_1.mp3`, yavaş):

{ordinal_lines(a, ORD_EN)}

**Dikte 2** (`G06_B1_dikte_2.mp3`, normal):

{ordinal_lines(b, ORD_EN)}

**Dikte 3** (`G06_B1_dikte_3.mp3`, hızlı):

{ordinal_lines(c, ORD_EN)}

**Dikte TR** (`G06_B1_dikte_TR.mp3`, Türkçe kontrol, normal hız):

{ordinal_lines(tr, ORD_TR)}

Notlar: Her dosyada iki sayı, bir gün adı, bir nesne öbeği ve iki kısa cümle vardır. -teen ile biten sayılar (fifteen, thirteen, seventeen) onluk sayılarla (50, 30, 70) benzer duyulabilir; böyle bir karışma gözleme girer, hüküm değildir. Dikte işitme testi değildir.

## G06-L1 — duyduğun metinler (İngilizce)

Üç dosya üç farklı konuşmacı ve üç farklı hızdadır (hedef yaklaşık 120 / 90 / 150 sözcük/dakika; gerçekleşen değerler `ses/ses_manifest.json` içindedir).

**EN-A, Maya (`EN_A_normal.mp3`):** {T.EN["EN-A"][2]}

**EN-B, Daniel (`EN_B_yavas.mp3`):** {T.EN["EN-B"][2]}

**EN-C, Emma (`EN_C_hizli.mp3`):** {T.EN["EN-C"][2]}

Beklenen içerik:

- **A:** Maya; kütüphane; salı; saat dört (biraz erken gelecek); defter ve mavi kalem; merdivene yakın oda uygun değil; ön kapıda bekleme ve yeni odaya birlikte gitme.
- **B:** Daniel; okulda bilim kulübü etkinliği; cuma; saat üç; kalem ve su şişesi; alışılmış sınıf dolu; ana kapının yanında buluşma.
- **C:** Emma; spor merkezi; çarşamba; saat beş (erken gelecek); rahat ayakkabı ve küçük havlu; yan giriş kapalı; otobüs durağının yanındaki kapı.

## G06-TR-L — duyduğun metin (Türkçe)

(`TR_L.mp3`) {T.TR["TR-L"]}

Beklenen içerik: Burak; perşembe; kütüphane; dört; defter ve siyah kalem; merdivene yakın oda dolu; kapıda buluşup yeni odaya geçme.

Türkçe ve İngilizce parçalar anlam bakımından yakındır ama ölçülmüş eşdeğer formlar değildir; dil ya da hız etkisini tek başına ayırmazlar.

## Bu anahtarın sınırı

Ses dosyaları yapay (nöral) sestir. Bir kısmını anlayamamak ses kalitesinden, hızdan, içerikten ya da dinleme koşullarından kaynaklanabilir; bunlar bu pakette ayrılamaz. “Ses anlaşılmadı” ile “içeriği anlamadım” ayrımı kayıtta yazılı kalır.
"""
# ---------------------------------------------------------------- GÜN 7
g7 = f"""# Gün 7 anahtarı — yalnız Gün 7 görevlerini bitirince aç

{COMMON}

Hafıza görevi G06-H2-B için anahtar yoktur (kontrol edilecek bilgiler `05_GUN6_GOREVLER.md` içinde gördüğün satırdır). H6 duyurusunun anahtarı **bu dosyada değildir**: Gün 8 kontrolü bitmeden duyuru metnine bakma; anahtar `08_ANAHTAR_GUN8_H6.md` dosyasındadır.

## G07-H5 — duyduğun mini dersler

**H5-1, strateji A (`G07_H5_1.mp3`):** {T.TR["H5-A"]}

**H5-2, strateji B (`G07_H5_2.mp3`):** {T.TR["H5-B"]}

Beklenen içerik (“Dersin başında ne söylendi?”):

- **H5-1:** konu, mercan resiflerinin neden önemli olduğu; üç parça: yaşam alanı, kıyı koruması, besin zinciri.
- **H5-2:** konu, arıların çiçekleri neden ziyaret ettiği; üç parça: nektar, polen, tozlaşma.

İki parça farklı içeriktedir ve sıra sabittir (A sonra B); sonuçlar bir stratejinin üstünlüğünü kanıtlamaz, yalnız kendi gözlemini kaydeder.

## G07-C — duyduğun metinler

- **C0-dinleme, `G07_C0_dinleme.mp3`:** {T.TR["C-A"]}
- **C1, `G07_C1.mp3`:** {T.TR["C-B"]}
- **C2, `G07_C2.mp3`:** {T.TR["C-C"]}

Beklenen içerik:

- **C0-dinleme:** sergi; fotoğraflar giriş masasına, çizimler pencere panosuna; eski kâğıtlar kaldırılacak; önce düzenleme sonra konuk karşılama.
- **C1:** kitap değişimi; romanlar kapıya yakın masaya, dergiler köşe rafına; raftaki kutular kaldırılacak; önce yerleştirme sonra karşılama.
- **C2:** atölye tanışma günü; kalemler büyük kutuya, kâğıtlar sepete; eski afişler kaldırılacak; önce hazırlık sonra karşılama.

Bu formlar eşdeğerliği kanıtlanmış ölçme araçları değildir; tek görev ile birleşik görev farkından genel beceri ya da yalnız hareket etkisi çıkarılmaz. Yazma, konuşma ve C3 görevlerinde anahtar yoktur; yanıtlar aynen saklanır.

## G07-O — okuma sonrası anlatım

Üç ortak soru: (1) ana olay, (2) çıkan sorun ya da değişen bilgi, (3) sonunda yapılan şey ya da tutulan kayıt.

- **O1 (A):** Okulun boş odası çalışma alanı yapılıyor. Önce masalar pencereye yaklaştırılıyor, öğleden sonra ışık ekranlarda yansıma yapıyor; masalar yan duvara çevriliyor, geçiş yolu daralıyor, açık bir yol bırakılıyor. Panoya kısa kurallar asılıyor. İlk kullananlardan görüş alınıyor; çanta yeri eksik olduğu için bir köşeye çanta rafı ekleniyor. İlk plan tümüyle atılmıyor; öneri kâğıdı bırakılıyor.
- **O2 (B):** Kulüp defteri yerinde yok. Aynı yerler yeniden aranmak yerine bakılan yerler yazılıyor (sınıf dolabı, sergi kutuları). Bir öğrencinin “masada iki benzer defter vardı” hatırlaması aramayı etkinlik odasına yöneltiyor; defter hoparlör çantasında. Belirsiz hatırlama ile kesin olay ayrımı vurgulanıyor. Ödünç alma kartı: kim aldı, nereye götürdü; gereksiz kişisel bilgi yazılmayacak.
- **O3 (B):** İki afiş: canlı renkli ve büyük fotoğraflı olan ile sade olan. Sade afişte bilgi daha kolay bulunuyor. Fotoğraf kaldırılmıyor, küçültülüyor; yer ve başlama bilgisi fotoğrafın altına aynı boyutta konuyor. Deneme grubu küçük; “herkes daha iyi anlayacak” denmiyor. Telefon ve basılı kâğıtta görünüm farklı olabilir; iki ortamda yeniden inceleniyor, küçük yazı büyütülüyor, değişiklikler listeleniyor.
- **O4 (A):** Okul bahçesi: ilk gün herkes toprak taşıyor ama fidan yerleri belli değil, toprağın bir kısmı yeniden taşınıyor. İkinci gün sıra: alan işaretleme, toprak hazırlama, bitki yerleştirme; görevler panoda. Sulama kabı eksik; sulama yapılmış gibi işaretlenmiyor, tamamlanan ve bekleyen işler ayrı yazılıyor. Ertesi gün önce bekleyen sulama yapılıyor.

Satır kaybı ve geri dönüş sayıları senin beyanındır; anahtarda olması gereken bir sayı yoktur.

## Gün 8 ve sonrası

- **Gün 8:** H6 kontrol 4 (açmadan), sonra `08_ANAHTAR_GUN8_H6.md`.
- **Gün 12:** G05-H2-A satırının bir haftalık kontrolü; yalnız “A bilgisi neydi?” sorusu.
- **Gün 13 (isteğe bağlı):** G06-H2-B'nin bir haftalık kontrolü.
"""
# ---------------------------------------------------------------- GÜN 8 H6
g8 = f"""# H6 anahtarı — yalnız Gün 8 kontrolünü (kontrol 4) yaptıktan sonra aç

{COMMON}

Duyuru (`H6_dinleme_G03_G04_G07.mp3`), Gün 3'te bir, Gün 4'te ikinci, Gün 7'de üçüncü kez dinlendi:

> {T.TR["H6"]}

Kayıtta aranan **yedi ayrıntı**: (1) gezi, (2) cumartesi sabahı, (3) saat dokuz, (4) okulun arka kapısı, (5) şapka, (6) kırmızı su şişesi, (7) yeşil otobüs, numara on iki. Yedi ayrıntı kaydı okumak için kullanılan bir listedir; bir “puan” değildir.

Kontrollerin sırası ve ne anlama geldiği (hepsi açmadan, yardımsız):

| Kontrol | Gün | Ondan önceki dinleme sayısı | Önceki dinlemeden beri |
| --- | --- | --- | --- |
| 1 | 4 | 1 | yaklaşık bir gün |
| 2 | 7 | 2 | yaklaşık üç gün |
| 3 | 7 | 3 | birkaç dakika |
| 4 | 8 | 3 | yaklaşık bir gün |

Kontrol 1 ile kontrol 4 aynı gecikmede (bir gün) ama farklı dinleme sayısındadır; bu karşılaştırma “3+ kez dinleyince kalıyor” gözlemini kendi verinde sınamak içindir. Sınırlar: her kontrol soru olarak bir hatırlama alıştırmasıdır (retrieval); yani kontrolün kendisi sonraki kontrolü kolaylaştırabilir. İçerik tek, kişi tek, hafta tektir; bu yüzden sonuç genellenemez ve hüküm çıkarılmaz.
"""
import os
for fn, txt in [("08_ANAHTAR_GUN5.md", g5), ("08_ANAHTAR_GUN6.md", g6), ("08_ANAHTAR_GUN7.md", g7), ("08_ANAHTAR_GUN8_H6.md", g8)]:
    open(os.path.join(outdir, fn), "w", encoding="utf-8").write(txt)
    print(fn, len(txt))
