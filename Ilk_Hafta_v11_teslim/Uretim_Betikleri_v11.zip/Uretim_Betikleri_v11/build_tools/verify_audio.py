"""Nihai mp3'leri bağımsız (daha büyük) bir ASR modeliyle geri okur ve beklenen metinle karşılaştırır.
Kullanım: python verify_audio.py <audio_dir> <out_json> <model>
"""
import difflib, json, re, subprocess, sys, unicodedata
import numpy as np
from faster_whisper import WhisperModel
sys.path.insert(0, __file__.rsplit("/", 1)[0])
import audio_texts as T
adir, out, model = sys.argv[1], sys.argv[2], sys.argv[3]
EN_ONES = "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen".split()
EN_TENS = "_ _ twenty thirty forty fifty sixty seventy eighty ninety".split()
TR_ONES = "sıfır bir iki üç dört beş altı yedi sekiz dokuz".split()
TR_TENS = "_ on yirmi otuz kırk elli altmış yetmiş seksen doksan".split()
def num(n, lang):
    O, Tn = (EN_ONES, EN_TENS) if lang == "en" else (TR_ONES, TR_TENS)
    if lang == "en" and n < 20: return O[n]
    if lang == "tr" and n < 10: return O[n]
    t, o = divmod(n, 10)
    return Tn[t] + ("" if o == 0 else " " + O[o])
def norm(s, lang):
    s = unicodedata.normalize("NFC", s).lower().replace("-", " ")
    s = re.sub(r"\b(\d{1,2})(st|nd|rd|th)\b", lambda m: num(int(m.group(1)), "en"), s)
    s = re.sub(r"\b\d{1,2}\b", lambda m: num(int(m.group(0)), lang), s)
    s = re.sub(r"[^\w\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()
def load(path):
    o = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-f", "f32le", "-ac", "1", "-ar", "16000", "-"], capture_output=True, check=True).stdout
    return np.frombuffer(o, dtype=np.float32)
ORD_EN = ["First.", "Second.", "Third.", "Fourth.", "Fifth.", "Sixth."]
ORD_TR = ["Birinci.", "İkinci.", "Üçüncü.", "Dördüncü.", "Beşinci.", "Altıncı."]
exp = {}
for tid, (sp, vk, text) in T.EN.items():
    for lab in T.SPEEDS: exp[f"{tid.replace('-','_')}_{lab}"] = (text, "en")
for tid, text in T.TR.items(): exp[tid.replace("-", "_")] = (text, "tr")
for tid, items in T.DK_EN.items(): exp[tid.replace("-", "_")] = (" ".join(f"{ORD_EN[i]} {it}" for i, it in enumerate(items)), "en")
for tid, items in T.DK_TR.items(): exp[tid.replace("-", "_")] = (" ".join(f"{ORD_TR[i]} {it}" for i, it in enumerate(items)), "tr")
m = WhisperModel(model, device="cpu", compute_type="int8")
res = {}
for name, (text, lang) in sorted(exp.items()):
    segs, _ = m.transcribe(load(f"{adir}/{name}.mp3"), language=lang, beam_size=5, condition_on_previous_text=False)
    heard = " ".join(s.text.strip() for s in segs)
    sim = difflib.SequenceMatcher(None, norm(text, lang), norm(heard, lang), autojunk=False).ratio()
    res[name] = dict(similarity=round(sim, 3), heard=heard, model=model)
    print(f"{name:14s} {sim:.3f} | {heard}", flush=True)
json.dump(res, open(out, "w"), ensure_ascii=False, indent=1)
