"""Dikte dosyalarını yeniden üretir (v2): İngilizce dikte sesi 'ljspeech' (kristin bazı tek sözcüklerde bozuktu),
öğe adayları iki bağlamda (taşıyıcı ifade + gerçek dosya bağlamı: sıra sözcüğü + 0,6 sn boşluk) small ve medium
modelle geri okunur; en düşük skoru en yüksek aday seçilir.
Kullanım: python regen_dictation2.py <voices_dir> <out_dir> [K] [yalnız_şu_çıktılar]
  yalnız_şu_çıktılar: virgülle ayrılmış (ör. DK_TR); verilmezse DK_T,DK_A,DK_B,DK_C,DK_TR hepsi."""
import sys, json, re, difflib, unicodedata, time
voices_dir, out_dir = sys.argv[1], sys.argv[2]
ONLY = set(sys.argv[4].split(",")) if len(sys.argv) > 4 else None
K2 = int(sys.argv[3]) if len(sys.argv) > 3 else 8
HERE = __file__.rsplit("/", 1)[0]
head = open(f"{HERE}/gen_audio2.py", encoding="utf-8").read().split("random.seed(11)")[0]
sys.argv = [__file__, voices_dir, out_dir, "1"]
exec(compile(head, "gen_audio2_head", "exec"))
asr2 = WhisperModel("medium", device="cpu", compute_type="int8")
EN_DICT_VOICE = "ljspeech"

ORDW = {"1st": "first", "2nd": "second", "3rd": "third", "4th": "fourth", "5th": "fifth", "6th": "sixth"}
def norm2(s, lang):
    s = unicodedata.normalize("NFC", s).lower()
    for k, v in ORDW.items(): s = re.sub(rf"\b{k}\b", v, s)
    return norm(s, lang)
TR_ORD_DIGIT = {"1": "birinci", "2": "ikinci", "3": "üçüncü", "4": "dördüncü", "5": "beşinci", "6": "altıncı"}
def sim2(a, b, lang, ordinal=False):
    if ordinal and lang == "tr":  # ASR sıra sözcüğünü rakamla yazarsa eşdeğer say
        b = re.sub(r"\b([1-6])\b\.?", lambda m: TR_ORD_DIGIT[m.group(1)], b)
    return difflib.SequenceMatcher(None, norm2(a, lang), norm2(b, lang), autojunk=False).ratio()
CARRIER = {"en": "The answer is", "tr": "Cevap şu"}
_car = {}
def carrier_audio(vkey):
    if vkey not in _car:
        _car[vkey] = synth_once(vkey, CARRIER[LANG[vkey]], 1.0)
    return _car[vkey]
def tr_model(model, arr, sr, lang):
    x = arr.astype(np.float32) / 32768.0
    if sr != 16000:
        n = int(len(x) * 16000 / sr)
        x = np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x).astype(np.float32)
    x = np.concatenate([np.zeros(3200, np.float32), x, np.zeros(3200, np.float32)])
    segs, _ = model.transcribe(x, language=lang, beam_size=5, condition_on_previous_text=False, temperature=0.0, max_new_tokens=40, without_timestamps=True)
    return " ".join(s.text.strip() for s in segs)

LOG2, _cache2 = [], {}
def best_unit(vkey, text, ls, ordinal=None, k=K2, is_ord=False):
    """ordinal=None: yalnız taşıyıcı bağlam; aksi halde (sıra_metni, sıra_sesi) ile ikinci bağlam da denenir."""
    key = (vkey, text, round(ls, 3), ordinal[0] if ordinal else None)
    if key in _cache2: return _cache2[key]
    lang, sr = LANG[vkey], voice(vkey).config.sample_rate
    ctxs = [(f"{CARRIER[lang]} {text}", np.concatenate([carrier_audio(vkey), silence(sr, 0.15)]))]
    if ordinal:
        ctxs.append((f"{ordinal[0]} {text}", np.concatenate([ordinal[1], silence(sr, 0.6)])))
    def score(model, a):
        return [sim2(exp, tr_model(model, np.concatenate([pre, a]), sr, lang), lang, ordinal=is_ord) for exp, pre in ctxs]
    cands = []
    for ci in range(k):
        a = synth_once(vkey, text, ls)
        s_small = score(asr, a)
        c = dict(a=a, small=s_small, medium=None)
        cands.append(c)
        if min(s_small) >= 0.999:
            c["medium"] = score(asr2, a)
            if min(c["medium"]) >= 0.999:
                break
    top = sorted(cands, key=lambda c: -min(c["small"]))[:3]
    for c in top:
        if c["medium"] is None:
            c["medium"] = score(asr2, c["a"])
    med = float(np.median([len(c["a"]) for c in cands]))
    best = max(top, key=lambda c: (round(min(min(c["small"]), min(c["medium"])), 3), -abs(len(c["a"]) - med)))
    LOG2.append(dict(voice=vkey, text=text, ls=round(ls, 3), small=[round(x, 3) for x in best["small"]],
                     medium=[round(x, 3) for x in best["medium"]], tried=len(cands), contexts=len(ctxs)))
    print("  unit", vkey, repr(text), [round(x, 2) for x in best["small"]], [round(x, 2) for x in best["medium"]], f"tried={len(cands)}", flush=True)
    _cache2[key] = best["a"]
    return best["a"]

ORD_EN = ["First.", "Second.", "Third.", "Fourth.", "Fifth.", "Sixth."]
ORD_TR = ["Birinci.", "İkinci.", "Üçüncü.", "Dördüncü.", "Beşinci.", "Altıncı."]

def render_dictation2(vkey, items, ls, ordinals, gap):
    sr = voice(vkey).config.sample_rate
    segs, speech = [silence(sr, 0.4)], 0
    for i, it in enumerate(items):
        o = best_unit(vkey, ordinals[i], 1.0, None, k=(24 if LANG[vkey] == "tr" else 6), is_ord=True)
        a = best_unit(vkey, it, ls, (ordinals[i], o))
        speech += len(a)
        segs += [o, silence(sr, 0.6), a, silence(sr, gap)]
    segs.append(silence(sr, 1.0))
    return np.concatenate(segs), sr, speech / sr

t0 = time.time()
for tid, items in T.DK_EN.items():
    name = tid.replace("-", "_")
    if ONLY and name not in ONLY: continue
    label, ls = T.DK_SPEED[tid]
    arr, sr, sp = render_dictation2(EN_DICT_VOICE, items, ls, ORD_EN, T.DK_GAP_S)
    finish(name, arr, sr, dict(text_id=tid, language="en", speaker=EN_DICT_VOICE, voice=f"en_US-{EN_DICT_VOICE}", speed_label=label,
                               length_scale=ls, items=len(items), gap_seconds=T.DK_GAP_S, best_of=K2, selection="carrier+context, small+medium"))
for tid, items in T.DK_TR.items():
    name = tid.replace("-", "_")
    if ONLY and name not in ONLY: continue
    label, ls = T.DK_SPEED[tid]
    arr, sr, sp = render_dictation2("dfki", items, ls, ORD_TR, T.DK_GAP_S)
    finish(name, arr, sr, dict(text_id=tid, language="tr", speaker="tr-dfki", voice="tr_TR-dfki", speed_label=label,
                               length_scale=ls, items=len(items), gap_seconds=T.DK_GAP_S, best_of=K2, selection="carrier+context, small+medium"))
json.dump(results, open(f"{out_dir}/results.json", "w"), ensure_ascii=False, indent=1)
json.dump(LOG2, open(f"{out_dir}/select_log.json", "w"), ensure_ascii=False, indent=1)
print("DONE", round(time.time() - t0), "sn", flush=True)
