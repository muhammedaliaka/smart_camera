"""Paket kökü için manifest.json ve checksums.sha256 üretir.
Kullanım: python3 -I build_manifest.py <paket_kökü>"""
import hashlib
import json
import os
import sys

root = sys.argv[1]
SKIP = {"manifest.json", "checksums.sha256"}


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for ch in iter(lambda: f.read(1 << 20), b""):
            h.update(ch)
    return h.hexdigest()


def listing():
    out = []
    for d, _, fs in os.walk(root):
        for f in fs:
            p = os.path.join(d, f)
            rel = os.path.relpath(p, root).replace(os.sep, "/")
            out.append((rel, p))
    return sorted(out)


files = [(r, p) for r, p in listing() if r not in SKIP]
mp3 = [r for r, _ in files if r.endswith(".mp3")]
ses = json.load(open(f"{root}/test_gununde_ac/ses/ses_manifest.json", encoding="utf-8"))
lang = {e["path"]: e["language"] for e in ses["files"]}
assert set(lang) == set(mp3), set(lang) ^ set(mp3)

man = dict(
    kind="learning_material_package",
    version="11",
    prepared_on="2026-10-27",
    timezone="Europe/Istanbul",
    contains_user_results=False,
    automatic_recording_app_included=False,
    turkish_audio_included=True,
    english_synthetic_audio_count=sum(1 for v in lang.values() if v == "en"),
    turkish_synthetic_audio_count=sum(1 for v in lang.values() if v == "tr"),
    audio_human_listening_qa=False,
    audio_tested_on_user_device=False,
    spreadsheet_tested_in_excel=False,
    notes="manifest.json ve checksums.sha256 kendi özetlerini içermez; checksums.sha256 manifest.json dahil diğer tüm dosyaları içerir.",
    files=[dict(path=r, size_bytes=os.path.getsize(p), sha256=sha(p)) for r, p in files],
)
with open(f"{root}/manifest.json", "w", encoding="utf-8") as f:
    json.dump(man, f, ensure_ascii=False, indent=1)
    f.write("\n")

lines = [f"{sha(p)}  {r}" for r, p in listing() if r != "checksums.sha256"]
with open(f"{root}/checksums.sha256", "w", encoding="ascii", newline="\n") as f:
    f.write("\n".join(lines) + "\n")
print("dosya:", len(files), "+ manifest; en:", man["english_synthetic_audio_count"], "tr:", man["turkish_synthetic_audio_count"])
