"""v10 ana raporunu v11'e çevirir. Her değişiklik tam olarak bir kez eşleşmek zorundadır (aksi halde betik durur).
Kullanım: python3 -I patch_report_v11.py <10_ANA_RAPOR_v10.md> <10_ANA_RAPOR_v11.md>"""
import re
import sys

src, dst = sys.argv[1], sys.argv[2]
T = open(src, encoding="utf-8").read()
LOG = []


def rep(old, new, count=1):
    global T
    n = T.count(old)
    assert n == count, f"{n} eşleşme (beklenen {count}): {old[:90]!r}"
    T = T.replace(old, new)
    LOG.append(old[:60])


def block(start, end, new):
    """start satırından (dahil) end işaretine (hariç) kadar olan bloğu değiştirir; ikisi de tek kez bulunmalı."""
    global T
    assert T.count(start) == 1, f"başlangıç işareti {T.count(start)} kez: {start[:60]!r}"
    i = T.index(start)
    assert T.count(end) == 1, f"bitiş işareti {T.count(end)} kez: {end[:60]!r}"
    j = T.index(end)
    assert j > i
    T = T[:i] + new + T[j:]
    LOG.append("blok: " + start[:50])


def insert_after_line(prefix, newlines):
    global T
    idx = [m.start() for m in re.finditer(r"(?m)^" + re.escape(prefix), T)]
    assert len(idx) == 1, f"{len(idx)} satır: {prefix!r}"
    e = T.index("\n", idx[0])
    T = T[: e + 1] + newlines + T[e + 1 :]
    LOG.append("ekle: " + prefix)


# ---------------------------------------------------------------- başlık ve durum
rep("## Birleşik ana rapor, bağımsız analiz ve değerlendirici talimatı (v10)",
    "## Birleşik ana rapor, bağımsız analiz ve değerlendirici talimatı (v11)")
rep("**Tarih:** 26 Ekim 2026 · **Sürüm:** v10 (R9 açıklaması, kaynak araştırması ve ilk hafta içerikleri işlendi)",
    "**Tarih:** 27 Ekim 2026 · **Sürüm:** v11 (v10 raporu ve ilk hafta paketinin hata analizi, düzeltmeler, yeniden kurulmuş paket)")
rep("İngilizce sentetik sesler üretildi. Türkçe ses dosyaları ve gerçek cihaz doğrulaması eksik. Otomatik kayıt uygulaması geliştirilmedi; eski prototip değiştirilmedi.",
    "Türkçe ve İngilizce nöral sentetik sesler üretildi; otomatik tanıma ile geri okundu, **insan dinleme kontrolünden geçmedi** ve kullanıcı cihazında denenmedi. Gerçek cihaz doğrulaması eksik. Otomatik kayıt uygulaması geliştirilmedi; eski prototip değiştirilmedi.")

# ---------------------------------------------------------------- 0.1
rep("### 0.1. v10'da ne değişti?\n\nR9, önceki raporun açık yorumlarını netleştirdi.",
    """### 0.1. v11'de ne değişti?

27 Ekim 2026'da v10 paketinin 26 dosyası ve bu rapor tek tek okundu; bulgular ve düzeltmeler `09_DEGISIKLIK_VE_HATA_RAPORU.md` dosyasındadır. Bu raporu ilgilendiren başlıca değişiklikler:

1. **Paket yeniden kuruldu (v11):** Gün 5–7 görevleri üç ayrı dosyaya bölündü (bir günün dosyasını açmak sonraki günlerin soru ve hafıza satırlarını göstermesin diye); anahtarlar gün gün ayrıldı; H6 anahtarı Gün 8 dosyasına alındı (kontrol 4'ten önce görünmesin). Okuma görevlerinin soruları metne özgü olmaktan çıkarılıp dört metinde aynı üç genel soru yapıldı (ön bilgi/hazırlanma etkisini azaltmak için).
2. **Sesler yeniden üretildi:** Türkçe ve İngilizce nöral sesler Piper ile üretildi; üretim sırasında birden çok aday sentezlenip otomatik tanıma ile geri okunarak en iyisi seçildi, sonra nihai mp3 dosyaları `medium` boyutlu bir tanıma modeliyle yeniden okundu (dikte dosyalarında bu model seçimde de kullanıldığı için orada kontrol bağımsız sayılmaz). Çok kısa tekil öğeler (sayılar, sıra sözcükleri, gün adları) otomatik tanıma için güvenilmezdir; dikte dosyaları bu yüzden taşıyıcı ifade, dosyadaki gerçek bağlam ve iki modelle yeniden üretildi (bazı tek sözcüklerde ilk İngilizce ses bozuk çıktığı için dikte sesi değiştirildi). **İnsan dinleme kontrolü yoktur.**
3. **İngilizce tekrar takvimi (xlsx) eklendi:** ardışık 3–10–20–50 kuralı ve gecikmede “sonraki aralık gerçekleşen tekrardan başlar” tasarımı formülle işler; planlanan ve gerçekleşen tarih ayrı tutulur. Yalnız LibreOffice ile denendi (Bölüm 8.8).
4. **Numaralama:** Bölüm 8.8 numarası boş kalmıştı (8.7'den §§89§§'a atlanıyordu); “İngilizce tekrar kuralı” artık **8.8**'dir ve tüm göndermeler güncellendi.
5. **Hafta 1 tabloları paketle eşlendi:** 13.2 (gün gün hedefler), 7.8 (gecikmeli hatırlama aralıkları: 5 dk · 30 dk · 2 sa · ertesi gün; bir haftalık takip Gün 12–13), 9.3 (H5 sırası sabit, dengelenmedi), 9.5 (8 duraklı güzergâh, 6 öğelik eğitim listesi, 7 öğelik H1), 10.2 (özgün Türkçe ≈155 sözcüklük dört metin, tek ortam), 11.7/11.11/11.13 (Hafta 1'de yüklü direnç çalışması yok; üç basamaklı rampa; duvar şınavı).
6. **Kaynaklar yeniden açıldı (27 Ekim 2026):** USA Learns, VOA, British Council, Stanford, EF SET, NSCA PDF, Anki, Brain Workshop, Nike Training Club. Busuu yardım sayfası 403 verdi ve Melby-Lervåg bağlantısı yeniden açılmadı; bu iki satır işaretlendi (Bölüm 17).
7. **Yeni riskler:** RK28 (sentetik sesin doğrulanmamış kalitesi), RK29 (Hafta 1 paketinde ayrıştırılamayan karışıklıklar). Yeni kaynak: K73–K74.

**v10 değişiklikleri (R9) — korunur:**

R9, önceki raporun açık yorumlarını netleştirdi.""")
rep("7. **İlk hafta paketi:** günlük kartlar, dört İngilizce yedek dersi, iki okuma, spor başlangıç kartı, üç test gününün özgün soruları, ayrı anahtar, seslendirme metinleri, İngilizce sentetik sesler ve boş kayıt şablonları. Otomatik kayıt uygulaması, Türkçe sesler ve 50 makalelik havuzun tamamı bu teslimde yoktur.",
    "7. **İlk hafta paketi:** günlük kartlar, dört İngilizce yedek dersi, okuma metinleri, spor başlangıç kartı, üç test gününün özgün soruları, gün gün ayrı anahtarlar, seslendirme metinleri, Türkçe ve İngilizce nöral sentetik sesler (v11'de yeniden üretildi) ve boş kayıt şablonları. Otomatik kayıt uygulaması ve 50 makalelik havuzun tamamı bu teslimde yoktur.")

# ---------------------------------------------------------------- 1.4
rep("Kayıt-kritik testlerin bütün akışı, Türkçe sesler ve cihaz doğrulaması tamamlanmadan hazır ilan edilmez.",
    "Kayıt-kritik testlerin bütün akışı ve kullanıcı cihazındaki doğrulama tamamlanmadan hazır ilan edilmez; sesler üretildi ama insan dinleme kontrolünden geçmedi.")

# ---------------------------------------------------------------- D39 (Q2 tanımsızdı)
rep("| D39 | **Konuşma partneri yok** (Q2 cevabı).", "| D39 | **Konuşma partneri yok** (R8-6 cevabı).")

# ---------------------------------------------------------------- 5.11
rep("İngilizce sentetik sesleri; boş kayıt ve tekrar şablonları.",
    "Türkçe ve İngilizce nöral sentetik sesler (otomatik tanıma ile geri okundu, insan dinleme kontrolü yok); boş kayıt şablonları ve formüllü İngilizce tekrar takvimi (xlsx).")
rep("Türkçe ses dosyaları ve kullanıcı cihazındaki doğrulama da eksik.",
    "Kullanıcı cihazındaki doğrulama ve seslerin insan dinleme kontrolü de eksik.")

# ---------------------------------------------------------------- 7.8
rep("10 dk – ertesi gün aralığında ilk hatırlama gözlemleri;",
    "5 dk – ertesi gün aralığında ilk hatırlama gözlemleri (Hafta 1 paketi: 5 dk · 30 dk · 2 sa · ertesi gün);")
rep("1 haftalık hatırlama (Hafta 2'ye düşer);",
    "1 haftalık hatırlama (Gün 12–13'e düşer, Hafta 1 raporunun dışındadır);")

# ---------------------------------------------------------------- 8.5 örnekler
rep("| Serbest yazı | “Bir günümü anlat” | 5–8 cümle |",
    "| Serbest yazı | “Bir günümü anlat” (Hafta 1: kendini tanıtan ve etkinlik öneren yazı, G05-W1) | 5–8 cümle |")
rep("| Okuma anlama | 120–180 kelimelik başlangıç metni + 3 açık uçlu soru + kendi sözleriyle anlatım |",
    "| Okuma anlama | 120–180 kelimelik başlangıç metni + açık uçlu sorular (Hafta 1: ≈150 sözcük, 6 kısa soru, G05-R1) + kendi sözleriyle anlatım |")

# ---------------------------------------------------------------- 8.9 → 8.8 için önce 8.8 sonrası eklemeler (v10 metniyle eşleşenler)
rep("İngilizce maddelerinin uzun ölçekli tekrarı ayrı sistemdir (8.9).",
    "İngilizce maddelerinin uzun ölçekli tekrarı ayrı sistemdir (8.9). Hafta 1 paketinde H2 kontrolleri 5 dk · 30 dk · 2 sa · ertesi gün olarak yazılmıştır; bir haftalık kontrol A için Gün 12, B için Gün 13'tür (isteğe bağlı) ve ilk hafta raporunda tamamlanmış gösterilmez.")
rep("Tekrar 4 | 50 gün | 83 |\n",
    "Tekrar 4 | 50 gün | 83 |\n\n"
    "**Araç:** `kayitlar/INGILIZCE_TEKRAR_TAKVIMI.xlsx` bu kuralı formülle işler: her maddenin beş satırı (öğrenme ve dört tekrar) vardır; bir sonraki planlanan tarih, bir önceki **gerçekleşen** tarih varsa ondan, yoksa bir önceki planlanan tarihten hesaplanır. Nominal tarih (gecikmesiz) ve gecikme günü ayrı sütundadır. Dosya LibreOffice ile yeniden hesaplanarak gecikme, vadesi gelen ve gecikmiş durumları için denendi; Excel ve telefon tablo uygulamalarında **denenmedi**. “Bugün” hücresi elle değiştirilebilir.\n")

# ---------------------------------------------------------------- 9.3 H5
rep("B = serbest dinleme (günler dengelenmiş)",
    "B = serbest dinleme (Hafta 1 paketinde iki farklı mini ders ve sabit sıra A→B kullanıldı; **dengeleme yapılmadı**, bu yüzden Hafta 1 karşılaştırması hüküm vermez; Hafta 2+ pratiğinde sıra farklı günlere yayılabilir)")

# ---------------------------------------------------------------- 9.5
rep("Kullanıcının kendi odasından / evinden 8–10 duraklı küçük bir güzergâh; her durağa bir öğe bağlanır; ilk gün kurulum, ikinci gün sıralı 6–8 öğeyle deneme (eğitim, test değil).",
    "Kullanıcının kendi evinden 8 duraklı (en az 6; zorlanırsa 4) küçük bir güzergâh; her durağa bir öğe bağlanır. Hafta 1 paketi: Gün 1 kurulum ve 6 öğelik eğitim listesi, Gün 2 yedi nesnelik sıralı yönerge (H1) ile deneme (eğitim, test değil).")

# ---------------------------------------------------------------- 10.2
rep("Bu yüzden **kitap, PDF / ekran ve (isteğe bağlı) ders dışı metin** hepsinde ölçülür; kayıtlar kullanıcı sayımıyla karşılaştırılır, varsayım yapılmaz.",
    "Bu yüzden **kitap, PDF / ekran ve (isteğe bağlı) ders dışı metin** hepsinde ölçülmesi hedeflenir; ancak **v11 Hafta 1 paketi dört metni tek ortamda (telefon ekranı) okutur** ve kitap/PDF karşılaştırması Hafta 2+ pratiğine bırakılmıştır (EKSIKLER.md). Kayıtlar kullanıcı sayımıyla karşılaştırılır, varsayım yapılmaz.")
rep("- 4 metin (aynı uzunluk, ≈250–300 kelime): 2 koşul × 2 metin; koşullar **ABBA** sırasıyla. Koşullar: kılavuzsuz / parmak veya cetvel.",
    "- 4 metin (aynı uzunluk): 2 koşul × 2 metin; koşullar **ABBA** sırasıyla. Koşullar: kılavuzsuz / parmak veya cetvel. Hafta 1 paketinde dört özgün Türkçe metin (`07_OKUMA_METINLERI.md`) her biri yaklaşık 155 sözcüktür (v10'daki ≈250–300 hedefinden kısa); zorluk ve uzunluk eşitliği kanıtlanmış değildir, koşul farkı metin farkıyla karışır. Her metinden sonra aynı üç genel soru sorulur.")

# ---------------------------------------------------------------- 11.7 / 11.11 / 11.13
rep("CDC / WHO haftada ≥3 gün kas-kemik güçlendirmeyi öneriyor [K25, K32].",
    "CDC / WHO haftada ≥3 gün kas-kemik güçlendirmeyi öneriyor [K25, K32]. **Hafta 1'de yüklü (dambıl / bar) çalışma yoktur;** güç hedefi vücut ağırlığıyla ve teknik odaklıdır (`04_SPOR_ILK_HAFTA.md`). Bu bölümdeki yüklü gün düzeni Hafta 2+ içindir.")
rep("Gün 1–3 hedefler zorunlu çekirdeğin yaklaşık **üçte ikisi** (her kalemde orantılı küçültme), Gün 4–7 tam çekirdek, isteğe bağlı eklenti Hafta 2'den itibaren.",
    "Hafta 1 paketi (`04_SPOR_ILK_HAFTA.md`) üç basamaklıdır: Gün 1–3 kolay başlangıç (1 set × 6 rahat tekrar, 1,5–2 km yürüyüş), Gün 4–6 bir üst basamak (rahatsa; 2 set × 6–8, 2,5–3 km), Gün 7 hafif gün önerisi (kullanıcı isterse tam çekirdek). Ek yük ve eklenti yoktur; eklenti Hafta 2'den itibaren isteğe bağlıdır.")
rep("kas dayanıklılığı: kontrollü şınav ve karın (curl-up) tekrarı, form bozulunca durarak;",
    "kas dayanıklılığı: kontrollü şınav (Hafta 1 paketinde duvar şınavı) ve karın (curl-up) tekrarı, form bozulunca durarak (pakette en çok 20);")

# ---------------------------------------------------------------- 13.2 tablo
block("| Gün | Çalışma hedefleri | Spor hedefleri (rampa) | Kayıt biçimi / alarm |\n",
      "### 13.3. Test günü yükü",
      """| Gün | Çalışma hedefleri | Spor hedefleri (rampa) | Kayıt biçimi / alarm |
| --- | --- | --- | --- |
| **0** | Telefon ayarları: pil “Kısıtlama yok”, otomatik başlatma, Saat alarmı testi; mikrofon izni; **USB-C kulaklık / mikrofon kurulumu** (Bölüm 5.2, 5.9; pakette `calisma/01_GUN_0_HAZIRLIK.md`) | — | Gün 0 doğrulama sonuçları |
| **1** | **Başlangıç anlatım kartları** (alana ilk girişte; görev sayılmaz, 4.4.3). **Eğitim öncesi başlangıç kaydı** (dersten önce): 1 kısa serbest yazı, 1 kısa sesli anlatım, 1 okuma + satır sayımı + kendi sözleriyle anlatım (kılavuzsuz). USA Learns: hesap + 1 video + 2 etkinlik + mikrofon testi. Hafıza sarayı: 8 duraklı güzergâh (en az 6) + 6 öğelik eğitim listesi. | Kolay başlangıç çekirdeği + isteğe bağlı **başlangıç gözlemi** (1,6 km yürüyüş, tek ayak denge, otur-uzan) | Elle / köprü kaydı |
| **2** | VOA Ders 1 + 3 ifade + tanışma kaydı. H1: 7 nesnelik sıralı yönerge (saray; eğitim). C0 tek görev tabanları (dinle, yaz, konuş, yerinde hareket). Dünkü güzergâhı hatırlama. İsteğe bağlı: ilk İngilizce maddeler. | Kolay başlangıç çekirdeği + isteğe bağlı kas dayanıklılığı gözlemi (duvar şınavı, karın) | Elle / köprü kaydı |
| **3** | Ana kaynak notu (üç evet/hayır sorusu, puansız) + bir etkinlik grubu. B1 tanışma (6 öğelik dikte, eğitim). G3 makalesi + **parmak/cetvel kılavuz denemesi** + kendi sözleriyle anlatım. H5 tanışma. **H6 1. dinleme** (ertesi gün için Saat alarmı). | Kolay başlangıç çekirdeği | Elle / köprü kaydı; alarm: H6 kontrol 1 |
| **4** | **H6 kontrol 1 + 2. dinleme.** İngilizce etkinlik grubu + 3 istek cümlesi; Gün 1 maddeleri kuyruğa alındıysa ilk tekrar (Gün 1 + 3). Kesinti sırasında yazma provası. Kayıt ve anahtar provası (P1, P2). Tekrar günü notu. **Test maddeleri eğitimden ayrı kilitli.** | Bir üst basamak (rahatsa) | Elle / köprü kaydı |
| **5 (Test 1)** | Yazılı İngilizce profili: serbest yazı (W1), okuma + 6 soru + anlatım (R1), çeviri (T1), isteğe bağlı kısa dil kullanımı (G1). **H2 bilgi A** (görsel kip; kontroller 5 dk · 30 dk · 2 sa; ertesi gün Gün 6, bir hafta Gün 12). **H4** çok kısa gecikme (3 deneme, ses). | Bir üst basamak | Elle / köprü kaydı; alarm: A için 5 dk, 30 dk, 2 sa |
| **6 (Test 2)** | A'nın ertesi gün kontrolü. Sesli okuma (S1) ve serbest konuşma / network başlangıç kaydı (S2). Dikte B1 (3 İngilizce hız + Türkçe kontrol; 6 öğe/dosya), İngilizce dinleme (yavaş / normal / hızlı), Türkçe dinleme kontrolü. **H2 bilgi B** (iki bilgi; kontroller 5 dk · 30 dk · 2 sa; ertesi gün Gün 7, bir hafta Gün 13 isteğe bağlı). | Bir üst basamak | Elle / köprü kaydı; alarm: B için 5 dk, 30 dk, 2 sa |
| **7 (Test 3)** | B'nin ertesi gün kontrolü. **H6 kontrol 2, 3. dinleme, kontrol 3.** Okuma sırası **A–B–B–A** (dört özgün metin, tek ortam). **H5** ders başı iki deneme (A sonra B; dengelenmedi). Kombinasyon haritası: C0 tabanları + C1 + C2 (+ C3 tanışma notu). Gün sonu paketi (ZIP, yedek). | **Hafif gün önerisi** (kullanıcı isterse tam çekirdek) | Elle / köprü kaydı |
| **8** | **H6 kontrol 4** (açmadan), sonra H6 anahtarı. Taşan test varsa. Hafta paketi: ZIP + USB-C ile Windows'a yedek (Bölüm 6.9). Hafta 1 haritasının dış değerlendiriciye verilmesi; Hafta 2 hedef kurulumu başlar. | Kartta tanımlı değil (04 kartı Gün 1–7'yi kapsar) | Son dışa aktarım tarihi |
| **12** | **A bilgisinin 1 haftalık kontrolü** (Gün 5 + 7). | Çekirdek ± eklenti | Planlanan / gerçek gecikme |
| **13** | B bilgilerinin 1 haftalık kontrolü (isteğe bağlı). | Çekirdek ± eklenti | Planlanan / gerçek gecikme |

Tablo `calisma/02_ILK_DORT_GUN.md` ve `test_gununde_ac/05_GUN5–7_GOREVLER.md` dosyalarıyla eşlenmiştir; bir çelişki görürsen paketteki dosya güncel görev metnidir. Paket dosyalarındaki `G05`, `G06`, `G07` etiketleri **Gün**dür; bu raporun G01–G26 karar kodlarıyla karıştırılmamalıdır.

""")

# ---------------------------------------------------------------- 13.6
rep("`HAFTA1\\G05\\` altında ses: `G05_T1_S03_D02_20261030-1815.m4a` (gün, görev, soru, deneme, tarih-saat)",
    "`HAFTA1\\G05\\` altında ses: `G05_T1_S03_D02_20261030-1815.m4a` (gün, görev, soru, deneme, tarih-saat; buradaki `G` **Gün**dür, karar kodu değil)")
rep("her gün “bugün vadesi gelenler” listesi çıkarılır (Bölüm 8.9) |",
    "her gün “bugün vadesi gelenler” listesi çıkarılır (Bölüm 8.9); pakette formüllü `kayitlar/INGILIZCE_TEKRAR_TAKVIMI.xlsx` vardır (yalnız LibreOffice ile denendi) |")
rep("| Hazırlık | Hafta 1 materyal paketi R9 sonrası hazırlandı. Türkçe ses üretimi ve cihaz doğrulaması eksik; paket EKSIKLER.md dosyası esas alınır |",
    "| Hazırlık | Hafta 1 materyal paketi (v11) hazır. Türkçe ve İngilizce nöral sesler üretildi ve otomatik tanıma ile geri okundu; insan dinleme kontrolü ve cihaz doğrulaması yoktur; pakette `EKSIKLER.md` esas alınır |")

# ---------------------------------------------------------------- riskler
rep("Materyal/ürün ayrımı, elle kayıt etiketi, Türkçe ses ve cihaz eksiklerinin açık listesi |",
    "Materyal/ürün ayrımı, elle kayıt etiketi, insan dinleme kontrolü ve cihaz eksiklerinin açık listesi (EKSIKLER.md) |")
insert_after_line("| RK27 |",
    "| RK28 | **Sentetik sesin doğrulanmamış kalitesi:** sesler otomatik tanıma ile kontrol edildi, bir insan dinlemedi; anlaşılmayan bir kayıt içerik zorluğu ya da işitme sorunu sanılabilir | Orta | Orta | “Anlamadım” kayıtlarının belirli dosyalarda yığılması | “Ses anlaşılmadı” ayrı işaretlenir, içeriği anlamamakla karıştırılmaz; dosya adı kaydedilir; çok kısa tekil öğelerde (sayı, sıra sözcüğü) otomatik tanımanın güvenilmez olduğu bilinir (EKSIKLER.md, 06 ses notu) |\n"
    "| RK29 | **Hafta 1 paketinde ayrıştırılamayan karışıklıklar:** dikte dosyalarında hız, sıra ve öğe birlikte değişir; H5 sırası sabittir; okuma tek ortamdadır; H6 kontrolleri aynı içeriği tekrar sınar; eğitim ve test aynı haftadadır | Yüksek | Orta | Fark görüldüğünde tek bir nedene bağlanması | Paket dosyalarında her görev için sınır yazılıdır; yorum yalnız tanımlayıcıdır (7.7, 7.8); Hafta 2+ pratiğinde sıra ve ortam yayılır |\n")

# ---------------------------------------------------------------- G21
rep("| G21 | **Kaynak ve özel üretim** | R9 ile araştırma ve gerekli özel içerik başlatıldı. Materyal hazır; otomatik kayıt yazılımı henüz yok |",
    "| G21 | **Kaynak ve özel üretim** | R9 ile araştırma ve gerekli özel içerik başlatıldı. Materyal ve nöral sentetik sesler hazır (insan dinleme kontrolü yok); otomatik kayıt yazılımı henüz yok |")

# ---------------------------------------------------------------- 16.x
rep("Çalışan kayıt yazılımı, Türkçe sesler ve kullanıcı cihazındaki doğrulama tamamlanmadı.",
    "Çalışan kayıt yazılımı ve kullanıcı cihazındaki doğrulama tamamlanmadı; sesler üretildi ama insan dinleme kontrolünden geçmedi.")
rep("Yapılanlar: resmî kaynak araştırması, ilk dört günün eğitim seçimi, dört yedek İngilizce dersi, iki özgün Türkçe okuma, spor başlangıç kartı, üç test gününün soru/anahtar ve seslendirme metinleri, İngilizce sentetik uyaranlar ve boş kayıt şablonları.",
    "Yapılanlar: resmî kaynak araştırması ve 27 Ekim 2026'da yeniden kontrolü, ilk dört günün eğitim seçimi, dört yedek İngilizce dersi, özgün okuma metinleri, spor başlangıç kartı, üç test gününün gün gün ayrı görev dosyaları, anahtarları ve seslendirme metinleri, Türkçe ve İngilizce nöral sentetik uyaranlar (otomatik tanıma ile geri okundu), formüllü İngilizce tekrar takvimi ve boş kayıt şablonları.")
rep("Tamamlanmayanlar: otomatik kayıt uygulaması; Türkçe ses dosyaları; kullanıcı cihazında teknik doğrulama;",
    "Tamamlanmayanlar: otomatik kayıt uygulaması; seslerin insan dinleme kontrolü; kullanıcı cihazında teknik doğrulama (HyperOS, Windows, tablo uygulamaları);")

# ---------------------------------------------------------------- Bölüm 17
rep("Kodlar bu belgenin her yerinde aynı kaynağı gösterir. K1–K57 önceki sürümlerde, K58–K61 v8'de incelendi. Tarih 26 Ekim 2026.",
    "Kodlar bu belgenin her yerinde aynı kaynağı gösterir. K1–K57 önceki sürümlerde, K58–K61 v8'de, K62–K72 v10'da, K73–K74 v11'de eklendi. 27 Ekim 2026'da yeniden açılan bağlantılar satırında belirtilmiştir; bir satırda bu not yoksa bağlantı v11'de yeniden açılmamıştır.")
rep("kullanıcı hesabında denenmedi. |",
    "kullanıcı hesabında denenmedi. 27 Ekim 2026'da yeniden okundu (20 ünite; akıllı telefon ve mikrofon yardım sayfası). |")
rep("gerçek cihazda indirme testi yok. |",
    "gerçek cihazda indirme testi yok. 27 Ekim 2026'da yeniden açıldı (52 ders; Ders 1 için 240p–1080p video ve 64 kbps MP3). |")
rep("Ücretsiz ders ile ücretli çevrimdışı/tekrar özellikleri ayrıldı. |",
    "Ücretsiz ders ile ücretli çevrimdışı/tekrar özellikleri ayrıldı. **27 Ekim 2026'da sayfa 403 verdi; bilgi yeniden doğrulanamadı.** Kaynak seçimi bu satıra dayanmaz. |")
rep("Sıralı bilgi için üniversite yöntem rehberi; etkililik deneyi değil; tam el ilanı çevirisi çoğaltılmadı. |",
    "Sıralı bilgi için üniversite yöntem rehberi (lisans: CC BY-NC-ND 4.0); etkililik deneyi değil; çeviri veya uyarlama çoğaltılmadı, yalnız bağlantı ve kendi cümlelerimle yönerge verilir. 27 Ekim 2026'da yeniden açıldı. |")
rep("Dört beceri 90 dakika; okuma/dinleme 50 dakika. İsteğe bağlı dış ölçüm. |",
    "Dört beceri 90 dakika; okuma/dinleme 50 dakika. İsteğe bağlı dış ölçüm. 27 Ekim 2026'da yeniden açıldı. |")
rep("kişisel yük reçetesi değil. |",
    "kişisel yük reçetesi değil. 27 Ekim 2026'da PDF metni yeniden okundu. |")
rep("çalışma belleği oyunlarından geniş beceriye aktarım otomatik kabul edilmez. |",
    "çalışma belleği oyunlarından geniş beceriye aktarım otomatik kabul edilmez. Bu bağlantı v11 hazırlığında yeniden açılmadı. |")
insert_after_line("| K72 |",
    "| K73 | Brain Workshop: https://brainworkshop.sourceforge.net/ | Ücretsiz açık kaynak dual n-back (Windows, Mac, Linux). 27 Ekim 2026'da açıldı. Günlük unutkanlık için ana çözüm yapılmadı; çalışma belleği antrenmanından geniş aktarım için bkz. K20, K71. |\n"
    "| K74 | Piper nöral konuşma sentezi ve ses modeli kartları: https://huggingface.co/rhasspy/piper-voices | Hafta 1 sesleri bu modellerle üretildi. Model kartlarında bildirilen lisanslar: kristin ve ljspeech kamu malı, joe CC0, Türkçe dfki CC BY-NC-SA 4.0 (yalnız kişisel, ticari olmayan kullanım). Kartlar ses seçimi sırasında okundu. Lisansı kuran taraf bu rapor değildir; sesler gerçek bir kişinin sesi olarak sunulmaz. |\n")
rep("- K62 yalnız arama özetlerine dayanır;",
    "- K66 ve K71 için v11'de doğrulama yapılamadı (Busuu sayfası 403; Melby-Lervåg bağlantısı açılmadı).\n- K62 yalnız arama özetlerine dayanır;")

# ---------------------------------------------------------------- Bölüm 18
rep("Bu yüzden bu aşamada **geliştirme değil, doğru anlama, bağımsız analiz ve gerekli sorular** isteniyor.",
    "Bu yüzden bu aşamada **geliştirme değil, doğru anlama, bağımsız analiz ve gerekli sorular** isteniyor. (v11 notu: R9'dan sonra kaynak araştırması ve ilk hafta içerik üretimi kullanıcı talimatıyla başlatıldı; değerlendirici bu raporu paketteki `09_DEGISIKLIK_VE_HATA_RAPORU.md` ve `EKSIKLER.md` ile birlikte okur. Bu paragraf ilk değerlendirme turunun rolünü anlatır, üretim işini durdurmaz.)")

# ---------------------------------------------------------------- Ek A
rep("U1–U11 raporun ilk derlemesi öncesi mesajlardır; R0–R8 bu derlemeden sonraki mesajlardır.",
    "U1–U11 raporun ilk derlemesi öncesi mesajlardır; R0–R10 bu derlemeden sonraki mesajlardır.")
rep("### U-mesajları (ilk derleme öncesi)",
    """**R10 — v11 hata analizi ve düzeltme talimatı (27 Ekim 2026)**
> Hepsini oku hataları analiz edip gider daha profesyonel hale getir sorunları çöz o 220 kb galiba o Md dosyasına bakarak guncellersin mantıksal hataları giderrirsin sorunları çözersin sistem sorunları daha profesyonel yapılandırma vs. Vs. Hepsini kapsayan bir çalışma yaparsın kodları hem düzenleyip hataları giderdikten sonra raporla zip dosyasını hepsini teker teker eksiksiz şekilde analiz etmen şart eğer sorularin olursa kesinlikle sorabilirsin eğer yoksa ana gayeye göre yapilandirirsin

(R10 ile birlikte bir ZIP paket eklendi. Mesajda soru zorunlu tutulmadı; sorular gerekmediği için sorulmadı, varsayımlar `09_DEGISIKLIK_VE_HATA_RAPORU.md` içinde yazılıdır.)

### U-mesajları (ilk derleme öncesi)""")

# ---------------------------------------------------------------- Ek C
T = T.rstrip("\n") + "\n"
T += ("| **v11** | 27 Ekim 2026 | v10 raporu ve ilk hafta paketinin hata analizi. Rapor: sürüm/tarih; 0.1; Bölüm 8.8 numarası (8.8 boşluğu kapatıldı, tüm göndermeler güncellendi); 13.2 gün tablosu paketle eşlendi (Gün 12–13 dahil); 7.8, 9.3, 9.5, 10.2, 11.7, 11.11, 11.13 düzeltmeleri; RK28–RK29; G21; K63–K74 notları; Ek A R10; D39 “Q2” göndermesi düzeltildi; Türkçe sesler artık üretilmiş ama insan dinleme kontrolünden geçmemiş olarak yazıldı. Paket: Gün 5–7 görev ve anahtar dosyaları ayrıldı, sesler yeniden üretilip bağımsız modelle doğrulandı, İngilizce tekrar takvimi (xlsx), manifest ve SHA-256 özetleri, dürüst eksikler listesi. Ayrıntı: `09_DEGISIKLIK_VE_HATA_RAPORU.md`. |\n\n"
      "Not: Eski sürüm satırlarındaki “Q1–Q9” gibi etiketler o sürümün soru numaralarıdır; v10'dan itibaren kullanılmaz. Kalıcı kodlar D, G, T, RK, V, K ve R'dir. Bölüm 8.8'e yapılan göndermeler, eski sürümlerde “§§89§§” olarak yazılmıştır.\n")

# ---------------------------------------------------------------- 8.9 -> 8.8 (sonda, genel)
before = len(re.findall(r"(?<![0-9.])8\.9(?![0-9])", T))
T = re.sub(r"(?<![0-9.])8\.9(?![0-9])", "8.8", T)
assert before >= 19, before
assert "### 8.8. İngilizce tekrar kuralı" in T
T = T.replace("§§89§§", "8.9")
assert "§§" not in T

open(dst, "w", encoding="utf-8").write(T)
print("tamam:", len(LOG), "yama; 8.9→8.8:", before, "gönderme;", len(T), "karakter")
