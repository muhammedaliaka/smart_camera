"""Tek sözcük/ifade adaylarının ASR çıktısını ham olarak gösterir (teşhis). Kullanım: python probe_words.py <voices_dir> <out_dir> <voice> <ls> <metin> [<metin>...]"""
import sys
voices_dir, out_dir, vk, ls = sys.argv[1], sys.argv[2], sys.argv[3], float(sys.argv[4])
texts = sys.argv[5:]
HERE = __file__.rsplit("/", 1)[0]
head = open(f"{HERE}/gen_audio2.py", encoding="utf-8").read().split("random.seed(11)")[0]
sys.argv = [__file__, voices_dir, out_dir, "1"]
exec(compile(head, "gen_audio2_head", "exec"))
CAR = {"en": "The answer is", "tr": "Cevap şu"}
lang, sr = LANG[vk], voice(vk).config.sample_rate
car = np.concatenate([synth_once(vk, CAR[lang], 1.0), silence(sr, 0.15)])
def tr(model, arr):
    x = arr.astype(np.float32) / 32768.0
    if sr != 16000:
        n = int(len(x) * 16000 / sr)
        x = np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x).astype(np.float32)
    x = np.concatenate([np.zeros(3200, np.float32), x, np.zeros(3200, np.float32)])
    segs, _ = model.transcribe(x, language=lang, beam_size=5, condition_on_previous_text=False, temperature=0.0, max_new_tokens=40, without_timestamps=True)
    return " ".join(s.text.strip() for s in segs)
for t in texts:
    print("==", t, flush=True)
    for i in range(8):
        a = synth_once(vk, t, ls)
        print("  ", i, "|", tr(asr, np.concatenate([car, a])), "|", tr(asr, np.concatenate([silence(sr, 0.4), a])), flush=True)
