"""INGILIZCE_TEKRAR_TAKVIMI.xlsx üretir (openpyxl, formüllü). Kullanım: python build_xlsx.py <çıktı.xlsx>"""
import sys, datetime as dt
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.formatting.rule import FormulaRule
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.utils import get_column_letter

OUT = sys.argv[1]
N_BLOCKS = 60                       # 60 madde x 5 satır = 300 satır
HEAD = ["madde_id", "icerik", "anlam", "kendi_ornegim", "ogrenme_tarihi", "adim", "bekleme_gun",
        "planlanan_tarih", "gerceklesen_tarih", "ilk_yanit", "anahtar_durumu", "yardimlar",
        "ek_karsilasma_notu", "nominal_tarih", "gecikme_gun", "durum"]
GAPS = [None, 3, 10, 20, 50]
CUM = [0, 3, 13, 33, 83]
DATE_FMT = "dd.mm.yyyy"

F_IN = PatternFill("solid", fgColor="FFF8DC")      # girdi
F_CALC = PatternFill("solid", fgColor="EDEDED")    # formül
F_HEAD = PatternFill("solid", fgColor="1F3864")
F_ORN = PatternFill("solid", fgColor="F8CBAD")
thin = Side(style="thin", color="BFBFBF")
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)


def build_sheet(ws, n_blocks, example=None, hr=1):
    for c, h in enumerate(HEAD, 1):
        ws.cell(row=hr, column=c, value=h)
    for c in range(1, len(HEAD) + 1):
        cell = ws.cell(row=hr, column=c)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = F_HEAD
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    last = hr + n_blocks * 5
    for b in range(n_blocks):
        r0 = hr + 1 + b * 5
        for k in range(5):
            r = r0 + k
            ws.cell(r, 6, k)                                              # adim
            if k == 0:
                ws.cell(r, 8, f'=IF(E{r}="","",E{r})')
                ws.cell(r, 9, f'=IF(E{r}="","",E{r})')
                ws.cell(r, 14, f'=IF(E{r}="","",E{r})')
            else:
                ws.cell(r, 1, f'=IF($A${r0}="","",$A${r0})')
                ws.cell(r, 2, f'=IF($B${r0}="","",$B${r0})')
                ws.cell(r, 3, f'=IF($C${r0}="","",$C${r0})')
                ws.cell(r, 4, f'=IF($D${r0}="","",$D${r0})')
                ws.cell(r, 5, f'=IF($E${r0}="","",$E${r0})')
                ws.cell(r, 7, GAPS[k])
                p = r - 1
                ws.cell(r, 8, f'=IF($E${r0}="","",IF(ISNUMBER(I{p}),I{p},H{p})+G{r})')
                ws.cell(r, 14, f'=IF($E${r0}="","",$E${r0}+{CUM[k]})')
                ws.cell(r, 15, f'=IF(AND(ISNUMBER(I{r}),ISNUMBER(H{r})),I{r}-H{r},"")')
                ws.cell(r, 16, f'=IF(ISNUMBER(I{r}),"yapıldı",IF(H{r}="","",IF(H{r}<BUGUN,"vadesi geçti",IF(H{r}=BUGUN,"bugün","bekliyor"))))')
            for c in range(1, 17):
                cell = ws.cell(r, c)
                cell.border = BORDER
                calc = (k == 0 and c in (6, 8, 9, 14)) or (k > 0 and c in (1, 2, 3, 4, 5, 6, 7, 8, 14, 15, 16))
                cell.fill = F_CALC if calc else F_IN
                if c in (5, 8, 9, 14):
                    cell.number_format = DATE_FMT
            if k == 0:
                for c in range(1, 17):
                    ws.cell(r, c).font = Font(bold=True)
    widths = [10, 24, 24, 30, 14, 6, 9, 14, 14, 24, 20, 14, 30, 14, 9, 14]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.row_dimensions[hr].height = 32
    ws.freeze_panes = f"B{hr + 1}"
    ws.auto_filter.ref = f"A{hr}:P{last}"
    # doğrulamalar
    dv_d = DataValidation(type="date", operator="greaterThanOrEqual", formula1="DATE(2026,1,1)", allow_blank=True,
                          showErrorMessage=True, errorTitle="Tarih", error="Geçerli bir tarih yaz (gg.aa.yyyy).")
    dv_k = DataValidation(type="list", formula1='"kapali,elle acildi,ucuncu gonderimde acildi"', allow_blank=True,
                          showErrorMessage=True, errorTitle="Anahtar durumu", error="Listeden seç.")
    ws.add_data_validation(dv_d); ws.add_data_validation(dv_k)
    for b in range(n_blocks):
        r0 = hr + 1 + b * 5
        dv_d.add(f"E{r0}")
        dv_d.add(f"I{r0 + 1}:I{r0 + 4}")
        dv_k.add(f"K{r0 + 1}:K{r0 + 4}")
    red = PatternFill("solid", bgColor="F4B084"); yel = PatternFill("solid", bgColor="FFE699"); grn = PatternFill("solid", bgColor="C6E0B4")
    f0 = hr + 1
    rng = f"P{f0}:P{last}"
    ws.conditional_formatting.add(rng, FormulaRule(formula=[f'$P{f0}="vadesi geçti"'], fill=red))
    ws.conditional_formatting.add(rng, FormulaRule(formula=[f'$P{f0}="bugün"'], fill=yel))
    ws.conditional_formatting.add(rng, FormulaRule(formula=[f'$P{f0}="yapıldı"'], fill=grn))
    if example:
        for (r, c, v) in example:
            ws.cell(r, c, v)


wb = Workbook()

# ---------------------------------------------------------------- Aciklama
ws = wb.active
ws.title = "Aciklama"
ws["A1"] = "İngilizce tekrar takvimi — nasıl kullanılır"
ws["A1"].font = Font(bold=True, size=14)
ws["A3"] = "Bugünün tarihi (boş bırakırsan bilgisayarın tarihi kullanılır):"
ws["B3"].fill = F_IN; ws["B3"].number_format = DATE_FMT; ws["B3"].border = BORDER
ws["A4"] = "Kullanılan tarih (formül):"
ws["B4"] = '=IF(ISNUMBER(B3),B3,TODAY())'
ws["B4"].number_format = DATE_FMT; ws["B4"].fill = F_CALC; ws["B4"].border = BORDER
ws.column_dimensions["A"].width = 70
ws.column_dimensions["B"].width = 16
ws.column_dimensions["C"].width = 70
lines = [
    "",
    "Bu dosya İngilizce madde tekrarlarının planlanan ve gerçekleşen tarihlerini tutar. Sistem yalnız kaydeder; puan ya da doğru/yanlış hükmü vermez.",
    "",
    "KURAL (R9): Öğrenme → 3 gün sonra Tekrar 1 → 10 gün sonra Tekrar 2 → 20 gün sonra Tekrar 3 → 50 gün sonra Tekrar 4.",
    "Gecikme yoksa öğrenmeye göre günler 3, 13, 33 ve 83'tür. Tekrar geciktiyse sonraki aralık GERÇEKLEŞEN tarihten başlar (benim seçtiğim kural).",
    "",
    "TAKVİM sayfası: her madde için 5 satırlık bir blok vardır (adım 0 = öğrenme, adım 1–4 = tekrarlar).",
    "  1) Bloğun ilk satırına (kalın) madde_id, icerik, anlam, kendi_ornegim ve ogrenme_tarihi yaz. Gerisi hesaplanır.",
    "  2) Bir tekrarı yaptığında o satırın gerceklesen_tarih hücresine tarihi yaz. Sonraki tekrarın planlanan_tarih'i otomatik güncellenir.",
    "  3) ilk_yanit (anahtara bakmadan ilk yanıtın, aynen), anahtar_durumu, yardimlar (A0–A4) ve not hücrelerini elle doldur.",
    "  Sarı hücreler girdidir, gri hücreler formüldür; formülleri silme.",
    "  nominal_tarih: gecikme olmasaydı tarih. gecikme_gun: gerçekleşen − planlanan. durum: yapıldı / vadesi geçti / bugün / bekliyor.",
    "  Planlanan tarih hiç silinmez; gerçekleşen tarih ayrı sütundadır.",
    "",
    "YUK sayfası: önümüzdeki 60 günde her gün kaç tekrar vadesi geliyor ve kaç yeni madde eklendi; ayrıca gecikmesiz kararlı yük tablosu.",
    "ORNEK sayfası: gecikmenin nasıl işlediğini gösteren GERÇEK OLMAYAN örnek. Kendi verini oraya yazma.",
    "",
    "CSV ile ilişki: TAKVİM sayfasının A–M sütunları INGILIZCE_TEKRAR.csv başlığıyla aynıdır; N–P hesaplanan ek sütunlardır. Bir maddeyi iki yerde tutma; esas kayıt bu dosyadır.",
    "",
    "SINIRLAR: Formüller LibreOffice ile bir geçici kopyada yeniden hesaplanarak denendi; Excel ve telefon tablo uygulamalarında denenmedi.",
    "Tek bir madde Anki ile bu takvime aynı anda bağlanmaz. Kararlı yük, günde N yeni madde için en çok 4N tekrar/gün olur (bkz. YUK sayfası).",
    "Testte kullanılan kilitli maddeler eğitim kuyruğuna otomatik eklenmez.",
]
for i, t in enumerate(lines, start=6):
    ws.cell(i, 1, t)
    ws.cell(i, 1).alignment = Alignment(wrap_text=False)
wb.defined_names["BUGUN"] = DefinedName("BUGUN", attr_text="Aciklama!$B$4")

# ---------------------------------------------------------------- Takvim
wt = wb.create_sheet("Takvim")
build_sheet(wt, N_BLOCKS)

# ---------------------------------------------------------------- Yuk
wy = wb.create_sheet("Yuk")
wy["A1"] = "Tekrar yükü"
wy["A1"].font = Font(bold=True, size=14)
wy["A3"] = "Günde yeni madde sayısı N (hesap için):"
wy["B3"] = 3; wy["B3"].fill = F_IN; wy["B3"].border = BORDER
wy["A5"] = "Kararlı yük (gecikmesiz) — 0 tabanlı gün d"
wy["A5"].font = Font(bold=True)
for j, h in enumerate(["d ≥", "çarpan", "tekrar/gün"], start=1):
    wy.cell(6, j, h).font = Font(bold=True)
for i, (d, m) in enumerate([(0, 0), (3, 1), (13, 2), (33, 3), (83, 4)], start=7):
    wy.cell(i, 1, d); wy.cell(i, 2, m); wy.cell(i, 3, f"=$B$3*B{i}")
wy["A13"] = "Aralıkların uzaması günlük üst sınırı (4N) yarıya indirmez; yük yeni madde girişi durunca azalır."
wy["A15"] = "Önümüzdeki 60 gün (Takvim sayfasından)"
wy["A15"].font = Font(bold=True)
for j, h in enumerate(["tarih", "vadesi gelen tekrar (yapılmamış)", "yeni öğrenilen madde", "vadesi geçmiş birikmiş (o güne dek)"], start=1):
    c = wy.cell(16, j, h); c.font = Font(bold=True); c.alignment = Alignment(wrap_text=True)
last = 1 + N_BLOCKS * 5
for i in range(60):
    r = 17 + i
    wy.cell(r, 1, f"=BUGUN+{i}").number_format = DATE_FMT
    wy.cell(r, 2, f"=SUMPRODUCT((Takvim!$H$2:$H${last}=A{r})*(Takvim!$F$2:$F${last}>=1)*(Takvim!$I$2:$I${last}=\"\"))")
    wy.cell(r, 3, f"=SUMPRODUCT((Takvim!$F$2:$F${last}=0)*(Takvim!$E$2:$E${last}=A{r}))")
    wy.cell(r, 4, f"=SUMPRODUCT(ISNUMBER(Takvim!$H$2:$H${last})*(Takvim!$H$2:$H${last}<A{r})*(Takvim!$F$2:$F${last}>=1)*(Takvim!$I$2:$I${last}=\"\"))")
for col, w in zip("ABCD", (44, 26, 22, 30)):
    wy.column_dimensions[col].width = w
wy.row_dimensions[16].height = 32

# ---------------------------------------------------------------- Ornek
wo = wb.create_sheet("Ornek")
ex = [
    (3, 1, "ORNEK-1"), (3, 2, "tomorrow"), (3, 3, "yarın"), (3, 4, "I will call you tomorrow."), (3, 5, dt.date(2026, 11, 1)),
    (4, 9, dt.date(2026, 11, 6)), (4, 10, "(örnek) tomorrow = yarın"), (4, 11, "kapali"), (4, 12, "A0"),
    (4, 13, "ÖRNEK: 2 gün geç yapıldı"),
    (8, 1, "ORNEK-2"), (8, 2, "borrow"), (8, 3, "ödünç almak"), (8, 4, "Can I borrow a pen?"), (8, 5, dt.date(2026, 11, 2)),
    (9, 9, dt.date(2026, 11, 5)), (9, 12, "A0"),
    (10, 9, dt.date(2026, 11, 15)), (10, 12, "A0 A2"),
]
build_sheet(wo, 2, example=ex, hr=2)
wo["A1"] = "ÖRNEK — GERÇEK VERİ DEĞİL. Yalnız gecikmenin nasıl işlediğini gösterir; kendi maddelerini TAKVİM sayfasına yaz."
wo["A1"].font = Font(bold=True, color="C00000", size=12)
wo["A1"].fill = F_ORN
wo.freeze_panes = "B3"
wb.save(OUT)
print("saved", OUT)
