import re, sys, io

p = sys.argv[1]
t = io.open(p, encoding="utf-8").read()
lines = t.split("\n")

# 1. headings
heads = set()
for ln in lines:
    m = re.match(r"^(#{2,3}) (\d+(?:\.\d+)?[a-z]?)\. ", ln)
    if m:
        heads.add(m.group(2))
    m2 = re.match(r"^## (\d+)\. ", ln)
    if m2:
        heads.add(m2.group(1))
# sub-sub (4.4.1 etc.) are bold labels, collect them too
for m in re.finditer(r"\*\*(\d+\.\d+\.\d+)\. ", t):
    heads.add(m.group(1))

refs = set(re.findall(r"Bölüm(?:ler)? (\d+(?:\.\d+){0,2}[a-z]?)", t))
refs |= set(re.findall(r"\((?:Bölüm )?(\d+\.\d+[a-z]?)(?:[,)])", t))
missing = sorted(r for r in refs if r not in heads and r.rstrip("abcdefgh") not in heads)
print("missing section refs:", missing)

# 2. tables
bad = 0
i = 0
while i < len(lines):
    if lines[i].startswith("|"):
        j = i
        blk = []
        while j < len(lines) and lines[j].startswith("|"):
            blk.append(lines[j]); j += 1
        n0 = len(re.findall(r"(?<!\\)\|", blk[0])) - 1
        for k, b in enumerate(blk):
            n = len(re.findall(r"(?<!\\)\|", b)) - 1
            if n != n0:
                bad += 1
                print("table col mismatch near line", i + k + 1, n, "vs", n0, b[:80])
        i = j
    else:
        i += 1
print("table problems:", bad)

# 3. code definitions vs usage
def defined(prefix, width, rng):
    out = set()
    for ln in lines:
        m = re.match(r"^\| \*{0,2}%s(\d+)\*{0,2} \|" % prefix, ln)
        if m:
            out.add(int(m.group(1)))
    return out

for prefix in ["D", "G", "RK", "T", "K", "V"]:
    d = defined(prefix, 2, None)
    used = set(int(x) for x in re.findall(r"(?<![A-Za-z0-9])%s(\d{1,3})(?![0-9A-Za-z])" % prefix, t))
    undefined = sorted(u for u in used if u not in d)
    gaps = [x for x in range(1, max(d) + 1) if x not in d] if d else []
    print(prefix, "defined:", (min(d), max(d), len(d)) if d else None, "gaps:", gaps, "used-but-undefined:", undefined)

# 4. stale phrases
for pat in ["Q1–Q2", "Q2 cevab", "gerçek partner varsa", "4 haftada bir", "Dört haftalık aralıkla", "yeniden haritalarda", "G01–G21", "2 yeni soru", "(v8)"]:
    hits = [i + 1 for i, ln in enumerate(lines) if pat in ln]
    print("stale?", pat, hits)

print("lines:", len(lines))
