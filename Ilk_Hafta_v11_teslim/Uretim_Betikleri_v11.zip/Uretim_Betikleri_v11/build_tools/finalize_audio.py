"""Nihai sesleri pakete yerleştirir, ses_manifest.json üretir ve 06_SES_VE_LISANS_NOTU.md tablosunu doldurur.
Kullanım: python3 -I finalize_audio.py <SP> <paket_kökü> <verify_json> [<verify_small_json>]
Ön koşul: <SP>/audio_final içinde 26 mp3 + results.json (nihai dikte dosyaları merge_audio.py ile alınmış olmalı)
ve <SP>/build_tools/audio_texts.py bulunmalı (betikler <SP>/build_tools altında durur)."""
import hashlib
import json
import os
import shutil
import sys

SP, PKG, VER = sys.argv[1], sys.argv[2], sys.argv[3]
VER_SMALL = sys.argv[4] if len(sys.argv) > 4 else None
sys.path.insert(0, f"{SP}/build_tools")
import audio_texts as T  # noqa: E402

AF = f"{SP}/audio_final"
ORD_EN = ["First.", "Second.", "Third.", "Fourth.", "Fifth.", "Sixth."]
ORD_TR = ["Birinci.", "İkinci.", "Üçüncü.", "Dördüncü.", "Beşinci.", "Altıncı."]

# kaynak ad -> (hedef klasör, hedef dosya adı)
MAP = {
    "C0_T": ("calisma/ses", "G02_C0_dinleme"),
    "DK_T": ("calisma/ses", "G03_B1_dikte_tanisma"),
    "H5_T": ("calisma/ses", "G03_H5_tanisma"),
    "H6": ("calisma/ses", "H6_dinleme_G03_G04_G07"),
    "H4_1": ("test_gununde_ac/ses/gun5", "G05_H4_1"),
    "H4_2": ("test_gununde_ac/ses/gun5", "G05_H4_2"),
    "H4_3": ("test_gununde_ac/ses/gun5", "G05_H4_3"),
    "EN_A_normal": ("test_gununde_ac/ses/gun6", "EN_A_normal"),
    "EN_B_yavas": ("test_gununde_ac/ses/gun6", "EN_B_yavas"),
    "EN_C_hizli": ("test_gununde_ac/ses/gun6", "EN_C_hizli"),
    "TR_L": ("test_gununde_ac/ses/gun6", "TR_L"),
    "DK_A": ("test_gununde_ac/ses/gun6", "G06_B1_dikte_1"),
    "DK_B": ("test_gununde_ac/ses/gun6", "G06_B1_dikte_2"),
    "DK_C": ("test_gununde_ac/ses/gun6", "G06_B1_dikte_3"),
    "DK_TR": ("test_gununde_ac/ses/gun6", "G06_B1_dikte_TR"),
    "H5_A": ("test_gununde_ac/ses/gun7", "G07_H5_1"),
    "H5_B": ("test_gununde_ac/ses/gun7", "G07_H5_2"),
    "C_A": ("test_gununde_ac/ses/gun7", "G07_C0_dinleme"),
    "C_B": ("test_gununde_ac/ses/gun7", "G07_C1"),
    "C_C": ("test_gununde_ac/ses/gun7", "G07_C2"),
    "EN_A_yavas": ("test_gununde_ac/ses/sonradan_calisma", "EN_A_yavas"),
    "EN_A_hizli": ("test_gununde_ac/ses/sonradan_calisma", "EN_A_hizli"),
    "EN_B_normal": ("test_gununde_ac/ses/sonradan_calisma", "EN_B_normal"),
    "EN_B_hizli": ("test_gununde_ac/ses/sonradan_calisma", "EN_B_hizli"),
    "EN_C_yavas": ("test_gununde_ac/ses/sonradan_calisma", "EN_C_yavas"),
    "EN_C_normal": ("test_gununde_ac/ses/sonradan_calisma", "EN_C_normal"),
}
LICENCE = {
    "en_US-kristin": "kamu malı (model kartı)",
    "en_US-ljspeech": "kamu malı (model kartı)",
    "en_US-joe": "CC0 (model kartı)",
    "tr_TR-dfki": "CC BY-NC-SA 4.0 — yalnız kişisel, ticari olmayan kullanım (model kartı)",
}

# beklenen metinler (doğrulama ile aynı kurallar)
exp = {}
for tid, (sp, vk, text) in T.EN.items():
    for lab in T.SPEEDS:
        exp[f"{tid.replace('-', '_')}_{lab}"] = text
for tid, text in T.TR.items():
    exp[tid.replace("-", "_")] = text
for tid, items in T.DK_EN.items():
    exp[tid.replace("-", "_")] = " ".join(f"{ORD_EN[i]} {it}" for i, it in enumerate(items))
for tid, items in T.DK_TR.items():
    exp[tid.replace("-", "_")] = " ".join(f"{ORD_TR[i]} {it}" for i, it in enumerate(items))

res = {r["file"].rsplit(".", 1)[0]: r for r in json.load(open(f"{AF}/results.json", encoding="utf-8"))}
ver = json.load(open(VER, encoding="utf-8"))
ver_s = json.load(open(VER_SMALL, encoding="utf-8")) if VER_SMALL else {}
assert set(MAP) == set(res) == set(ver) == set(exp), (set(MAP) ^ set(res), set(ver) ^ set(MAP))


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for ch in iter(lambda: f.read(1 << 20), b""):
            h.update(ch)
    return h.hexdigest()


entries = []
for src, (d, dst) in MAP.items():
    os.makedirs(f"{PKG}/{d}", exist_ok=True)
    out = f"{PKG}/{d}/{dst}.mp3"
    shutil.copyfile(f"{AF}/{src}.mp3", out)
    r = res[src]
    e = dict(
        path=f"{d}/{dst}.mp3",
        text_id=r["text_id"],
        language=r["language"],
        engine="Piper (nöral, ONNX)",
        voice=r["voice"],
        licence=LICENCE[r["voice"]],
        length_scale=r.get("length_scale"),
        target_wpm=r.get("target_wpm"),
        wpm_total=r.get("wpm_total"),
        speed_label=r.get("speed_label"),
        duration_seconds=r["duration_seconds"],
        loudness_lufs=r["loudness_lufs"],
        true_peak_dbfs=r["true_peak_dbfs"],
        asr_similarity_medium=ver[src]["similarity"],
        asr_similarity_small=ver_s.get(src, {}).get("similarity"),
        size_bytes=os.path.getsize(out),
        sha256=sha(out),
        text_sha256=hashlib.sha256(exp[src].encode("utf-8")).hexdigest(),
        synthetic=True,
        human_listening_qa=False,
    )
    entries.append({k: v for k, v in e.items() if v is not None})

man = dict(
    kind="stimulus_material_not_user_results",
    prepared_on="2026-10-27",
    human_listening_qa=False,
    on_device_tested=False,
    asr_check=("Dosyalar mp3'ten okunup faster-whisper 'medium' ile yazıya çevrildi; benzerlik, beklenen metinle "
               "difflib.SequenceMatcher (autojunk=False) oranıdır. Bu bir anlaşılabilirlik ölçüsü değildir; "
               "ASR güvenilir olmayan kısa tekil öğeler vardır (EKSIKLER.md, 06_SES_VE_LISANS_NOTU.md)."),
    files=entries,
)
os.makedirs(f"{PKG}/test_gununde_ac/ses", exist_ok=True)
with open(f"{PKG}/test_gununde_ac/ses/ses_manifest.json", "w", encoding="utf-8") as f:
    json.dump(man, f, ensure_ascii=False, indent=1)
print("yerleştirildi:", len(entries), "mp3; ses_manifest.json yazıldı")

# 06 notundaki tablo
rows = ["| Dosya | Dil · ses | Hız (toplam sözcük/dk) | Süre (sn) | Ses düzeyi (LUFS) | Otomatik tanıma benzerliği (medium) |",
        "| --- | --- | --- | --- | --- | --- |"]
for e in sorted(entries, key=lambda x: x["path"]):
    wpm = e.get("wpm_total")
    spd = f"{wpm}" if wpm else (e.get("speed_label") or "—")
    rows.append(f"| `{e['path']}` | {e['language'].upper()} · {e['voice']} | {spd} | {e['duration_seconds']:.1f} | "
                f"{e['loudness_lufs']} | {e['asr_similarity_medium']:.3f} |")
note_path = f"{PKG}/test_gununde_ac/06_SES_VE_LISANS_NOTU.md"
note = open(note_path, encoding="utf-8").read()
assert note.count("{{TABLO}}") == 1
open(note_path, "w", encoding="utf-8").write(note.replace("{{TABLO}}", "\n".join(rows)))
print("06 notu tablosu dolduruldu")
