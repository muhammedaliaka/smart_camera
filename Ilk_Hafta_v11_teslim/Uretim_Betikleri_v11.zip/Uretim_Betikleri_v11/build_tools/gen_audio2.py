"""Ses üretimi v2: Piper (nöral) + cümle başına en iyi-N seçimi (ASR geri okuma ile) -> loudnorm (2 geçiş) -> mp3.
Kullanım: python gen_audio2.py <voices_dir> <out_dir> [K] [yalnız_şu_çıktılar]
  yalnız_şu_çıktılar: virgülle ayrılmış çıktı adları (ör. TR_L,EN_A_normal); verilmezse hepsi üretilir.
NOT: Dikte dosyaları (DK_*) nihai pakette regen_dictation2.py ile üretildi; buradaki DK üretimi eski sürümdür.
"""
import difflib, json, random, re, subprocess, sys, unicodedata, wave
import numpy as np
from faster_whisper import WhisperModel
from piper import PiperVoice, SynthesisConfig

sys.path.insert(0, __file__.rsplit("/", 1)[0])
import audio_texts as T

VOICES_DIR, OUT = sys.argv[1], sys.argv[2]
import os
os.makedirs(OUT, exist_ok=True)  # çıkış klasörü yoksa oluştur
K = int(sys.argv[3]) if len(sys.argv) > 3 else 5
VOICE_FILES = {"kristin": "en_US-kristin-medium.onnx", "joe": "en_US-joe-medium.onnx",
               "ljspeech": "en_US-ljspeech-high.onnx", "dfki": "tr_TR-dfki-medium.onnx"}
LANG = {"kristin": "en", "joe": "en", "ljspeech": "en", "dfki": "tr"}
NOISE, NOISE_W = 0.5, 0.6          # daha kararlı telaffuz
_voices = {}
asr = WhisperModel("small", device="cpu", compute_type="int8")


def voice(k):
    if k not in _voices:
        _voices[k] = PiperVoice.load(f"{VOICES_DIR}/{VOICE_FILES[k]}")
    return _voices[k]


# ---------- metin normalleştirme (ASR karşılaştırması için) ----------
EN_ONES = "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen".split()
EN_TENS = "_ _ twenty thirty forty fifty sixty seventy eighty ninety".split()
TR_ONES = "sıfır bir iki üç dört beş altı yedi sekiz dokuz".split()
TR_TENS = "_ on yirmi otuz kırk elli altmış yetmiş seksen doksan".split()


def num_en(n):
    if n < 20: return EN_ONES[n]
    t, o = divmod(n, 10)
    return EN_TENS[t] + ("" if o == 0 else " " + EN_ONES[o])


def num_tr(n):
    if n < 10: return TR_ONES[n]
    t, o = divmod(n, 10)
    return TR_TENS[t] + ("" if o == 0 else " " + TR_ONES[o])


def norm(s, lang):
    s = unicodedata.normalize("NFC", s).lower()
    s = s.replace("-", " ")
    s = re.sub(r"\b(\d{1,2})(st|nd|rd|th)\b", lambda m: num_en(int(m.group(1))), s)
    s = re.sub(r"\b\d{1,2}\b", lambda m: (num_en if lang == "en" else num_tr)(int(m.group(0))), s)
    s = re.sub(r"[^\w\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def similarity(a, b, lang):
    return difflib.SequenceMatcher(None, norm(a, lang), norm(b, lang)).ratio()


def transcribe(arr_int16, sr, lang):
    x = arr_int16.astype(np.float32) / 32768.0
    if sr != 16000:
        n = int(len(x) * 16000 / sr)
        x = np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x).astype(np.float32)
    x = np.concatenate([np.zeros(3200, np.float32), x, np.zeros(3200, np.float32)])
    segs, _ = asr.transcribe(x, language=lang, beam_size=5, condition_on_previous_text=False)
    return " ".join(s.text.strip() for s in segs)


# ---------- sentez ----------
def synth_once(vkey, text, ls):
    cfg = SynthesisConfig(length_scale=ls, noise_scale=NOISE, noise_w_scale=NOISE_W)
    parts = [c.audio_int16_array for c in voice(vkey).synthesize(text, cfg)]
    return np.concatenate(parts) if parts else np.zeros(0, np.int16)


_best_cache = {}
LOG = []


def synth_best(vkey, text, ls, k=K):
    """K aday üret, ASR ile en iyi benzerliği seç (eşitlikte süresi medyana yakın olanı)."""
    key = (vkey, text, round(ls, 3))
    if key in _best_cache:
        return _best_cache[key]
    lang, sr = LANG[vkey], voice(vkey).config.sample_rate
    cands = []
    for _ in range(k):
        a = synth_once(vkey, text, ls)
        sc = similarity(text, transcribe(a, sr, lang), lang)
        cands.append((sc, a))
        if sc >= 0.999:
            break
    med = float(np.median([len(a) for _, a in cands]))
    best = max(cands, key=lambda c: (round(c[0], 3), -abs(len(c[1]) - med)))
    LOG.append(dict(voice=vkey, text=text, ls=round(ls, 3), best=round(best[0], 3), tried=len(cands)))
    _best_cache[key] = best[1]
    return best[1]


def silence(sr, sec):
    return np.zeros(int(round(sr * sec)), np.int16)


def split_units(text, clauses):
    """Cümleler; clauses=True ise virgül/noktalı virgülde de böl. Her birim (metin, sonraki_duraklama_türü)."""
    sents = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s.strip()]
    units = []
    for si, s in enumerate(sents):
        parts = [p.strip() for p in re.split(r"(?<=[,;])\s+", s) if p.strip()] if clauses else [s]
        for pi, p in enumerate(parts):
            kind = "end" if si == len(sents) - 1 and pi == len(parts) - 1 else ("sent" if pi == len(parts) - 1 else "clause")
            units.append((p, kind))
    return units


def assemble(vkey, units, ls, pause_sent, pause_clause, lead=0.30, tail=0.50, best=True):
    sr = voice(vkey).config.sample_rate
    segs, speech = [silence(sr, lead)], 0
    for text, kind in units:
        a = synth_best(vkey, text, ls) if best else synth_once(vkey, text, ls)
        speech += len(a)
        segs.append(a)
        segs.append(silence(sr, {"sent": pause_sent, "clause": pause_clause, "end": tail}[kind]))
    return np.concatenate(segs), sr, speech / sr


LS_MAX = 1.65


def fit_speed(vkey, text, target_wpm, pause_sent, clauses):
    words = len(text.split())
    units = split_units(text, clauses)
    pause_clause = 0.40 if clauses else 0.0
    total_target = words * 60.0 / target_wpm
    n_sent = sum(1 for _, k in units if k == "sent")
    n_clause = sum(1 for _, k in units if k == "clause")
    lead, tail = 0.30, 0.50
    # 1 geçiş: ls=1.0'daki konuşma süresini (en iyi-N'siz) ölç
    _, _, s1 = assemble(vkey, units, 1.0, pause_sent, pause_clause, best=False)
    ls = 1.0
    for _ in range(4):
        fixed = n_sent * pause_sent + n_clause * pause_clause + lead + tail
        speech_target = total_target - fixed
        ls = max(0.7, min(LS_MAX, speech_target / s1))
        if speech_target / s1 > LS_MAX:      # fazlalığı duraklamalara dağıt
            extra = speech_target - LS_MAX * s1
            if n_sent: pause_sent += extra / n_sent
            continue
        break
    arr, sr, sp = assemble(vkey, units, ls, pause_sent, pause_clause, best=True)
    for _ in range(4):                         # son düzeltme: gerçek süreye göre
        total = len(arr) / sr
        diff = total_target - total
        if abs(diff) < 0.5: break
        if ls >= LS_MAX - 0.01 and diff > 0 and n_sent:
            pause_sent += diff / n_sent         # ls tavanda: fazlayı duraklamaya ver
        else:
            ls2 = max(0.7, min(LS_MAX, ls * (total_target - (total - sp)) / sp))
            if abs(ls2 - ls) < 0.005: break
            ls = ls2
        arr, sr, sp = assemble(vkey, units, ls, pause_sent, pause_clause, best=True)
    return arr, sr, ls, pause_sent, pause_clause, words, sp


# ---------- dosya çıktısı ----------
def write_wav(path, arr, sr):
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes(arr.tobytes())


def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def to_mp3(wav, mp3):
    r = run(["ffmpeg", "-nostats", "-i", wav, "-af", "loudnorm=I=-18:TP=-2:LRA=9:print_format=json", "-f", "null", "-"])
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", r.stderr, re.S)
    j = json.loads(m.group(0))
    af = (f"loudnorm=I=-18:TP=-2:LRA=9:measured_I={j['input_i']}:measured_LRA={j['input_lra']}:"
          f"measured_TP={j['input_tp']}:measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", wav, "-af", af, "-ar", "22050", "-ac", "1",
                    "-c:a", "libmp3lame", "-b:a", "64k", mp3], check=True)


def duration(mp3):
    return float(run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", mp3]).stdout.strip())


def loudness(mp3):
    r = run(["ffmpeg", "-nostats", "-i", mp3, "-af", "ebur128=peak=true", "-f", "null", "-"])
    m = re.search(r"Integrated loudness:\s+I:\s+(-?[\d.]+) LUFS", r.stderr)
    p = re.search(r"True peak:\s+Peak:\s+(-?[\d.]+) dBFS", r.stderr)
    return (float(m.group(1)) if m else None, float(p.group(1)) if p else None)


results = []


def finish(name, arr, sr, meta):
    wav, mp3 = f"{OUT}/{name}.wav", f"{OUT}/{name}.mp3"
    write_wav(wav, arr, sr)
    to_mp3(wav, mp3)
    d = duration(mp3)
    lufs, tp = loudness(mp3)
    meta.update(file=f"{name}.mp3", duration_seconds=round(d, 3), loudness_lufs=lufs, true_peak_dbfs=tp)
    results.append(meta)
    print(name, json.dumps(meta, ensure_ascii=False), flush=True)


def render_dictation(vkey, items, ls, ordinals, gap):
    sr = voice(vkey).config.sample_rate
    segs, speech = [silence(sr, 0.4)], 0
    for i, it in enumerate(items):
        o = synth_best(vkey, ordinals[i], 1.0)
        a = synth_best(vkey, it, ls)
        speech += len(a)
        segs += [o, silence(sr, 0.6), a, silence(sr, gap)]
    segs.append(silence(sr, 1.0))
    return np.concatenate(segs), sr, speech / sr


random.seed(11)
only = set(sys.argv[4].split(",")) if len(sys.argv) > 4 else None

for tid, (speaker, vkey, text) in T.EN.items():
    for label, (wpm, pause) in T.SPEEDS.items():
        name = f"{tid.replace('-', '_')}_{label}"
        if only and name not in only: continue
        arr, sr, ls, ps, pc, words, sp = fit_speed(vkey, text, wpm, pause, clauses=(label == "yavas"))
        finish(name, arr, sr, dict(text_id=tid, language="en", speaker=speaker, voice=f"en_US-{vkey}", target_wpm=wpm,
                                   word_count=words, length_scale=round(ls, 3), sentence_pause_s=round(ps, 2),
                                   clause_pause_s=pc, wpm_total=round(words * 60 / (len(arr) / sr), 1),
                                   wpm_speech_only=round(words * 60 / sp, 1), best_of=K))

for tid, text in T.TR.items():
    name = tid.replace("-", "_")
    if only and name not in only: continue
    ls, pause = (1.10, 0.60) if not tid.startswith("H5") else (1.05, 0.50)
    units = split_units(text, False)
    arr, sr, sp = assemble("dfki", units, ls, pause, 0.0, best=True)
    words = len(text.split())
    finish(name, arr, sr, dict(text_id=tid, language="tr", speaker="tr-dfki", voice="tr_TR-dfki", word_count=words,
                               length_scale=ls, sentence_pause_s=pause, wpm_total=round(words * 60 / (len(arr) / sr), 1),
                               wpm_speech_only=round(words * 60 / sp, 1), best_of=K))

ORD_EN = ["First.", "Second.", "Third.", "Fourth.", "Fifth.", "Sixth."]
ORD_TR = ["Birinci.", "İkinci.", "Üçüncü.", "Dördüncü.", "Beşinci.", "Altıncı."]
for tid, items in T.DK_EN.items():
    name = tid.replace("-", "_")
    if only and name not in only: continue
    label, ls = T.DK_SPEED[tid]
    arr, sr, sp = render_dictation("kristin", items, ls, ORD_EN, T.DK_GAP_S)
    finish(name, arr, sr, dict(text_id=tid, language="en", speaker="kristin", voice="en_US-kristin", speed_label=label,
                               length_scale=ls, items=len(items), gap_seconds=T.DK_GAP_S, best_of=K))
for tid, items in T.DK_TR.items():
    name = tid.replace("-", "_")
    if only and name not in only: continue
    label, ls = T.DK_SPEED[tid]
    arr, sr, sp = render_dictation("dfki", items, ls, ORD_TR, T.DK_GAP_S)
    finish(name, arr, sr, dict(text_id=tid, language="tr", speaker="tr-dfki", voice="tr_TR-dfki", speed_label=label,
                               length_scale=ls, items=len(items), gap_seconds=T.DK_GAP_S, best_of=K))

json.dump(results, open(f"{OUT}/results.json", "w"), ensure_ascii=False, indent=1)
json.dump(LOG, open(f"{OUT}/select_log.json", "w"), ensure_ascii=False, indent=1)
weak = [l for l in LOG if l["best"] < 0.85]
print("DONE", len(results), "zayıf birim:", len(weak))
for l in weak: print("  ZAYIF", l)
