"""Yeniden üretilen sesleri (bir veya daha çok çalışma klasörü) nihai klasöre (audio_final) birleştirir.
Kullanım: python3 -I merge_audio.py <SP> <çalışma_klasörü_adı> [<çalışma_klasörü_adı> ...]"""
import json
import shutil
import sys

SP, works = sys.argv[1], sys.argv[2:]
F = f"{SP}/audio_final"
old = json.load(open(f"{F}/results.json", encoding="utf-8"))
by_file = {r["file"]: r for r in old}
for w in works:
    new = json.load(open(f"{SP}/{w}/results.json", encoding="utf-8"))
    for r in new:
        assert r["file"] in by_file, r["file"]
        by_file[r["file"]] = r
        shutil.copyfile(f"{SP}/{w}/{r['file']}", f"{F}/{r['file']}")
        print("  güncellendi:", r["file"], "<-", w)
    shutil.copyfile(f"{SP}/{w}/select_log.json", f"{F}/select_log_{w}.json")
assert len(by_file) == 26
json.dump(list(by_file.values()), open(f"{F}/results.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("toplam", len(by_file))
