# Kaynak araştırması ve seçim gerekçeleri

Kontrol tarihi: **27 Ekim 2026**. Aşağıdaki bağlantıların çoğu bu tarihte yeniden açılıp sayfa içeriğiyle karşılaştırıldı (hangisinin açılmadığı tabloda belirtilir). Bunlar resmî ürün sayfaları, üniversite rehberi ve özgün araştırma yayınlarıdır. **Senin Redmi telefonunda** hesap açma, mikrofon, oynatma ve çevrimdışı çalışma denenmedi; bir kaynak açılmıyorsa ya da bir özellik farklıysa gerçek cihaz sonucu bu tabloyu geçersiz kılar.

## Seçim ölçütleri

Ücretsiz erişim, başlangıç seviyesine uygun basamaklar, anlaşılır yönerge, dinleme ve üretim fırsatı, telefon kullanımı ve kayıt gereksinimleri birlikte dikkate alındı. Bir ürünün tanıtımı, bu kullanıcıda gelişimi kanıtlayan deney değildir. Aşağıdaki seçim **gereksinime uygunluk kararımdır**; dünyanın en iyi uygulamasını bulduğum iddiası değildir.

## Kaynaklar

| Kaynak | 27 Ekim 2026'da sayfada görülen | Bu plandaki kullanım |
| --- | --- | --- |
| [USA Learns — 1st English Course](https://www.usalearns.org/1st-free-online-english-course) | Başlangıç düzeyi için ücretsiz, video tabanlı çevrimiçi kurs; 20 ünite; videolar ve çevrimiçi etkinlikler | **Ana İngilizce kaynağı.** İlk üniteden sırayla, küçük etkinlik gruplarıyla. |
| [USA Learns öğrenci yardımı](https://www.usalearns.org/need-help-students) | Sitenin akıllı telefonda, tablette ve bilgisayarda çalıştığı; tarayıcıya mikrofon izni verme açıklaması | Gün 1 erişim ve kayıt denemesi. Sitenin kendi geçmişinin bu pakete aktarılabildiği **doğrulanmadı**; elle kayıt tutulur. |
| [VOA — Let's Learn English 1](https://learningenglish.voanews.com/p/5644.html) | 52 ders, haftada bir ders | **Destek ve yedek.** İlk hafta 1–3. derslerin uygun parçaları; 52 dersi hızla bitirmek hedef değil. |
| [VOA Ders 1](https://learningenglish.voanews.com/a/lets-learn-english-lesson-one/3111026.html) | Video indirme seçenekleri (240p–1080p) ve 64 kbps MP3 ses | İnsan sesiyle model dinleme; indirme telefonda çalışırsa kişisel çevrimdışı kullanım. |
| [British Council A1 dinleme](https://learnenglish.britishcouncil.org/free-resources/listening/a1) | Her derste hazırlık görevi, ses kaydı ve anlamayı kontrol eden iki görev | İkinci yedek; aksan hedefi Amerikan olduğu için ana rota değil. |
| [Busuu Premium nedir](https://help.busuu.com/hc/tr/articles/16269241908497-Premium-nedir) | **Bu tarihte sayfa açılmadı (403).** v10'daki “temel kurs ücretsiz; çevrimdışı ve bazı tekrar araçları ücretli” bilgisi yeniden doğrulanamadı | Alternatif olarak anıldı; sıfır bütçe ve çevrimdışı önceliğinde ana kaynak seçilmedi. Karar bu bilgiye dayanmıyor. |
| [Anki ayarları](https://docs.ankiweb.net/manual/deck-options) | Kendi zamanlama (öğrenme adımları, günlük sınırlar, FSRS) seçenekleri | Zorunlu değil. Aynı maddeleri hem Anki'de hem 3–10–20–50 kuyruğunda tutmayız. |
| [Stanford — Memory Palace](https://ctl.stanford.edu/memory-strategy-memory-palace) | Sıralı bilgi için bilinen bir yerin “odalarına” görüntü yerleştirme yöntemini anlatan rehber; lisans: **CC BY-NC-ND 4.0** | **Yöntem rehberi (yalnız bağlantı).** Rehberin çevirisi ya da uyarlaması bu pakette **yoktur**. |
| [Brain Workshop](https://brainworkshop.sourceforge.net/) | Ücretsiz açık kaynak dual n-back; Windows, Mac, Linux | Günlük unutkanlık için ana çözüm yapılmadı. Görevde ilerleme günlük yaşama aktarımı kanıtlamaz. |
| [Nike Training Club](https://www.nike.com/tr/ntc-app) | Ücretsiz indirme, 200'den fazla ücretsiz antrenman, Android sürümü | İsteğe bağlı hareket gösterimi. Genel programı senin oranların ve ekipmanın yerine koymuyorum. |
| [EF SET dört beceri](https://www.efset.org/4-skill/) / [iki beceri](https://www.efset.org/ef-set-50/) | Dört beceri (konuşma, yazma, dinleme, okuma) 90 dakika; iki beceri (okuma, dinleme) 50 dakika | İsteğe bağlı dış ölçüm. Üç test gününe zorunlu sınav yükü olarak eklenmedi. Süreler ürünün sınav koşuludur. |

## Hangi kısım dışarıdan, hangisi özel hazırlandı?

| Alan | Karar | Özel hazırlığın nedeni |
| --- | --- | --- |
| İngilizce temel öğretim | USA Learns; VOA destek | Mevcut öğretimi yeniden üretmek yerine düzenli kurstan ve insan sesinden yararlanmak |
| Kaynak açılmazsa İngilizce | Pakette dört kısa yedek ders | Giriş, mikrofon veya erişim sorunu çalışmayı tamamen durdurmasın |
| Hafıza sarayı | Stanford rehberine bağlantı + kendi sözlerimle yönerge + kişisel rota alıştırması | Yöntem dışarıda var; kendi mekânına ve kayıt düzenine uyarlama gerekiyor |
| Dersin başını koruma, gecikmeli hatırlama, çok kısa gecikme, tekrar dinleme | Özel Türkçe pratik ve ses dosyaları | İncelenen adaylarda bu ihtiyaçları ve deneme/yardım kayıtlarını birlikte sağlayan bir çözüm doğrulanmadı |
| Dinleme + yazma/hareket/konuşma | Özel görev akışı ve sesler | Kanal tabanı, kesinti ve dil etkisini ayrı kaydetmek gerekiyor |
| Okurken satır kaybı | Metin + kullanıcının sayımı + anlatım | Göz izleme veya tıbbi ölçüm yapılmıyor |
| Spor | Kullanıcının çerçevesi + seçilmiş gösterimler | Tek taraflı dambıl, hafta sonu ekipmansızlık ve hedef oranları genel programdan farklı |
| Kayıt ve değerlendirme ZIP'i | Elle köprü protokolü | İncelenen kaynaklarda tam soru, tüm denemeler, anahtar olayları ve özgün sesi birlikte veren dışa aktarım doğrulanmadı |

Bir kaynağın raporu sınırlı diye eğitimini de terk etmek gerekmiyor. **Eğitimi dışarıdan alıp kayıt gereksinimini ayrı karşılamak** bu hafta için daha uygundur.

## Araştırmanın plana yansıyan noktaları

1. EF SET'in dört becerilik (90 dk) ve iki becerilik (50 dk) ürünleri ayrıdır; dış aracın puanı onun kendi sonucu olarak kalır, bu sistemin puanı değildir.
2. VOA'nın medya seçenekleri doğrulandı; bütün derslerin okuma hızının aynı olduğu genellenmez.
3. NSCA'nın 2009 resmî metni (bu tarihte yeniden açılıp okundu) gençler için direnç çalışmasını “2–3 gün, ardışık olmayan günlerde” önerir ve uygun tasarım ile gözetimi şart koşar. Bu, her gün aynı ağır çalışmayı desteklemez; bu hafta yüklü direnç çalışması da yoktur (`calisma/04_SPOR_ILK_HAFTA.md`). [NSCA, 2009](https://www.nsca.com/globalassets/about/position-statements/position_stand_youth_resistance_training---2009.pdf)
4. Çalışma belleği oyunlarının geniş günlük becerilere aktarımı yayımlanmış bir meta-analizde desteklenmemiştir; görevler bu yüzden gerçek ihtiyaca yakın tutuldu. [Melby-Lervåg ve diğerleri, 2016](https://journals.sagepub.com/doi/10.1177/1745691616635612) (bu bağlantı v11 hazırlığında yeniden açılmadı).
5. Tekrar yükü: aralıkların toplamı 83 gündür. Her gün N yeni madde ve madde başına dört tekrarla, gecikme yoksa kararlı yük **4N tekrar/gün** olur (0 tabanlı d için: d<3 → 0, 3–12 → N, 13–32 → 2N, 33–82 → 3N, d≥83 → 4N). Aralıkların uzaması bu üst sınırı yarıya indirmez. Bu bir kaynak iddiası değil, dört öğrenme grubunun sayımıdır (`kayitlar/INGILIZCE_TEKRAR_KURALI.md`).

## Kullanım sırasında seçimi değiştiren durumlar

USA Learns'e erişilemiyorsa veya yönergeler anlaşılmıyorsa aynı gün VOA ya da paketteki yedek ders kullanılır. Bir dersteki tek bir bilinmeyen sözcük kaynak değişikliği nedeni değildir. Video açılmaması, mikrofonun çalışmaması veya etkinlikleri tek başına yürütememek kayda yazılır.

Ana kaynak seçimi birinci gün değişmez bir karar olmaz. İlk iki deneyimin ardından üçüncü gün sen kullanım notuyla belirlersin. Şu an USA Learns'i öne alıyorum; gerçek cihaz sonucu bu kararı değiştirebilir.

## Telif ve lisans

Hiçbir dış kaynağın tam metni ya da çevirisi pakete kopyalanmadı; paketteki ders, soru ve sesler özgündür. Stanford rehberi CC BY-NC-ND 4.0 lisanslıdır (ticari olmayan kullanım, türev üretmeme, atıf); bu yüzden pakette yalnız bağlantı ve yöntemi genel olarak anlatan kendi cümlelerimle yazılmış yönerge vardır, rehberin çevirisi ya da uyarlaması yoktur. Seslerin lisansı `test_gununde_ac/06_SES_VE_LISANS_NOTU.md` dosyasındadır.
