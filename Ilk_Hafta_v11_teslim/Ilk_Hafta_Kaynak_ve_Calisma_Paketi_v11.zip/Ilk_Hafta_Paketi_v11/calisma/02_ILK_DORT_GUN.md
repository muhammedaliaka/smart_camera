# İlk dört günün çalışma kartları

Her günün ana hedeflerini gün içine dağıtabilirsin; sıra serbest, hedeflere uyku öncesine (≈23:00) kadar ulaşmak yeterli. Dakika görevi yok. Gün 1, sen başladığında yazılır; raporun tarihi otomatik olarak birinci gün sayılmaz. Spor ayrı karttan yürür (`04_SPOR_ILK_HAFTA.md`). Buradaki her anlatım ve deneme **öğrenme çalışmasıdır**, test değildir.

Bir alana ilk kez giriyorsan önce `02a_ALAN_BASLANGIC_KARTLARI.md` içindeki ilgili kartı oku (hedef sayılmaz). Cihaz provası için `01_GUN_0_HAZIRLIK.md`. Sesler `calisma/ses/` klasöründedir; ses dosyalarını telefonun ses kaydedicisiyle kaydettiğin yanıtlardan ayrı tut.

Yardım kodları (A0–A4) ve gönderim sayımı `kayitlar/YANIT_SABLONU.md` dosyasında. Anahtarlar bu dört günde `02b_PROVA_VE_GUN1_4_ANAHTARLARI.md` içinde, **yanıt verdikten sonra** açılır.

## Dört günün özeti

| Gün | Ana çıktılar | Ses dosyası |
| --- | --- | --- |
| 1 | Eğitim öncesi başlangıç kaydı; İngilizce kaynağa giriş; hafıza sarayı kurulumu | — |
| 2 | VOA Ders 1; H1 sıralı yönerge; C0 tek görev tabanları; ilk İngilizce maddeler | `G02_C0_dinleme.mp3` |
| 3 | Ana kaynak notu; G3 makalesi (parmak/cetvel kılavuzuyla); H5 tanışma; B1 dikte tanışma; H6 1. dinleme | `G03_H5_tanisma.mp3`, `G03_B1_dikte_tanisma.mp3`, `H6_dinleme_G03_G04_G07.mp3` |
| 4 | H6 kontrol 1 + 2. dinleme; İngilizce etkinlik grubu; ilk tekrar; kesintili yazma provası; kayıt ve anahtar provası | `H6_dinleme_G03_G04_G07.mp3` |

## Gün 1 — Başlangıç kaydı, kaynağa giriş, yöntemi tanı

### Eğitim öncesi başlangıç kaydı (ders açmadan, önce bunları yap)

Bunlar ana raporun 13.2 numaralı tablosundaki Gün 1 kaydıdır: **eğitimden önceki** durumun kısa bir örneği. Sınav değildir ve sonradan “gelişti/geriledi” hükmü çıkarmak için kullanılmaz; yapmak istemediğin parçaya “yapılmadı” yaz.

1. **Serbest yazı:** Kendini ve İngilizceyi neden öğrenmek istediğini İngilizce yazabildiğin kadar yaz. Yetmeyen yerde Türkçe yaz. Çeviri aracı ve yapay zekâ kullanma; kullandıysan belirt (A4).
2. **Kısa sesli anlatım:** Aynı konuyu telefonun ses kaydedicisine anlat (Türkçe ya da İngilizce, hangi dilde olduğunu söyle).
3. **Okuma, satır sayımı ve anlatım:** Aşağıdaki metni normal biçimde, **parmak ya da cetvel kullanmadan** oku. Okurken satırı kaybettiğin ya da geri döndüğün anları kendi sayımınla yaz (sayamadıysan “sayamadım”). Sonra metni kapat ve ana olayı, notta ne yazdığını ve Defne'nin ne yaptığını kendi sözlerinle anlat. Bu sayım göz hareketi ölçümü değildir.

> **Haritanın notu**
>
> Pazartesi sabahı Defne, mahalledeki küçük kitapçının önünden her zamanki gibi geçiyordu. Vitrinde daha önce görmediği bir harita duruyordu. Haritanın üstünde köşeleri kıvrılmış bir not asılıydı: “Bu haritayı gören, perşembe akşamına kadar buraya uğrasın.”
>
> Defne önce notu okumak için yaklaştı, sonra içeri girdi. Tezgâhın arkasındaki yaşlı satıcı gülümsedi. Haritayı bir müşterinin unuttuğunu, sahibini aradıklarını anlattı. Defne haritanın kenarında küçük bir yıldız işareti fark etti ve bunu satıcıya söyledi.
>
> Satıcı yıldızın ne anlama geldiğini bilmiyordu, ama bunu not defterine yazdı. “Perşembeden önce yeni bir şey hatırlarsan haber ver,” dedi. Defne çıkarken ertesi gün yeniden uğrayacağını söyledi.

Bu metin özgün kurmacadır. Gün 3'teki makaleyle karıştırma: **Gün 3'teki metin ayrı bir yazıdır.**

### İngilizce

[USA Learns 1st English Course](https://www.usalearns.org/1st-free-online-english-course) üzerinden ücretsiz öğrenci hesabıyla başla. Birinci ünitenin başlangıç videosunu ve ardından açılan bir kelime etkinliği ile bir dil kullanım etkinliğini tamamla. Tam üniteyi bitirme zorunluluğu yok. Dersin ekranında kaldığın bölümün adını yaz; mikrofon testini yapıp sonucunu not et.

Tamamlanma çıktısı: **1 video + 2 etkinlik + öğrendiğin 3 sözcük/kalıp**. Kalıpların Türkçe anlamını ve kendine ait birer örneği ekle. Sözcüğü bilmediğinde tahminini yazıp açıklamasına bakabilirsin. Dış kaynağın puanı bu paketin puanı değildir.

Bu üç madde, tekrar kuyruğuna almayı seçersen **Gün 4'te** (öğrenmeden 3 gün sonra) ilk kez sorulur. Ayrıntı: `kayitlar/INGILIZCE_TEKRAR_KURALI.md`.

Kaynak kullanılamazsa: `03_INGILIZCE_YEDEK_DERSLER.md` içindeki **E1** dersini yap. Hesap veya mikrofon sorununun kısa notunu sakla. Başka uygulamalar arasında dolaşmak yerine o gün yedekle bitir.

### Hafıza sarayı: sıfırdan

Kart 4'ü (`02a`) oku. Kısaca: hafıza sarayı, bildiğin bir yerdeki durakları hatırlamak istediğin sıraya bağlama yöntemidir; “her şeyi unutmama” yöntemi değildir. İsteğe bağlı dış açıklama: [Stanford rehberi](https://ctl.stanford.edu/memory-strategy-memory-palace).

1. Kendi evinden birbirine benzemeyen **8 sabit durak** seç (en az 6 yeterli). Örnek yapıyı kopyalamak zorunda değilsin: kapı, ayakkabılık, lavabo, masa, pencere, yatak, dolap, balkon.
2. Sırayı bir kez yaz. Hep aynı yönde zihninden geç.
3. Eğitim listesi: **limon, saat, kitap, top, anahtar, bulut**. Her durağa bir nesneyi komik bir olayla yerleştir. Örneğin masadan dev bir top zıplıyor.
4. Listeyi kapatıp duraklarda gezinerek aklına gelenleri sırayla söyle. Açıp bakarsan “yeniden baktım” yaz.

Çıktı: **durak listesi + 6 ilişkilendirme + bir geri çağırma denemesi**. İlişki kuramıyorsan durak sayısını dörde indir; sayı büyütmek hedef değil. Bu liste testte kullanılmayacak.

## Gün 2 — Gerçek sesle çalış, tek görevleri tanı

### İngilizce

[VOA Ders 1: Welcome!](https://learningenglish.voanews.com/a/lets-learn-english-lesson-one/3111026.html) ana dersini ve konuşma pratiği bölümünü kullan. Önce dinle, sonra gerekirse metne bak. Duyduğun üç kısa ifadeyi seç; her birini kendi sesinle birer kez söyle ve kaydet. Ses dosyalarını `01_GUN_0_HAZIRLIK.md` içindeki ada göre adlandır (örn. `G02_EN_S01_D01_20261029-1530.m4a`).

Çıktı: **1 ders deneyimi + 3 ifade + 1 kişisel tanışma kaydı**. Tanışmada ad yerine takma ad kullanabilirsin. İndirilebilir medya bağlantısı açılıyorsa kişisel kullanım için indirip uçak modunda açmayı dene; sonucu yaz. Bu deneme başarısız olursa bütün VOA'nın çevrimdışı çalıştığı varsayılmaz.

Kaynak açılmazsa: **E2** yedek dersi.

### Hafıza

1. Dünkü listeye bakmadan güzergâhını dolaş ve aklına gelenleri kaydet. Sonra listeye bakıp yeni bir deneme yapabilirsin. İki denemeyi ayrı tut. Listeyi değiştirip eskisini aynı duraklara hemen yığma.
2. **H1 — sıralı yönerge (eğitim):** Aşağıdaki yedi nesneyi sırayla saray duraklarına yerleştir: **çatal, merdiven, portakal, mektup, kask, ayna, zil.** Sonra listeyi kapat ve nesneleri sırayla söyle (kayıt). Gün içinde, listeye bakmadan bir kez daha söyle. İki denemeyi ayrı kaydet; yeniden baktıysan yaz. Yer ayırma sorun olursa durak sayısını azalt.

### C0 — tek görev tabanları (tanışma)

C0, dinle, konuş, yaz ve hareket kanallarının **ayrı ayrı** nasıl gittiğine bakar. Henüz hiçbirini aynı anda yapma.

- **Dinleme:** `G02_C0_dinleme.mp3` dosyasını oturarak dinle. Dilersen tekrar aç; açma sayısını yaz. Sonra kendi sözlerinle anlat (kayıt).
- **Yazma:** “Kullanışlı bir uygulama nasıl olmalı?” konusunda kendi fikrinle 4 cümle yaz.
- **Konuşma:** Yazdığın metni okumadan aynı konuda 3 düşünceni sesli anlat.
- **Hareket:** Sabit bir destek yanında 10 rahat yerinde adım yap; bu sırada başka görev yok.

Çıktı: dört kısa kayıt ve kısa zorlanma notu. Dinleme anahtarı `02b` dosyasında.

## Gün 3 — Ana kaynağı seç, okuduğunu kendi sözlerinle anlat

### İngilizce

İki kaynağa ilişkin üç soruya kısa yanıt ver: **Açabildim mi? Ne yapacağımı anlayabildim mi? Yardımsız bir sonraki etkinliğe geçebildim mi?** Sayısal puan verme. USA Learns kullanılabiliyorsa birinci ünitede kaldığın yerden iki etkinlik daha yap. Uygun değilse [VOA Ders 2](https://learningenglish.voanews.com/a/lets-learn-english-lesson-2-hello/3113733.html) ile ilerle.

Çıktı: **seçtiğin ana kaynağın adı + bir etkinlik grubu + yeni 3 kalıp**. Bütünüyle erişim sorunu varsa **E3** yedeği.

### B1 — duyduğunu yakalayıp yazma (dikte tanışma)

`G03_B1_dikte_tanisma.mp3` dosyasını aç. Altı kısa öğe sırayla okunur; her öğeden sonra yazman için boşluk bırakılır. Duyduğunu **aynen duyduğun gibi** yaz; bilmediğin sözcükleri sesine göre yazabilirsin. Dilersen dosyayı yeniden aç; tekrar sayısını yaz. Yanıttan sonra `02b` dosyasındaki anahtara bak. Bu bir eğitim; gerçek dikteler Gün 6'dadır ve farklı öğeler içerir. Dikte bir işitme testi değildir.

### G3 — İlk makale: Uzayda su neden döndürülür?

Bu metni bu kez **parmak ya da cetvel kılavuzuyla** oku (ilk kılavuz denemesi). Okurken satırı kaybettiğin ya da geri döndüğün anları kendi sayımınla yaz; sayamadıysan “sayamadım”. Gün 1'deki kılavuzsuz okumayla bu denemeyi karşılaştırıp hüküm çıkarma; metinler ve gün farklı.

Uzaya her ihtiyaç için yeni su taşımak yük oluşturur. Bu yüzden bir uzay istasyonunda kullanılan suyun bir bölümünü yeniden kullanılabilir hâle getiren donanımlar bulunur. Terden ve nefesten havaya karışan nem de bu döngünün parçasıdır. “Atık” denen bir akışın içinde hâlâ işe yarayacak su bulunabilir.

NASA, 2023'te istasyondaki bir düzenekte toplam su geri kazanımının yüzde 98'e ulaştığını bildirdi. Kalan suyu geri almak için kullanılan ek donanım bu gösterimde önemliydi. Bu sayı belirli sistemin ve gösterimin sonucudur. Bütün uzay araçlarının bütün ihtiyaçlarını yüzde 98 kapattığı anlamına gelmez. Su döngüsünün iyi çalışması, yiyecek ve havanın da aynı oranda döngüye girdiğini göstermez.

Yalnızca hesabı anlamak için, her turda 100 birimlik aynı tür bir su akışının yüzde 98'inin geri kazanıldığını düşün. İlk turda 98 birim kalır. İkinci turda bu 98 birimin yine yüzde 98'i geri gelirse yaklaşık 96,04 birim kalır. Bu basitleştirilmiş örnek, küçük kayıpların tekrarlandığında birikebileceğini gösterir; istasyonun gerçek günlük su hesabı değildir.

Bir başka önemli ayrım da temizlenmiş son ürün ile başlangıçtaki karışımdır. Su, farklı arıtma basamaklarından geçer ve kalitesi kontrol edilir. Başarılı bir geri dönüşüm düzeni, yalnızca suyu ayıran makineden oluşmaz; kaliteyi izleyen ve uygun olmayan suyu yeniden işleyen süreçleri de içerir.

Kaynak: [NASA, 20 Haziran 2023](https://www.nasa.gov/missions/station/iss-research/nasa-achieves-water-recovery-milestone-on-international-space-station/). Metin özgün Türkçe anlatımdır; sayısal tur örneği açıklama amacıyla eklenmiştir.

**Sözlük:** geri kazanım = kullanılan maddenin yeniden işe yarar hâle getirilmesi; akış = sistem içinde taşınan madde; arıtma = istenmeyen maddeleri uzaklaştırma.

Çıktı: metni kapatıp **ana fikir + iki bilgi + kesin sonucunu bilmediğin bir soru** yaz ya da kendi sesinle anlat. Kaynağa dönersen bunu belirt. Anlatırken kaynak cümlelerini ezberden aynen söylemek gerekmiyor.

### H5 — ders başını koruma (tanışma)

Kart 4'teki fikri dene: `G03_H5_tanisma.mp3` kısa bir mini ders. **Dinlerken** zihninde tek cümlelik bir başlık tut: “konu + kaç parça”. Not alma. Dosya bitince (tekrar açmadan) “Dersin başında ne söylendi?” sorusuna kendi sözlerinle yanıt ver; yazı ya da ses. Sonra `02b` dosyasındaki anahtara bak. Bu bir eğitim denemesidir; yöntemin seni nasıl etkilediğini notla.

### H6 — tekrar dinleme etkisi (1. dinleme)

`H6_dinleme_G03_G04_G07.mp3` kısa bir duyurudur. **Şimdi yalnız bir kez** dinle; durdurma, geri alma, yazma. Duyurunun metnine ve anahtarına bu haftanın sonuna kadar bakma; anahtar `test_gununde_ac` klasöründe, `08_ANAHTAR_GUN8_H6.md` dosyasında kapalıdır ve Gün 8 kontrolü bitince açılır. Telefonda **ertesi gün** için bir Saat alarmı kur. Gün 4'te ilk iş olarak duyuruyu çalmadan hatırlamaya çalışacaksın.

## Gün 4 — Düzeni prova et, testi çalışmaya karıştırma

### H6 — kontrol 1 ve 2. dinleme

1. Önce dosyayı **açmadan**, “Dün dinlediğim duyuruda neler vardı?” sorusuna yazı ya da sesle yanıt ver. Bilmiyorum diyebilirsin; yardım kullanma. Saati kaydet.
2. Sonra duyuruyu **bir kez** (ikinci dinleme) dinle.

Aralıklı soruların kendisi öğrenmeyi etkileyebilir; bu yüzden her kontrolün saati ve kaçıncı dinlemeden sonra yapıldığı yazılır.

### İngilizce

Seçtiğin ana kaynakta sonraki küçük etkinlik grubunu yap. VOA rotasındaysan [Ders 3: I'm Here!](https://learningenglish.voanews.com/a/lets-learn-english-lesson-3-i-am-here/3126527.html). Erişim sorunu varsa **E4** yedeği. Bir kişiye tekrar etmesini, daha yavaş konuşmasını ve bir sözcüğü açıklamasını isteyen üç cümle söyle.

Gün 1'de öğrendiğin maddeleri tekrar kuyruğuna aldıysan ilk geri çağırma **bugün**: öğrenmeden 3 gün sonra. Önce kayda bakmadan kendi yanıtını ver, sonra anahtara bak. Sonraki tekrar, bugünkü tekrardan **10 gün sonra** (Gün 14). İlk hafta maddelerini kuyruğa almak isteğe bağlıdır; düzenli yeni madde girişi ikinci hafta başlar. Gün 2, 3 ve 4'te öğrenilen maddelerin ilk tekrarı Gün 5, 6 ve 7'ye düşer; test günlerinde bu tekrarlar kısa tutulur.

| Öğrenme günü | Tekrar 1 (+3) | Tekrar 2 (+13) | Tekrar 3 (+33) | Tekrar 4 (+83) |
| --- | --- | --- | --- | --- |
| Gün 1 | Gün 4 | Gün 14 | Gün 34 | Gün 84 |
| Gün 2 | Gün 5 | Gün 15 | Gün 35 | Gün 85 |
| Gün 3 | Gün 6 | Gün 16 | Gün 36 | Gün 86 |
| Gün 4 | Gün 7 | Gün 17 | Gün 37 | Gün 87 |

Bu tablo gecikmesiz nominal günleri gösterir. Gerçek tarihler için `kayitlar/INGILIZCE_TEKRAR_TAKVIMI.xlsx` dosyasını kullan.

### Kesinti sırasında yazma provası

Oturarak bir uygulama fikrini 4–6 cümleyle yaz. Doğal bir kesinti olursa sonradan “kesinti oldu; kaldığım düşünceyi buldum/bulamadım” diye işaretle. Kesinti yoksa bir kısa soru kartını kendin açıp sesli yanıtla ve yazıya dön. İkinci yöntem canlı insan konuşmasıyla aynı değildir; “kendim açtığım kart” diye etiketlenir.

Kart örnekleri: “Bu fikri kim kullanır?”, “En gerekli tek özellik ne?”, “Bir cümleyle neden yararlı?” Başkasının sesini kaydetme. Yazının önceki hâlini silme.

### Kayıt ve anahtar provası

`02b_PROVA_VE_GUN1_4_ANAHTARLARI.md` dosyasındaki **P1 ve P2** prova sorularını kullan. P1'de anahtarı elle aç, P2'de üçüncü gönderimden sonra aç; açış saatini ve gönderim numarasını yaz. Bir örnek yanıtın ilk ve düzeltilmiş hâlini iki satır olarak sakla. Ses dosyasını açıp çaldığını kontrol et. **Test sorularını bu prova için açma.**

### Tekrar günü notu

Üç satır yaz: Bu dört günde hangi yöntem uygulanabilir geldi? Hangisi zordu? Hangi kaynağı sürdürmek istersin? Puan verme.

Test maddeleri eğitimden ayrı kilitlidir: `test_gununde_ac` klasöründeki hiçbir metin, ses ya da soru bu dört günde kullanılmadı. Gün 5'e kadar açma.

Çıktı: **1 kaynak etkinlik grubu + 3 istek cümlesi + H6 kontrol 1 + bir kesintili yazı örneği + kayıt provası + tekrar günü notu**.

## İsteğe bağlı derinleşme okuması

### G4 — İyi bir su döngüsü neden tam bir yaşam sistemi değildir?

Bir sistemin bir bölümünün başarılı olması, bütünün kendi kendine yettiğini göstermez. Bir evin musluğunun çalışması, elektrik veya yiyeceğin de üretildiği anlamına gelmediği gibi, uzayda suyu temizleyebilmek de insanın bütün ihtiyaçlarını kapatmaz.

NASA'nın ECLSS açıklamasında su geri kazanımı, havanın temizlenmesi ve oksijen üretimi ayrı alt sistemler olarak ele alınır. Basınç ve havalandırma gibi koşullar da yönetilir. Bunların her biri farklı bir akışı izler. Sistemin sınırını açıkça belirtmek, neyin içeri girip neyin dışarı çıktığını anlamayı kolaylaştırır.

Basitleştirilmiş bir düşünce deneyi yapalım. Elimizde suyu çok iyi geri kazanan ama yiyecek üretmeyen bir oda olsun. Su kaybı azalsa da yiyecek stokları tüketilir. Bu oda için “su bakımından geri dönüşüm var” denebilir; “süresiz bağımsız yaşam var” denemez. Öte yandan yiyecek yetiştirilen bir odada da enerji, besin maddesi veya yedek parça ihtiyacı devam edebilir. Bu örnekler gerçek bir habitatın tasarım hesabı değil, farklı ihtiyaçları birbirine karıştırmamak için kurulmuş varsayımlardır.

Bir teknik haberi okurken üç soru bu yüzden işe yarar: **Hangi alt sistem inceleniyor? Hangi koşulda denenmiş? Başarılı sayılan ölçüt ne?** İki sayfanın farklı yüzdeler vermesi de tek başına birinin uydurma olduğunu göstermez. Dönem, sistem düzeni ve ölçülen pay aynı mı diye bakmak gerekir. Bu kontrol yapılmadan rakamları birleştirmek yanıltıcı olabilir.

Kaynak: [NASA ECLSS açıklaması](https://www.nasa.gov/reference/environmental-control-and-life-support-systems-eclss/) ve önceki okumanın 2023 tarihli gösterim haberi. Özgün Türkçe anlatım; oda örnekleri açıklayıcı varsayımlardır.

**Sözlük:** alt sistem = daha büyük yapının belirli işi yapan bölümü; sistem sınırı = hesapta hangi parçaların içeride sayıldığı; ölçüt = neye bakarak sonuç değerlendirildiği.

Çıktı: “Su döngüsü iyi olan oda neden tek başına yeterli olmayabilir?” sorusunu kendi sözlerinle açıkla. Bu metin ilk haftada zorunlu değildir.
