# Prova soruları ve Gün 1–4 anahtarları — yanıt verdikten sonra aç

Bu dosyadaki anahtarlar yalnız **eğitim** görevleri içindir. Test günlerinin anahtarları `test_gununde_ac` klasöründe ve ayrı dosyalardadır. Hüküm ve puan yoktur; anahtar yalnız “beklenen buydu” bilgisidir. Bir maddeyi açtığında saatini ve kaçıncı gönderimde açtığını kayda yaz (`kayitlar/YANIT_SABLONU.md`).

Anahtarlar bu dosyanın en altında, ayrı bir bölümdedir. Yanıt vermeden o bölüme inme.

## Kayıt ve anahtar provası (Gün 4)

Amaç: gönderim sayımını, anahtarı elle açmayı ve üçüncü gönderimden sonra açmayı **eğitim sorusu üzerinde** denemek. P1 ve P2 test sorusu değildir; sonuçları hiçbir yerde kullanılmaz.

### P1 — Çeviri (anahtarı elle aç)

“The cat is under the table.” cümlesini Türkçeye aktar.

1. Yanıtını yaz, “gönder”e bas; **1. gönderim** olarak not al.
2. Anahtarı kendin aç (aşağıda P1) ve açış saatini ve “elle açıldı” yaz.
3. Yanıtını değiştirmek istersen yeni bir deneme olarak ekle; eskisini silme.

### P2 — Kısa yanıt (üçüncü gönderimden sonra aç)

“Kitap masanın üzerinde.” cümlesini İngilizce yaz.

1. 1. gönderimini yap ve not al.
2. İstersen yanıtını değiştirip 2. gönderimi yap.
3. 3. gönderimden **sonra** anahtarı aç; kayda “3. gönderimde açıldı” yaz. İki gönderimden sonra yanıtını değiştirmek istemesen de 3. gönderimi yapmak, kuralı denemek içindir (bu bir doğru/yanlış hükmü değildir).

Yardım kullandıysan (sözlük, çeviri aracı…) hangi kodla işaretlendiğini yaz (A1–A4).

---

## ANAHTARLAR — yanıt verdikten sonra

### P1

Kedi masanın altında. (Başka doğru ifadeler olabilir: “Kedi masa altında.”)

### P2

The book is on the table.

### Gün 2 — C0 dinleme (`G02_C0_dinleme.mp3`)

Metin: “Bir mahalle grubu ortak bahçe için hazırlık yapıyor. Fidanlar kapının yanına, saksılar çatı altındaki rafa konacak. Bahçeye girmeden önce yoldaki eski tahtalar kaldırılacak. Grup üyeleri önce aletleri toplayıp sonra komşuları karşılayacak.”

Beklenen noktalar: mahalle grubu, ortak bahçe; fidanlar kapının yanına, saksılar çatı altındaki rafa; yoldaki eski tahtalar kaldırılacak; önce aletler toplanacak, sonra komşular karşılanacak. Anlatımın bu noktaları içerip içermediğini dışarıdaki değerlendirici yorumlar.

### Gün 3 — B1 dikte tanışma (`G03_B1_dikte_tanisma.mp3`)

1. seven
2. twenty-one
3. Monday
4. a green book
5. Where is the bus stop?
6. I live near the school.

Duyduğunu sesine göre yazman yeterli; yazım hatası burada hüküm değildir.

### Gün 3 — H5 tanışma (`G03_H5_tanisma.mp3`)

Dersin başında söylenenler: konu **bulutların nasıl oluştuğu**; **üç parça**: buharlaşma, soğuma, yoğuşma.

Dersin tamamı: “Bugün bulutların nasıl oluştuğunu anlatacağım. Konuyu üç parçada ele alacağız: önce buharlaşma, sonra soğuma, en sonunda yoğuşma. Güneş yüzeydeki suyu ısıtır ve su buharı yükselir. Yükseldikçe hava soğur ve buhar küçük damlacıklara dönüşür. Bu damlacıklar toz taneciklerinin çevresinde toplanır. Milyarlarca damlacık bir araya geldiğinde gözle görünen bir bulut oluşur.”

Burada tek bir cümleye bağlı kalmak gerekmez; konu ve parçaların yer alması yeterli. Hafta 2'den sonra bu fikir kendi başına ders olarak sürdürülür, test değildir.
