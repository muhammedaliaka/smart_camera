# Alan başlangıç kartları

Ana raporun 4.4.3 numaralı “baştan anlatım” kuralı (D37): her alan sana **ilk kez geldiğinde sıfırdan** anlatılır — ne olduğu, neden yapıldığı, nasıl yapıldığı, neyin kaydedildiği ve **neyin kaydedilmediği**. Her kart tek seferliktir. Hedef sayılmaz, “yarım” sayılmaz; istediğin zaman yeniden açabilirsin.

Bütün alanlar için ortak üç not:

1. **Sistem hüküm vermez.** Puan, yüzde, doğru/yanlış, “gelişti/geriledi” yoktur. Kayıtları dışarıdaki bir değerlendirici (insan ya da yapay zekâ) yorumlar; yorum bu paketin işi değildir.
2. **Yardım dürüstçe yazılır.** A0 = yardımsız ilk deneme; A1 = ipucu veya araç; A2 = anahtar açıldıktan sonra; A3 = dış kaynak (kitap, sözlük, video); A4 = yapay zekâ veya çeviri aracı. Birden fazlası aynı anda olabilir. Yardım almak yasak değildir; saklanması kaydı bozar.
3. **Gönderim = “bitirdim, gönderiyorum” dediğin yanıt.** Taslak sayılmaz. Bir maddede **üçüncü gönderimden sonra** anahtar açılır; istersen daha önce de elle açarsın. Açıp açmadığın ve hangi gönderimde açtığın kayda yazılır. Anahtarı açmak onu okuduğun ya da anladığın anlamına gelmez; istersen “okudum / anlamadım” diye ayrıca işaretle.

## Kart 1 — İngilizce öğrenme (Tip 1)

**Ne:** Amerikan İngilizcesini dinleyip anlamak, tanışma ve iletişim için konuşabilmek; zamanla çeviri ve yapay zekâ aracı olmadan.

**Nasıl:** İlk dört günde iyi bir dış kaynakla (USA Learns, VOA) ders yaparsın; kaynak açılmazsa pakette yedek dersler (E1–E4) vardır. Kendi yazı ve ses görevlerin ayrıca kaydedilir. İkinci haftadan itibaren günde yaklaşık 3 yeni madde (sözcük ya da kalıp) tekrar kuyruğuna girer; her madde **3, 10, 20 ve 50 gün** aralıklarla (öğrenmeden 3, 13, 33, 83 gün sonra) bir kez daha sorulur.

**Kaydedilen:** madde, öğrenme günü, planlanan ve gerçek tekrar günü, ilk yardımsız yanıt, yardım kodu, anahtarın açılıp açılmadığı.

**Kaydedilmeyen / yapılmayan:** seviye etiketi (A1, A2…), puan, “doğru/yanlış” hükmü. Bu paket bir CEFR sınavı değildir.

**Hafta 2'den sonra:** “test” yalnız burada kalır; tekrarın kendisi de öğrenmedir, bu yüzden sonuç temiz bir sınav değil, tekrarlı geri çağırma kaydıdır.

## Kart 2 — Canlı pratik (Tip 2)

**Ne:** Konuşma turları, tanışma/network konuşmaları ve gerçek hayatta yazarken araya giren konuşmalarla birlikte yazma. Dinle, konuş, yaz ve hatırla kanallarının birleşimi.

**Nasıl:** Konuşma partnerin yok; bu yüzden önceden kaydedilmiş repliklerle ve **kendiliğinden oluşan** gerçek-hayat kesintileriyle çalışılır. Başkasının sesi kaydedilmez; yalnız kendi yazın, kendi sesin ve “yazarken biri konuştu” beyanın saklanır.

**Bu hafta:** Yalnız tanıtım (Gün 4'te yazarken kesinti provası ve Gün 6'da tanışma kaydı). C4–C6 sonraki haftaların konusu.

**Kaydedilmeyen:** kesintinin “hatasız sürdürülüp sürdürülmediği” hükmü; bunu dışarıdaki değerlendirici yazı öncesi/sonrası metne bakarak yorumlar.

## Kart 3 — Makale (Tip 3)

**Ne:** 25 konuluk, her konuda iki makalelik bir okuma havuzunun ilk örneği. Birinci makale giriş, ikincisi derinleşmedir.

**Nasıl:** Konuyu sen seçersin; zorunlu sıklık yoktur. Okuyunca kapat ve ana fikri, iki bilgiyi ve cevabını bilmediğin bir soruyu **kendi sözlerinle** anlat (yazı ya da ses). Anlamadığın yere “anlamadım” işareti koyabilirsin. İleride bazı günler “hazırlık → test” günüdür: aynı gün birinci makaleyi okur, ikinciyi anlatırsın; o günün yerine geçtiği konu atlanır.

**Bu hafta:** Yalnız Gün 3'teki ilk makale (G3). Havuzun geri kalanı bu pakette yok.

**Kaydedilmeyen:** soru puanı. Makalelerde bilinenler, tartışmalı olanlar ve bilinmeyenler ayrı yazılır.

## Kart 4 — Ders (Tip 4): hafıza sarayı ve ders başı stratejisi

**Ne:** Hafıza sarayı, bildiğin bir yerdeki durakları hatırlamak istediğin **sıralı** bilgiye bağlamaktır. Ders başı stratejisi (H5), bir dersin ilk söylenen düşüncesini kaybetmemek için dinlerken kafanda “konu + kaç parça” cümlesi tutmaktır. İkisi de **kendi başına ders**tir.

**İlkeleri:** hatırlama/ezber, bilgiyi rahatça akla getirebilmek, **rahatça sürdürülebilmek**. Zorlaşırsa artırılmaz, sadeleştirilir (örn. durak sayısı düşürülür). Her şeyi unutmama yöntemi değildir; yalnız sıralı bilgide denenir.

**Kaydedilen:** hangi güzergâh/liste, kaç öğe, yöntem kullanıldı mı (kullanıldı/kullanılmadı), yeniden baktın mı.

**Kaydedilmeyen:** yöntemin “işe yaradığı” hükmü. Hafta 2'den sonra bu alanda test yoktur; pratik kaydı vardır.

## Kart 5 — Mekanik alanlar (Tip 5)

**Kapsam:** spor; göz ve satır takibi; dinleme algılama (B1: duyduğunu yakalayıp yazma) ve anlama (B2: kendi sözlerinle anlatma); tek kanal tabanları ve basit kombinasyonlar (C0–C3: dinle, konuş, yaz, yerinde hareket); hafıza ve çoklu görev tabanları.

**Hafıza ve çoklu görev tabanları (H kodları):**

| Kod | Ne | Bu hafta nerede |
| --- | --- | --- |
| H1 | Sıralı yönerge: 6–8 öğeyi sırayla aktarmak | Gün 2 |
| H2 | Gecikmeli bilgi tohumu: tek ya da iki bilgi, sonra 5 dk / 30 dk / 2 saat / ertesi gün / bir hafta kontrol | Gün 5–6 (+ Gün 12–13) |
| H4 | Çok kısa gecikme: üç adımı duy, sayarak oyalan, adımları söyle | Gün 5 |
| H5 | Ders başı: bir mini dersin başında ne söylendiği | Gün 3 (tanışma), Gün 7 |
| H6 | Tekrar dinleme etkisi: aynı kısa duyuru farklı günlerde 1, 2, 3 kez | Gün 3, 4, 7 (+ 8) |

**Nasıl:** Antrenman gibi: tekrar, kademeli yük, çıktı birimi (km, set, tur, küme). Bir sonraki zorluğa geçmek **senin “bu rahat” bayrağınla** olur; ölçüt ya da puan yoktur. Yorgunluk ya da sinirlenme olursa bir önceki basamağa dönülür.

**Kaydedilen:** yapılan küme/set/km, hız ve zorluk düzeyi, zorlanma (0–10), yapıldı/yapılmadı, kendi satır kaybı sayımın.

**Kaydedilmeyen / yapılmayan:** gelişti/geriledi hükmü; göz hareketi ölçümü (satır sayımı **senin beyanındır**, göz izleme değildir); işitme testi (dikte ve dinleme görevleri işitme testi değildir); tanı.

**Güvenlik:** dinlerken hareket yalnız yerinde ya da güvenli kapalı alanda ve sağlam desteğe yakın; yürürken yazma, merdiven, trafik, kalabalık ve ağırlıkla çalışırken kombinasyon yok.
