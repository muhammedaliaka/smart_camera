# Gün 0 — Hazırlık ve cihaz provası

Bu kart, ana raporun 5.9 numaralı “Gün 0 doğrulama protokolü”nün **uygulamasız (elle) karşılığıdır**. Amacı, Gün 1'de ses kaydı, alarm veya dosya aktarımı yüzünden çalışmanın takılmamasıdır. Çalışma hedefi değildir; “yarım” sayılmaz. Atlarsan Gün 1'e başlayabilirsin, yalnız kayda “Gün 0 yapılmadı” yaz.

Ayrı bir takvim günü gerekmez: Gün 1'den önceki bir akşam yeter. Burada sorulan, telefonun ve bilgisayarın **bu işi yapıp yapamadığıdır**; sonuç bir puan değildir.

## Cihaz provası

| # | Ne yapılır | Ne yazılır | Rapor 5.9 |
| --- | --- | --- | --- |
| 1 | Telefonun ses kaydedicisiyle, ekran açıkken kısa bir kayıt al (bu denemede yaklaşık 5 dakika; sonra baştan sona çal) | Kayıtta boşluk var mı, dosya çalıyor mu, dosya uzantısı (örn. `.m4a`) | Test 1 |
| 2 | Aynı denemeyi ekranı kendin kilitleyerek tekrar et; yaklaşık bir dakika sonra aç | Kayıt kesintisiz sürdü mü; kesildiyse ne zaman | Test 2 |
| 3 | Pil ayarında Saat ve ses kaydedici uygulaması için “kısıtlama yok” ve otomatik başlatma seçeneklerine bak | Ayar bulundu mu, değiştirildi mi, önce/sonra fark | Test 4 |
| 4 | Saat uygulamasında 5 ayrı alarm veya zamanlayıcı kur (2–3 dakika sonrasına); çaldıkları gerçek saati yaz | Planlanan saat ile çalan saat farkı | Test 5 |
| 5 | Kulaklık mikrofonuyla ve telefon mikrofonuyla aynı cümleyi kaydet | Hangi giriş kullanıldı, hangisi daha anlaşılır (kendi kulağınla) | Test 9–10 |
| 6 | Bir kaydı USB-C kabloyla (telefon USB modu “Dosya aktarımı”) Windows'a kopyala | Kopya açıldı mı, dosya boyutu iki yerde aynı mı | Test 8 |
| 7 | Uçak modunu aç; bu paketten bir Markdown dosyası ile bir `.mp3` aç; bir kayıt al | Hangisi açılmadı | Test 11 |

Raporun 6, 7 ve 12 numaralı testleri (depolama kalıcılığı, uygulamada kaldığı yerden devam, Windows'ta uygulama) bir uygulama gerektirir; bu pakette uygulama olmadığı için yapılmaz.

HyperOS menü adları sürüme göre değişir. Pil ve otomatik başlatma ayarları için telefonun Ayarlar araması kullanılabilir; yol bu paketle **cihazda doğrulanmadı**.

## Dosya adı ve klasör düzeni

Kaydettiğin her ses dosyasını şu biçimle yeniden adlandır:

`G<gün, 2 hane>_<görev>_S<soru, 2 hane>_D<deneme, 2 hane>_<YYYYMMDD-HHMM>.m4a`

Örnek: `G05_T1_S03_D02_20261030-1815.m4a` — Gün 5, T1 görevi, 3. soru, 2. deneme, 30 Ekim 2026 18:15. Gün 0 provası için `G00_...`.

**Dikkat:** buradaki `G`, **Gün** demektir. Ana raporun 15. bölümündeki `G01`–`G26` kodları “devredilen karar” numaralarıdır; ikisi karıştırılmamalıdır.

Klasör: `HAFTA1\G00`, `HAFTA1\G01` … `HAFTA1\G08`. Her günün klasöründe ses dosyaları ve `yanitlar.md` bulunur; `yanitlar.md` içinde **satır başına bir deneme** yazılır (alanlar için `kayitlar/YANIT_SABLONU.md`). Eski bir yanıtı silme; yeni deneme yeni satır olur.

Paketleme ve yedek adımları `kayitlar/PAKETLEME_VE_YEDEK.md` dosyasındadır.

## Gizlilik

Kayıtlar kendi sesini içerir. Takma ad kullan; başka birinin sesini kaydetme. Pakette sağlık beyanı varsa bir yapay zekâ hizmetine yüklemeden önce o hizmetin veri saklama ayarlarına bak.

## Gün 0 notu (kopyala, doldur)

- Tarih / cihaz / kulaklık:
- Kayıt 1–2 sonucu:
- Pil ve otomatik başlatma ayarı:
- Alarm sapması (5 deneme):
- Mikrofon karşılaştırması:
- USB-C aktarım sonucu:
- Uçak modu sonucu:
- Yapılmayanlar ve nedeni:
