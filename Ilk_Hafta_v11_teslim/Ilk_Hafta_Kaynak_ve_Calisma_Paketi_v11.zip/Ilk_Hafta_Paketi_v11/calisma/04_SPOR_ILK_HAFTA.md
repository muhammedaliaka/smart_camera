# İlk hafta spor kartı

Bu kart, ana raporun 11. bölümündeki 50/30/15/5 önceliğini (dayanıklılık, güç, denge, çeviklik) ve ilk hafta kademeli başlangıcını (11.11) uygulayan **önerimdir**. Mesafe ve setleri yüzdelere tam çevirmek mümkün olmadığından bu kartın oranları tam gerçekleştirdiği veya 70–80 dakika eşdeğeri olduğu iddia edilmez; ilk hafta fiili yük gözlenir. Dakika görevi yoktur; hedeflere uyku öncesine (≈23:00) kadar ulaşmak yeterlidir. Test günlerinde (5–7) şiddetli hareket yatıştan yaklaşık bir saat önce biter.

**Bu hafta yüklü (dambıl veya bar) direnç çalışması yok.** Gözetim çoğunlukla olmadığı için kartta bar hareketi bulunmaz; güç hedefi vücut ağırlığıyla ve teknik odaklı yapılır. NSCA'nın gençlerde direnç çalışması önerileri uygun teknik, gözetim ve **ardışık olmayan günler**i içeriyor; bu ilke yüklü çalışma başlayınca (Hafta 2+) uygulanır, bu haftaki hafif teknik hareketler için değil. [Resmî metin](https://www.nsca.com/globalassets/about/position-statements/position_stand_youth_resistance_training---2009.pdf)

## Hareketlerin anlamı

- **Sandalyeye otur-kalk:** Kaymayan, sağlam sandalyeyi duvara daya. Ayakların yerde; kontrollü otur ve ayağa kalk. Ellerden destek gerekirse kullan ve bunu kaydet.
- **Duvar şınavı:** Ellerin omuz hizasında duvarda; vücudu tek parça tutarak dirsekleri bük ve it. Ayakları duvardan uzaklaştırmak zorlaştırır; ilk hafta kolay konum kullan.
- **Kalça köprüsü:** Sırtüstü, dizler bükülü ve ayaklar yerdeyken kalçayı rahat bir yüksekliğe kaldırıp indir. Belini aşırı çukurlaştırma.
- **Yüksüz çekiş provası:** Otururken gövden dik; dirsekleri yavaşça gövde yanına çekip bırak. Bu ağır çekiş yerine geçen kuvvet ölçümü değildir; hareket sırasını öğrenme provasıdır.
- **Denge turu:** Sağlam destek yanında, bir ayağı diğerinin önüne koyup üç rahat nefes dur; taraf değiştir. Ardından tek ayakta üç rahat nefes dene. Destek alman serbesttir.
- **Çeviklik turu:** Zemine hayalî bir çizgi koy. Çizginin iki yanına kontrollü beşer adım geç. Sıçramak veya hız yarışı yapmak gerekmiyor.

## Günlere göre çekirdek

| Gün | Dayanıklılık | Güç/teknik | Denge | Çeviklik |
| --- | --- | --- | --- | --- |
| 1–3 | Kendi rahat hızında 1,5–2 km yürüyüş; gerekirse parçalara böl | Dört hareketin her biri 1 set × 6 rahat tekrar | 1 tur | 1 tur |
| 4–6 | Rahat geldiyse 2,5–3 km (zorlanıyorsan 2–2,5 km); gerekirse parçalara böl | Dört hareketin her biri 2 set × 6–8 tekrar; kolay seçenek korunur | 2 tur | 2 tur |
| 7 | **Hafif gün önerisi:** rahat yürüyüş, önceki en kolay mesafe yeterli. İstersen tam çekirdek | 1 kolay teknik turu | 1 kolay tur | Rahat hareketlilik; hız zorunlu değil |

Bu ilk hafta **ek yük ve zorunlu eklenti yok**. Sonraki basamağa geçiş, öncekinin rahat ve kontrollü olmasıyla kullanıcı kararıdır. Gün 4 geldi diye zorlayan yük artırılmaz. Nefesin ve hareketin toparlanınca sonraki sete geç. Isınmaya birkaç rahat adım ve hareketlerin kolay provasıyla başla. Hafif gün, ana raporun 11.11 numaralı bölümündeki önerinin ilk haftaya uyarlamasıdır; “hepsi aynı olacak” tercihine aykırı bulursan tam çekirdeği yap ve kaydet.

Hafta sonuna denk gelen bütün günler ekipmansız seçeneklerle yapılabilir. Ağrı veya baş dönmesinde hareketi bırak; o gün hedefi zorlayarak tamamlama. Spor borcu ertesi güne eklenmez.

## Başlangıç gözlemi — isteğe bağlı (rapor 11.13)

Düşük riskli, hedeflerin **içinde** yapılan bir ölçüm kaydıdır; hedef değildir, puanlanmaz ve standartla karşılaştırılmaz. İstemediğin parçayı çıkarabilirsin. 1RM veya bar/yük testi yapılmaz, hiçbir gözlemde maksimal deneme yok.

| Gün | Gözlem | Kayda yazılan |
| --- | --- | --- |
| 1 | Aerobik: kendi hızında 1,6 km yürüyüş; denge: sağlam destek yanında tek ayak durma | Mesafe ve geçen süre (süre burada bir kayıttır, hedef değil); destek kullanıldı mı; zorlanma (0–10) |
| 1 | Esneklik: otur-uzan (bacaklar uzatılmış, öne uzan; zorlama) | Nereye kadar ulaştığını kendi cümleninle |
| 2 | Kas dayanıklılığı: duvar şınavı ve karın kıvırma (sırtüstü, dizler bükülü, omuzları hafifçe kaldır). Form bozulmadan dur; her biri en çok 20 | Tekrar sayısı, durma nedeni (form/yorgunluk/20'ye ulaştım), zorlanma |

Kaynak ve sınır: gençlere yönelik saha testi bataryalarından (FITNESSGRAM tipi) esinlenilmiştir; o bataryalar sağlık standartlarına göre puanlar, burada **puanlama kullanılmaz**. Çıktı, hedef sayılarını ilerde kalibre etmek için tanımlayıcı veridir (rapor 11.3).

## Kayda girecekler

Gerçek mesafe, hareket/set/tekrar, destek kullanımı, zorlanma notu (0–10), yarım kaldıysa nerede kaldığı. Süreyi istersen gözlem olarak ekle; süre doldurmak hedef değil. Test günlerinde (5–7) yorgunluk ve uyku notu da yaz. Genel egzersiz videosu için [Nike Training Club](https://www.nike.com/tr/ntc-app) isteğe bağlıdır; videodaki ağır veya hızlı seçenek bu karttaki kolay seçeneği otomatik değiştirmez.
