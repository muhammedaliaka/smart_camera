# Dış kaynak uygun değilse kullanılacak dört ders

Bu dersler özgün başlangıç materyalidir. Doğal Amerikan İngilizcesi ses modeli için öncelik VOA'dır. Aşağıdaki yazılı dersler tek başına telaffuz ve dinleme eğitiminin yerini tutmaz. Bir derste bilmediğin sözcük varsa Türkçe karşılığına bak; çalışma sırasında yardım serbesttir.

## E1 — Kendini tanıtma

**My name is ...** = Benim adım ... / **I am ...** = Ben ... / **I live in ...** = ...'da yaşıyorum. İngilizcede kısa bir tanıtım cümlesinde özne ile yüklemi birlikte kurarsın: **I am a student.** “Ben öğrenciyim.”

**I am → I'm**, **my name is → my name's** günlük konuşmadaki kısaltmalardır. **a student** bir öğrenci demektir; **student** öğrenci, **live** yaşamak, **city** şehir, **learn** öğrenmek.

Örnek: **Hi. I'm Deniz. I live in Bursa. I'm a student. I learn English.**

Yap: Örneği kendi bilgilerine göre dört cümleyle değiştir. Gerçek ad yerine takma ad olur. Sonra metni kapatıp kendini tanıt. Nerede durduğunu bir notla yaz.

Kendi karşılaştırman için örnek cevap: **Hi. My name is Ali. I live in Türkiye. I'm a student. I learn English.** Bu tek geçerli tanıtım değildir.

## E2 — Soru sorma ve tekrar isteme

**What is your name?** = Adın ne? / **Where do you live?** = Nerede yaşıyorsun? / **Are you a student?** = Öğrenci misin?

**Can you repeat that, please?** = Tekrar eder misin, lütfen? / **Can you speak more slowly, please?** = Daha yavaş konuşur musun, lütfen? / **What does ... mean?** = ... ne demek?

**repeat** tekrar etmek, **slowly** yavaşça, **mean** anlamına gelmek, **please** lütfen. “I don't understand.” = “Anlamıyorum.” Bunu söylemek iletişimin bir parçasıdır.

Yap: İki kişilik bir tanışma yaz. İlk kişi adını sorsun; ikinci kişi yanıtlasın ve karşı soru sorsun. Ardından üç farklı yardım isteme cümlesini kendin söyle. Okuyarak söylediysen “metinden” yaz.

Örnek akış: **Hello. What's your name? — I'm Ece. What's your name? — I'm Sam. Nice to meet you. — Nice to meet you, too.** İfadelerin anlamını biliyorsan cümleleri değiştir.

## E3 — Bir nesneyi ve yerini anlatma

**This is a notebook.** = Bu bir defter. / **It is on the desk.** = Masanın üzerinde. / **The bag is under the chair.** = Çanta sandalyenin altında.

**on** üzerinde; **under** altında; **next to** yanında; **desk** çalışma masası; **chair** sandalye; **bag** çanta; **notebook** defter.

**This is ...** bir şeyi gösterir. Bir nesneden yeniden söz ederken **it** kullanabilirsin: **This is a bag. It is blue.** “Bu bir çanta. O mavi.”

Yap: Çevrenden üç nesne seç; her biri için ne olduğunu ve yerini belirten iki cümle yaz. Sonra bir nesnenin yerini değiştirip yeni yerini söyle. Yerini gerçekten değiştiremiyorsan hayalî olduğunu belirt.

Örnek: **This is a book. It is on the desk.** Aynı örneği üç kez kopyalamak yerine yeni nesne kullan.

## E4 — Günlük düzen ve kendi fikrin

**I read every day.** = Her gün okurum. / **I study after school.** = Okuldan sonra çalışırım. / **I like science.** = Bilimi severim. / **I want to understand videos.** = Videoları anlamak istiyorum.

**after** sonra; **before** önce; **every day** her gün; **want** istemek; **understand** anlamak; **because** çünkü.

**I like ... because ...** nedenini ekler. Örnek: **I like science because I enjoy learning new things.** = Yeni şeyler öğrenmekten hoşlandığım için bilimi severim. Bu uzun cümle şimdilik zor gelirse iki kısa cümle kurabilirsin.

Yap: Kendi günün hakkında dört cümle ve İngilizceyi neden öğrenmek istediğin hakkında iki cümle yaz. İstersen kısa cümle kullan. Sonunda bir soru sor ve anlaşılmadığında kullanacağın bir cümle ekle.

## Tekrar kuyruğuna hangi maddeler girer?

Her gün bütün dersi kart yapmak yerine **3 yeni sözcük veya kullanışlı kalıp** seçmek başlangıç önerimdir. Maddeyi, anlamını ve kendine ait örneğini yaz. Öğrenme tarihini kaydet. Aynı maddenin dış kaynakta tekrar görülmesini “ek karşılaşma” olarak belirtebilirsin; bunu bağımsız geri çağırma denemesi gibi yazma.

Maddelerin tekrar günleri `kayitlar/INGILIZCE_TEKRAR_TAKVIMI.xlsx` dosyasında hesaplanır (kural: `kayitlar/INGILIZCE_TEKRAR_KURALI.md`). Yedek derslerden gelen maddeler de aynı kuyruğa girer; hangi dersten geldiğini `kendi_ornegim` yanına yazabilirsin.
