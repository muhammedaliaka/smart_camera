# Tamamlanmış sayılmayan ve doğrulanmayan parçalar

Bu dosya, içerik hazırlığı ile çalışan ürün ve yapılmış ölçümün karışmaması içindir. “Yapıldı” yazan her satır yalnız yazılı olan kontrolü anlatır; kullanıcı cihazında yapılmış bir ölçüm değildir.

| Parça | Şu anki durum |
| --- | --- |
| İlk dört gün dış kaynak seçimi | Resmî sayfalardan araştırıldı ve 27 Ekim 2026'da bağlantıların çoğu yeniden açılıp içerik karşılaştırıldı (Busuu yardım sayfası 403 verdi, doğrulanamadı). Telefonunda kullanıcı denemesi yapılmadı |
| Gün 0 cihaz provası | Elle yapılacak liste yazıldı; **cihazda yapılmadı**. Rapor 5.9'daki 12 testin üçü (6, 7, 12) bir uygulama gerektirdiği için bu pakette yoktur |
| İngilizce yedek dersler | Dört özgün yazılı ders hazır; doğal ses için dış kaynak kullanılıyor |
| Gün 1–4 prova soruları ve ses dosyaları | Hazır (C0 dinleme, dikte tanışma, H5 tanışma, H6 duyurusu). Prova soruları (P1, P2) ve anahtarlar özgündür; standartlaştırma yapılmadı |
| Gün 5–7 görev, soru ve anahtarları | Hazır; psikometrik doğrulama, seviye standardizasyonu veya madde eşdeğerliği çalışması **yapılmadı**. Okuma metinleri yaklaşık 155 sözcüktür ve tek ortamda (ekran) okunur: kitap/PDF/ekran karşılaştırması bu hafta mümkün değildir |
| H5 A/B stratejisi | Sıra sabit (önce A sonra B) ve iki ders farklı içeriktedir; sıra dengelenmedi. Bir haftada yapılabilen dengelemesi yok |
| H6 tekrar dinleme | Kontroller aynı içerik üzerinde tekrarlanır; her kontrol ayrıca bir hatırlama alıştırmasıdır. Tek kişi, tek içerik: genellenemez |
| İngilizce ses uyaranları | Yapay (nöral) Amerikan İngilizcesi sesleri; bilgisayar ortamında üretildi, **otomatik tanıma** ile geri okuma yapıldı. **İnsan dinleme kontrolü yok**; kullanıcının telefon ve kulaklığında denenmedi. Gerçek insan konuşmasının çeşitliliğini temsil etmez |
| Türkçe ses uyaranları | Tek erkek nöral ses; otomatik tanıma ile geri okundu, **insan dinleme kontrolü yok**. Bazı tek sözcüklük öğeler (sayılar, gün adları, sıra sözcükleri) otomatik tanıma ile ayrıca doğrulanamadı (çok kısa kayıt). Ses lisansı CC BY-NC-SA 4.0: yalnız kişisel, ticari olmayan kullanım. Seslerin gerçek bir kişiye ait olduğu iddia edilmez |
| Dikte (B1) öğeleri | Yeni, özgün küçük kümeler. Dosyalar arasında hız, sıra ve öğe farkı birlikte değişir; ayrıştırılamaz |
| Otomatik kayıt uygulaması | Bu teslimde geliştirilmedi. Checkpoint, üçüncü gönderimde otomatik açma, mikrofon kesinti olayları ve ZIP üretimi çalışan yazılım olarak sunulmuyor; **elle/köprü kaydı** kullanılır |
| HyperOS/Windows doğrulaması | Mikrofon seçimi, kayıt kesintisi, uçak modu, ZIP oluşturma ve geri yükleme cihazda yapılmadı. `kayitlar/PAKETLEME_VE_YEDEK.md` içindeki PowerShell komutları da **denenmedi** |
| Tekrar takvimi (xlsx) | Formüller LibreOffice ile yeniden hesaplanarak bir geçici kopyada denendi; Excel ve telefon tablo uygulamalarında **denenmedi**. Örnek sayfa gerçek veri değildir |
| Kayıt ve yedek | Boş şablonlar verildi; kullanıcının gerçek verisi yok. Sesleri telefon kaydedicisinden elle eklemek gerekir |
| Makale havuzu | 25 konu / 50 makalelik havuz tamamlanmadı; bu pakette yalnız ilk haftanın metinleri var |
| Spor | İlk hafta kolay başlangıç önerisi ve isteğe bağlı gözlem var; teknik gözlem ve yük kalibrasyonu yapılmadı. Bir spor uzmanı ya da aile hekimi onayı yoktur |
| Sağlık | Yeni sonuç gelmedi. Göz, kulak-burun ve diş kontrolü tarihleri belli değil; tarih sorulmadı, tanı ya da varsayılan muayene sonucu eklenmedi |

Eğitim kaynaklarının bir kısmı çevrimiçi. Paketteki Markdown, CSV, xlsx ve ses dosyaları cihazda uygun okuyucu/oynatıcı ile internetsiz açılabilir. Bu, dış kaynakların çevrimdışı işlevlerinin veya Redmi üzerindeki bütün akışın test edildiği anlamına gelmez.

İlk dört günün yazılı/harici kaynak çalışmaları bu eksiklerden bağımsız yürütülebilir. Kayıt açısından kritik testleri tam uygulama özellikleriyle yapmak istiyorsak, yazılım hazırlığı bitmeden o akış hazır ilan edilmez. Elle yürütülen parçalar “elle kayıt” olarak etiketlenir.

## Bir şey çalışmazsa

Çalışmayan adımı (ses açılmadı, komut hata verdi, tablo hesaplamadı) `HAFTA1\EKSIKLER.md` dosyasına tarih, cihaz ve ne olduğuyla yaz; görevi yapılmış gibi kaydetme. Dış değerlendirici bu notları eksik veri olarak okur.
