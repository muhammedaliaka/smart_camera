# Yanıt ve deneme kaydı

Bu dosya boş şablondur; doldurulana kadar yapılmış çalışma veya test sonucu içermez. Her gün için `HAFTA1\G0X\yanitlar.md` dosyasında bu bölümü **satır başına bir deneme** olacak şekilde kullan (köprü protokolü, ana rapor 13.6). Yeni deneme yeni satır; eski satır silinmez. Elle tutulan her şey **“elle/köprü kaydı”** sayılır; otomatik ölçülmemiş olaylar otomatikmiş gibi yazılmaz.

## Günlük bağlam — isteğe bağlı

Tarih / çalışma günü:
Kullanılan cihaz ve kulaklık:
Uyku / şekerleme / yorgunluk hakkında kısa not (yatış-kalkış saati, yorgunluk 0–10):
Ortam hakkında kısa not:

## Her deneme için bu bölümü çoğalt

- Görev ve soru kimliği (örn. `G05-R1`, soru 3):
- Gönderim no (1, 2, 3…):
- Tarih/saat ve saat dilimi:
- Yanıt / bilmiyorum:
- Yanıt kipi: yazı / ses / ikisi
- Ses dosyasının tam adı ve uzantısı (`G05_T1_S03_D02_20261030-1815.m4a` biçimi):
- Anahtar: kapalı / elle açıldı / üçüncü gönderimde açıldı
- Yardım kodu (birden fazla olabilir): **A0** yardımsız ilk deneme · **A1** ipucu veya araç · **A2** anahtar açıldıktan sonra · **A3** dış kaynak (kitap, sözlük, video) · **A4** yapay zekâ veya çeviri aracı
- Anahtarı açtım: evet/hayır; saat:
- Okudum: evet/hayır/belirtmedim
- Anlamadım işareti: varsa
- Bu yeni denemenin ilişkili olduğu önceki deneme:
- Ek not / kesinti / kayıt arızası:

Birden fazla yardım birlikte kullanılabilir; örneğin hem sözlük (A1) hem anahtar sonrası (A2). Bu nedenle yardım durumlarını tek bir koda zorlayıp birini kaybetme. İlk bağımsız yanıt (**A0**) için hem anahtar kapalı olmalı hem de yardım kullanılmamış olmalı. Sonraki tekrarlarda madde daha önce öğrenilmiştir; “bağımsız” bütün yaşamında ilk kez karşılaşma anlamına gelmez.

## Gönderim sayacı (anahtar kuralı için)

Üçüncü gönderimden sonra anahtar açılır; istersen daha önce elle açarsın. Her soru için bir satır tut:

| Soru kimliği | 1. gönderim (saat) | 2. gönderim (saat) | 3. gönderim (saat) | Anahtar açıldı (saat, elle / 3. gönderim) |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |

**Gönderim** = “bitirdim, gönderiyorum” dediğin yanıt. Taslak ve yarım bırakılan yazı sayılmaz. Düzeltmek için yeniden gönderdiğin yanıt yeni gönderimdir.

## Gecikmeli kontrol

- Bilgi kimliği ve sunum kipi: görsel / sesli
- İlk sunum tarihi/saati:
- Kontrolün planlanan zamanı:
- Kontrolün gerçekleşen zamanı:
- Arada yeniden gösterim / ipucu / tekrar karşılaşma:
- Kontroldeki yanıt aynen:
- Neyi hatırlamam gerektiğini çıkaramadım: evet/hayır

H6 için ayrıca: kaçıncı dinlemeden sonra kontrol (1, 2 veya 3) ve dinleme sayısı. H4 için: sayma boyunca kaç saniye geçti (ses kaydından sonradan okunur), adımları söylerken yardım alındı mı.

## Dinleme / dikte için

Dosya adı, **tekrar açma sayısı**, ses seviyesi beyanı, kulaklık/hoparlör, metnin görünür olup olmadığı, yazdığın/söylediğin yanıt aynen.

## Okuma / spor / kesinti için kısa kayıt

Okuma: metin ve koşul (kılavuzsuz / parmak / cetvel), ortam (kitap / PDF / ekran), kendi satır kaybı/geri dönüş sayımım veya “sayamadım”, anlatım dosyası.

Spor: hedef, gerçekleşen mesafe/hareket/set/tekrar, destek, zorlanma beyanı (0–10), not. Süre yalnız gözlemse öyle yaz.

Kesinti: kendim açtığım kart / doğal konuşma, yaklaşık ne zaman, yazıya dönünce kendi gözlemim. Doğal konuşmanın sesi kaydedilmez.
