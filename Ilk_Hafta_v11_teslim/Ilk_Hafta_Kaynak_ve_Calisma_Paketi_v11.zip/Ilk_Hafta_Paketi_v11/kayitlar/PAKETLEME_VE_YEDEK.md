# Paketleme ve yedek (uygulamasız köprü protokolü)

Ana raporun 6.6, 6.9 ve 13.6 numaralı bölümlerinin Hafta 1 için elle uygulanan karşılığıdır. Otomatik kayıt uygulaması yok; bu yüzden aşağıdaki her adım elle yapılır ve kayda **“elle/köprü kaydı”** diye yazılır. Bu adımlar telefon ve Windows bilgisayarda bu pakette **denenmedi**; ilk uygulamada çalışmayan bir adım olursa `EKSIKLER.md` mantığıyla not et.

## Ne zaman

- Her test gününden sonra (Gün 5, 6, 7) o günün paketi.
- Hafta bitmeden bir kez bütün `HAFTA1` paketi (Gün 8'de taşan test varsa sonrasında).
- Ayda bir ikinci ortam kopyası ve geri yükleme denemesi (rapor 6.9).

## Klasör düzeni

```
HAFTA1\
  G00\ … G08\      her gün: yanitlar.md + ses dosyaları (G05_T1_S03_D02_20261030-1815.m4a)
  EKSIKLER.md      yapılamayan veya eksik kalan parçalar ve nedeni
  OKUMA_KILAVUZU.md kendi yazdığın kısa not (içeriği 2. adımda)
  checksums.sha256  aşağıdaki komutla üretilir
```

Ad kuralı `calisma/01_GUN_0_HAZIRLIK.md` içinde: `G` = **Gün**; ana raporun `G01–G26` karar kodlarıyla karıştırma. Dosya adlarında Türkçe karakter ve boşluk kullanma.

## Adımlar

1. Telefondaki ses kayıtlarını ve `yanitlar.md` dosyalarını adlandırma kuralına göre `HAFTA1\G0X` klasörüne koy.
2. `OKUMA_KILAVUZU.md` dosyasına şunları yaz: paketin elle tutulmuş bir kayıt olduğu; sistemin puan ya da hüküm vermediği; yardım kodları A0–A4; hangi görevlerin yapılmadığı; kayıtta kullanılan takma ad. Bu pakete ait `00_BURADAN_BASLA.md` ve ana rapor (bölüm 18, değerlendirici talimatı) dış değerlendiriciye birlikte verilebilir.
3. Klasörü ZIP yap (telefonda dosya yöneticisiyle ya da Windows'ta sağ tık → “Sıkıştırılmış klasöre gönder”). Ad önerisi: `HAFTA1_G05-G07_20261102.zip`.
4. Telefonun USB modunu “Dosya aktarımı”na al, USB-C kabloyla Windows'a kopyala: `Belgeler\Ogrenme_Yedek\2026\`. Kopyalamadan sonra dosya boyutlarını iki yerde karşılaştır.
5. Bütünlüğü doğrula (PowerShell). Paketin kendi özet dosyasını üretmek için `HAFTA1` klasöründe:

```powershell
$root = (Get-Location).Path
Get-ChildItem -Recurse -File | Where-Object { $_.Name -ne 'checksums.sha256' } | ForEach-Object {
  $rel = $_.FullName.Substring($root.Length + 1).Replace('\','/')
  '{0}  {1}' -f (Get-FileHash $_.FullName -Algorithm SHA256).Hash.ToLower(), $rel
} | Set-Content -Encoding ascii checksums.sha256
```

Kopyayı doğrulamak için aynı klasörde:

```powershell
Get-Content checksums.sha256 | ForEach-Object {
  $h, $p = $_ -split '  ', 2
  if ((Get-FileHash $p -Algorithm SHA256).Hash.ToLower() -ne $h) { "UYUMSUZ: $p" }
}
```

Çıktı boşsa her dosya özetle eşleşir. Bu komutlar bu pakette denenmedi; çalışmazsa tek dosya için `Get-FileHash dosya_adi -Algorithm SHA256` kullan.

6. **İkinci kopya:** Windows'taki yedeği harici USB belleğe ya da diske kopyala (3-2-1: üç kopya, iki farklı ortam, biri başka yerde). Telefondaki kopya tek başına yedek sayılmaz.
7. **Dışarı çıkacak kopya** (bulut, başkasının cihazı, yapay zekâ hizmeti) önce şifrelenir: 7-Zip → “Arşive ekle” → biçim **7z**, şifreleme yöntemi **AES-256**, **“Dosya adlarını şifrele”** işaretli. Zip biçiminde dosya adları görünür kalır; Windows'un yerleşik zip aracı parola desteklemez. Parolayı kaybedersen veri kaybolur; parolayı ayrıca güvenli bir yerde sakla.
8. Ayda bir bir paketi aç, `checksums.sha256` ile doğrula: “yedek ancak geri yüklenebildiği kadar yedektir”.

## Gizlilik

Paket kendi sesini ve sağlıkla ilgili beyanlarını içerebilir. Bir yapay zekâ hizmetine yüklemeden önce hizmetin veri saklama ve kullanma ayarlarına bak; paketi oluştururken **ses dahil / hariç** seçimini bilinçli yap (ana rapor 6.8). Aile ile paylaşım tercihi sana aittir. Başka birinin sesini kaydetme; pakette ad-soyad yerine takma ad kullan.

## Dış değerlendiriciye gidecek sorular

“Hangi beceride hangi gözlem var? Hangi açıklamalar belirsiz? İkinci haftanın çalışma yükünü hangi somut kayda göre değiştirmeliyiz?” Değerlendirici yorumunu kendi adı, sürümü ve tarihiyle ayrı bir `yorum\` klasörüne yazar; kayıt dosyalarını değiştirmez.
