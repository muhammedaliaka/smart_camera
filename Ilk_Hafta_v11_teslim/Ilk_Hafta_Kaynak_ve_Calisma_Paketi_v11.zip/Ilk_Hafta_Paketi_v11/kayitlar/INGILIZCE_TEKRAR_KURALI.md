# İngilizce tekrar kaydı

Yeni madde: sözcük, kalıp veya kısa cümle. Başlangıç önerisi ikinci haftadan itibaren günlük **3 yeni madde**; gerçek yük gözlemine göre değişebilir. İlk haftanın eğitim maddelerini de eklemek kullanıcının seçimi. Testte kullanılan kilitli maddeler eğitim kuyruğuna otomatik alınmaz.

| Olay | Önceki olaydan bekleme | Gecikme yoksa öğrenmeye göre gün |
| --- | --- | --- |
| Öğrenme | — | 0 |
| Tekrar 1 | 3 gün | 3 |
| Tekrar 2 | 10 gün | 13 |
| Tekrar 3 | 20 gün | 33 |
| Tekrar 4 | 50 gün | 83 |

Her tekrarda önce anahtara bakmadan kendi yanıtını ver. Sonra ihtiyaç duyduğunda anahtarı aç. Hüküm ve puan yok. Yardımı ve ilk yanıtını ayrı tut (yardım kodları A0–A4: `YANIT_SABLONU.md`).

**Gecikme uygulaması — tasarım tercihim:** Tekrar 1 planlanandan 2 gün geç yapıldıysa, Tekrar 2 o gerçekleşen tarihten 10 gün sonra planlanır. Eski plan silinmez. Biriken adımları aynı gün peş peşe yaptırıp aralıklı tekrar yapılmış gibi kaydetmeyiz. Günlük genel hedef kuyruğunun önce yarım hedef kuralı ayrıca devam eder.

Örnek (gerçek veri değil): madde 1 Kasım'da öğrenildi → Tekrar 1 nominal 4 Kasım. 6 Kasım'da yapıldı (2 gün geç). Tekrar 2 = 6 Kasım + 10 gün = 16 Kasım (nominal olarak 14 Kasım'dı; eski plan 14 Kasım saklanır). Tekrar 3 = Tekrar 2'nin gerçek tarihi + 20 gün; Tekrar 4 = Tekrar 3'ün gerçek tarihi + 50 gün.

**Yük hesabı:** Günde N yeni madde ve madde başına dört tekrar varsayılırsa, gecikme yokken 0 tabanlı d gününde yaklaşık yük: d<3 için 0; 3≤d<13 için N; 13≤d<33 için 2N; 33≤d<83 için 3N; d≥83 için 4N. Gün sayısını birinci günden numaralandırırsan eşikler 4, 14, 34, 84 olur. Bu takvim farkı günlük uzun dönem yükünü yarıya indirmez.

Günde 3 yeni madde için dört aşama birden aktif olduğunda yaklaşık **12 tekrar/gün**; 5 madde için **20 tekrar/gün**. Bunlar süre taahhüdü veya kullanıcı sonucu değil, kuyruk hesabıdır. Yeni madde girişi durursa kalan tekrar kuyruğu zamanla azalır.

## İlk hafta maddeleri

Gün 1–4'te öğrenilen maddelerin nominal tekrar günleri `calisma/02_ILK_DORT_GUN.md` içindeki tabloda ve `INGILIZCE_TEKRAR_TAKVIMI.xlsx` içinde hesaplanır. Gün 2, 3 ve 4 maddelerinin ilk tekrarı Gün 5, 6 ve 7'ye, yani test günlerine düşer; o günlerde tekrarı kısa tut.

## Dosyalar

- `INGILIZCE_TEKRAR_TAKVIMI.xlsx` **esas kayıt ve hesaplayıcıdır**: öğrenme tarihini yazarsan nominal ve güncel planlanan tarihleri hesaplar; gerçekleşen tarihi sen yazarsın. Sütunları aşağıdaki CSV başlığıyla uyumludur.
- `INGILIZCE_TEKRAR.csv` aynı alanların boş şablonudur (uygulama ya da tablo programına aktarım için). Bir maddeyi iki yerde birden tutma; esas kaynak xlsx olsun.
- Tek madde Anki ve bu kuyruğa aynı anda bağlanmaz; dış kaynakta ek karşılaşma olursa bunun notu tutulabilir.
