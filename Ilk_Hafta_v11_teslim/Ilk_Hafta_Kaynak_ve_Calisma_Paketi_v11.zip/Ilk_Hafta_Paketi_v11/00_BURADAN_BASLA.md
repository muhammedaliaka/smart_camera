# İlk hafta: 4 gün çalışma + 3 gün test (v11)

27 Ekim 2026 · v10 paketinin hata analizinden sonra yeniden kurulmuş sürüm. Neyin değiştiği ve hangi hataların bulunduğu `09_DEGISIKLIK_VE_HATA_RAPORU.md` dosyasında; sistemin tamamı `10_ANA_RAPOR_v11.md` içinde.

## Bu paket nedir, ne değildir?

Bu paket bir eğitim ve test **içeriğidir**: kaynak seçimi, günlük hedefler, soru ve metinler, **hazır ses dosyaları**, cevap anahtarları ve elle tutulan kayıt şablonları. Otomatik kayıt yapan, üçüncü gönderimde anahtar açan ya da ZIP üreten bir uygulama **değildir**; o parça henüz yok. Bu yüzden her kayıt “elle/köprü kaydı” olarak yazılır (`kayitlar/PAKETLEME_VE_YEDEK.md`).

Sistem yalnızca kaydeder ve raporlar: **puan, doğru/yanlış hükmü, tanı yoktur.** Yorumu dış değerlendirici yapar.

## Klasörler

| Yer | İçinde ne var | Ne zaman |
| --- | --- | --- |
| `01_KAYNAK_SECIMI.md` | Hangi dış kaynak, neden, nasıl kullanılır | Başlamadan önce |
| `calisma/01_GUN_0_HAZIRLIK.md` | Telefon ve kulaklık provası, dosya adı kuralı | **Gün 0** (Gün 1'den önce) |
| `calisma/02a_ALAN_BASLANGIC_KARTLARI.md` | Her alanın kısa başlangıç kartı | Alana ilk girerken |
| `calisma/02_ILK_DORT_GUN.md` | Gün 1–4 görevleri | Gün 1–4 |
| `calisma/02b_PROVA_VE_GUN1_4_ANAHTARLARI.md` | Gün 1–4 prova soruları ve anahtarları | Görevi yaptıktan sonra |
| `calisma/03_INGILIZCE_YEDEK_DERSLER.md` | Dış kaynak açılmazsa dört kısa ders | Gerekirse |
| `calisma/04_SPOR_ILK_HAFTA.md` | İlk hafta spor kartı | Her gün |
| `calisma/ses/` | Gün 2–4 sesleri | Gün 2–4 |
| `kayitlar/` | Yanıt şablonu, İngilizce tekrar kuralı, tekrar takvimi (xlsx), paketleme ve yedek | Her gün |
| `test_gununde_ac/` | Gün 5, 6, 7 görevleri, okuma metinleri, anahtarlar, sesler | **Gün 4 bitmeden açma** |
| `EKSIKLER.md` | Yapılmayan ve doğrulanmayan her şeyin dürüst listesi | Okumak istediğinde |
| `manifest.json`, `checksums.sha256` | Dosya listesi ve bütünlük özeti | Paket bozuldu mu diye bakarken |

## Hafta planı

| Gün | Ne yapılır | Dosya |
| --- | --- | --- |
| 0 | Telefon ayarları, mikrofon, alarm, USB-C kulaklık provası | `calisma/01_GUN_0_HAZIRLIK.md` |
| 1 | Başlangıç kayıtları (eğitimden önce), USA Learns hesabı, hafıza sarayı kurulumu | `calisma/02_ILK_DORT_GUN.md` |
| 2 | VOA ders 1–2, sıralı yönerge (H1), C0 tabanları | aynı |
| 3 | Kaynak notu, makale, satır takibi kılavuz denemesi, H5 tanışma, dikte tanışma, H6 1. dinleme | aynı |
| 4 | Tekrar günü, H6 kontrol 1 + 2. dinleme, prova, test maddeleri kilitlenir | aynı |
| 5 | Test 1: yazılı İngilizce, görsel hafıza bilgisi A, çok kısa gecikme (H4) | `test_gununde_ac/05_GUN5_GOREVLER.md` |
| 6 | Test 2: sesli üretim, dikte, dinleme, Türkçe kontrol, bilgi B | `…/05_GUN6_GOREVLER.md` |
| 7 | Test 3: satır takibi, kombinasyon, ders başı (H5), H6 kontrol 2–3 | `…/05_GUN7_GOREVLER.md` |
| 8 | Taşan test varsa; H6 kontrol 4; ZIP ve yedek | `…/05_GUN7_GOREVLER.md` (son bölüm) |
| 12 | A bilgisinin bir haftalık kontrolü | aynı |
| 13 | B bilgisinin bir haftalık kontrolü (isteğe bağlı) | aynı |

Planın amacı süre doldurmak değildir: her günün **hedefleri** bitince gün tamamlanır; ana hedef akşama, yaklaşık 23:00'e kadar. İsteğe bağlı bölümler eksik sayılmaz. Spor borcu ertesi güne eklenmez. Test günleri 2,5–4 saate kadar uzayabilir; yorgunluk ve uyku notu tut.

## Kesinleşen iki kural

**Hafta 1:** İlk dört gün yöntem ve eğitim; son üç gün başlangıç durumunu tanımaya yönelik test. Dış kaynak yeterliyse o kullanılır; yeterli değilse hazırlanmış özel materyal kullanılır. Hafta 1'den sonra “test” kavramı yalnız İngilizce tekrarında kalır; diğer alanlar kesintisiz pratiktir.

**İngilizce tekrarları:** Öğrenme → 3 gün bekle → tekrar → 10 gün bekle → tekrar → 20 gün bekle → tekrar → 50 gün bekle → tekrar. Gecikme yoksa öğrenme gününe göre tarihler **3, 13, 33 ve 83. günlerdir**; aralıklar birbirini izler (3, 10, 20, 50 gün), takvimde 10. veya 20. gün anlamına gelmez. Bir tekrar gecikirse sonraki aralık **gerçekleşen tekrar tarihinden** başlar (bu benim seçtiğim uygulama kuralıdır, kanıtlanmış üstünlük iddiası yok). Planlanan ve gerçekleşen tarih birlikte saklanır. Hesap için `kayitlar/INGILIZCE_TEKRAR_TAKVIMI.xlsx`.

## Anahtar ve yanıt kuralları

- Yanıt yerine **bilmiyorum** yazabilirsin; **anlamadım** işareti ayrıca eklenebilir.
- Anahtarı istediğin zaman elle açabilirsin; bir maddede **üçüncü gönderimden** sonra da açılır. Bu pakette bu sayım elle tutulur (`kayitlar/YANIT_SABLONU.md`). Anahtarı açınca saatini yaz.
- Yardım kodları: **A0** yardımsız ilk deneme · **A1** ipucu/araç · **A2** anahtar açıldıktan sonra · **A3** dış kaynak · **A4** yapay zekâ ya da çeviri aracı. Birlikte kullanılabilir.
- Bir yanıtı değiştirince eskisini silme; yeni deneme olarak ekle.
- Görev numaralarındaki `G05`, `G06`, `G07` **Gün**dür; ana rapordaki G01–G26 karar kodlarıyla karıştırma.

## Sesler hakkında dürüst not

Pakette İngilizce ve Türkçe **yapay (nöral) ses** dosyaları vardır; ayrıntı `test_gununde_ac/06_SES_VE_LISANS_NOTU.md` dosyasında. Bu sesler bir bilgisayar ortamında üretildi ve otomatik tanıma ile kontrol edildi; **bir insan dinleyip onaylamadı** ve senin telefonunda/kulaklığında denenmedi. Bir ses anlaşılmazsa bunu “ses anlaşılmadı” diye ayrıca kaydet; içeriği anlamamakla karıştırma. Türkçe sesin lisansı kişisel ve ticari olmayan kullanım içindir.

## Testlerin kullanım sınırı

İlk dört günden sonra yapılan testler, **eğitim sonrası başlangıç profili** verir; eğitimden önceki beceriyi ölçmüş gibi yorumlanmaz. Gün 1'deki başlangıç kayıtları eğitimden önceki tek doğal örnektir. Hiçbir görev standartlaştırılmış ya da doğrulanmış sınav değildir.

50 makalelik havuz uzun vadeli hedeftir; bu pakette yalnız ilk haftanın birkaç özgün okuma metni vardır.
