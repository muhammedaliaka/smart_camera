# Gün 6 anahtarı — yalnız Gün 6 görevlerini ve A'nın ertesi gün kontrolünü bitirince aç

Bu anahtar **puan, yüzde, doğru/yanlış hükmü veya tanı üretmez**. Beklenen içerik bir kontrol listesidir; serbest yanıtlarda başka ifadeler de aynı noktayı taşıyabilir. İlk bağımsız yanıtın (A0) kayıtta aynen kalır; anahtara baktıktan sonra yaptığın düzeltme ayrı satırdır ve A2 olarak kodlanır. Anahtarı açınca **saatini** ve “elle” ya da “üçüncü gönderimde” diye yaz (`../kayitlar/YANIT_SABLONU.md`).

Hafıza görevleri (G05-H2-A, G06-H2-B) için **anahtar yoktur**; kontrol edilecek bilgiler `05_GUN5_GOREVLER.md` (A) ve `05_GUN6_GOREVLER.md` (B) içinde gördüğün satırlardır. A'nın bir haftalık kontrolü Gün 12'de, B'nin ertesi gün kontrolü Gün 7'dedir; o kontroller bitmeden satırlara tekrar bakma.

## G06-S1 / G06-S2

Sesli okuma: özgün metin ile kaydın birlikte tutulması yeterlidir. Serbest konuşmada aranan işlevler: kendini tanıtma, ilgi belirtme, soru sorma, tekrar isteme. Dış değerlendirici örnekleri **dinleyerek** hangi gözlemi hangi kayda dayandırdığını söyler; sözcük sözcük transkript tek başına telaffuz değerlendirmesi olmaz.

## G06-B1 — dikte: söylenen öğeler

Her öğeden önce sıra numarası söylenir; öğe **bir kez** okunur ve ardından altı saniye boşluk bırakılır. Yazılışta sayılar rakamla (15) ya da sözcükle (fifteen) yazılabilir; büyük/küçük harf ve noktalama kaydedilir ama ayrı bir hata sayılmaz.

**Dikte 1** (`G06_B1_dikte_1.mp3`, yavaş):

1. *First.* → **fifteen**
2. *Second.* → **Thursday**
3. *Third.* → **a red bag**
4. *Fourth.* → **forty-two**
5. *Fifth.* → **Please open the door.**
6. *Sixth.* → **My friend is at home.**

**Dikte 2** (`G06_B1_dikte_2.mp3`, normal):

1. *First.* → **thirteen**
2. *Second.* → **Saturday**
3. *Third.* → **a yellow pen**
4. *Fourth.* → **sixty-five**
5. *Fifth.* → **Please close the window.**
6. *Sixth.* → **My brother is at school.**

**Dikte 3** (`G06_B1_dikte_3.mp3`, hızlı):

1. *First.* → **seventeen**
2. *Second.* → **Sunday**
3. *Third.* → **a black coat**
4. *Fourth.* → **ninety-three**
5. *Fifth.* → **Please wait at the gate.**
6. *Sixth.* → **My teacher is in the room.**

**Dikte TR** (`G06_B1_dikte_TR.mp3`, Türkçe kontrol, normal hız):

1. *Birinci.* → **on yedi**
2. *İkinci.* → **Cumartesi**
3. *Üçüncü.* → **kırmızı bir çanta**
4. *Dördüncü.* → **yirmi iki**
5. *Beşinci.* → **Lütfen kapıyı aç.**
6. *Altıncı.* → **Arkadaşım evde.**

Notlar: Her dosyada iki sayı, bir gün adı, bir nesne öbeği ve iki kısa cümle vardır. -teen ile biten sayılar (fifteen, thirteen, seventeen) onluk sayılarla (50, 30, 70) benzer duyulabilir; böyle bir karışma gözleme girer, hüküm değildir. Dikte işitme testi değildir.

## G06-L1 — duyduğun metinler (İngilizce)

Üç dosya üç farklı konuşmacı ve üç farklı hızdadır (hedef yaklaşık 120 / 90 / 150 sözcük/dakika; gerçekleşen değerler `ses/ses_manifest.json` içindedir).

**EN-A, Maya (`EN_A_normal.mp3`):** Hi, this is Maya. Our study group meets at the library on Tuesday. Please bring a notebook and a blue pen. The meeting starts at four, but I will arrive a little earlier. We planned to use the room near the stairs. That room is not available, so please wait for me at the front door. We can walk to the new room together.

**EN-B, Daniel (`EN_B_yavas.mp3`):** Hello, this is Daniel. The science club has an activity at the school on Friday. Please bring a pencil and a bottle of water. We will begin at three. I want to get there before the activity starts. Our usual classroom is busy today. Please meet me next to the main gate. I will show you where the new classroom is.

**EN-C, Emma (`EN_C_hizli.mp3`):** Hi, this is Emma. I am going to the sports center on Wednesday. You can join me if you want. Bring comfortable shoes and a small towel. The class begins at five, so I plan to arrive early. The side entrance is closed this week. Please use the door beside the bus stop. I will wait inside and help you find our group.

Beklenen içerik:

- **A:** Maya; kütüphane; salı; saat dört (biraz erken gelecek); defter ve mavi kalem; merdivene yakın oda uygun değil; ön kapıda bekleme ve yeni odaya birlikte gitme.
- **B:** Daniel; okulda bilim kulübü etkinliği; cuma; saat üç; kalem ve su şişesi; alışılmış sınıf dolu; ana kapının yanında buluşma.
- **C:** Emma; spor merkezi; çarşamba; saat beş (erken gelecek); rahat ayakkabı ve küçük havlu; yan giriş kapalı; otobüs durağının yanındaki kapı.

## G06-TR-L — duyduğun metin (Türkçe)

(`TR_L.mp3`) Merhaba, ben Burak. Perşembe günü kütüphanedeki çalışma grubuna gidiyorum. Yanına defterini ve siyah bir kalem al. Buluşma dörtte başlayacak. Merdivene yakın oda dolu olduğu için başka bir odada olacağız. Kapıda beni bekle; yeni odaya birlikte geçelim.

Beklenen içerik: Burak; perşembe; kütüphane; dört; defter ve siyah kalem; merdivene yakın oda dolu; kapıda buluşup yeni odaya geçme.

Türkçe ve İngilizce parçalar anlam bakımından yakındır ama ölçülmüş eşdeğer formlar değildir; dil ya da hız etkisini tek başına ayırmazlar.

## Bu anahtarın sınırı

Ses dosyaları yapay (nöral) sestir. Bir kısmını anlayamamak ses kalitesinden, hızdan, içerikten ya da dinleme koşullarından kaynaklanabilir; bunlar bu pakette ayrılamaz. “Ses anlaşılmadı” ile “içeriği anlamadım” ayrımı kayıtta yazılı kalır.
