# Ses dosyaları: nasıl üretildi, nasıl doğrulandı, lisans

Bu not **cevap vermez ve metin içermez**; ses dosyalarının nasıl yapıldığını, neyin kontrol edildiğini ve neyin kontrol edilmediğini anlatır. Seslerin yazılı metinleri ilgili günün anahtar dosyasındadır (`08_ANAHTAR_*`).

## Kısa özet

- Bütün konuşma dosyaları **yapay (nöral) sestir**. Gerçek bir insan kaydı değildir; hiçbir ses gerçek bir kişiye ait gösterilmez.
- Dosyalar 27 Ekim 2026'da bir bilgisayar ortamında üretildi, otomatik tanımayla (konuşmadan yazıya) geri okundu ve nihai mp3 dosyaları `medium` boyutlu bir tanıma modeliyle yeniden kontrol edildi. **Bir insan dinleyip onaylamadı** ve senin telefonunda/kulaklığında denenmedi.
- Bu yüzden bir ses sana anlaşılmaz, yapay ya da garip gelirse bunu `ses anlaşılmadı` diye ayrıca kaydet. Bunu “içeriği bilmiyorum”dan ve işitme durumundan ayrı tut; ses kalitesi sorunu, dinleme becerisi sonucu değildir.

## Motor, sesler ve lisans

| Kullanım | Ses | Lisans (model kartında bildirilen) |
| --- | --- | --- |
| İngilizce, ses 1 (kadın sesi) | `en_US-kristin` (medium) | kamu malı |
| İngilizce, ses 2 (erkek sesi) | `en_US-joe` (medium) | CC0 |
| İngilizce, ses 3 (kadın sesi) | `en_US-ljspeech` (high) | kamu malı |
| İngilizce dikte dosyaları | `en_US-ljspeech` (high; ses 3 ile aynı) | kamu malı |
| Türkçe (tüm Türkçe dosyalar, tek erkek ses) | `tr_TR-dfki` (medium) | **CC BY-NC-SA 4.0**: yalnız kişisel, ticari olmayan kullanım; paylaşılırsa atıf ve aynı lisans |

Motor Piper'dır (nöral, ONNX). Lisans bilgisi sesler seçilirken `rhasspy/piper-voices` model kartlarından okundu. Bir çıktının hukuki durumu model ve veri kümesi lisanslarından etkilenebilir; bu not hukuki görüş değildir. **Türkçe dosyaları yalnızca kendi çalışmanda kullan, paylaşma veya yayımlama.** İngilizce seslerde de paketi başkalarıyla paylaşırsan kaynakları belirt.

## Nasıl üretildi?

1. Metinler özgündür (`08_ANAHTAR_*` dosyalarında). Her metin cümle cümle sentezlendi.
2. Her cümle/öğe için birkaç aday üretildi; adaylar otomatik tanıma ile yazıya çevrilip beklenen metne en çok benzeyen seçildi. Kısa öğelerde (sayı, gün adı, sıra sözcüğü) tek başına bırakmak otomatik tanımayı yanıltıyordu; bu öğeler kısa bir taşıyıcı ifadenin ardına konup iki farklı boyutta (small ve medium) modelle denendi. Dikte öğeleri ayrıca dosyadaki gerçek bağlamda (sıra sözcüğü + kısa boşluk + öğe) denendi; ses 1 bazı tek sözcüklerde (ör. bazı sayılarda) bozuk çıktığı için dikte dosyalarında ses 3 kullanıldı. Dikte dosyalarında `medium` seçimde de kullanıldığı için oradaki son kontrol bağımsız sayılmaz; üçüncü bir model (ör. large) denenmedi.
3. Konuşma hızı sentezleyicinin hız ayarı ve cümle/ifade araları ile ayarlandı. Dosya adındaki yavaş/normal/hızlı etiketleri **toplam hızı** (aralar dahil sözcük/dakika) anlatır; yalnız konuşulan kısmın hızı daha yüksektir. Hedefler yaklaşık 90 / 120 / 150 sözcük/dakikadır; gerçekleşen değerler tabloda ve `ses_manifest.json` içindedir, tam hedefe ulaşılmayabilir.
4. Ses düzeyi iki geçişli normalizasyonla yaklaşık −18 LUFS'a getirildi (en yüksek tepe yaklaşık −1,5 dBFS veya altında). Biçim: mono mp3, 22050 Hz, 64 kb/sn. Bu, telefon hoparlörü/kulaklık için “makul” bir hedeftir; senin cihazında ayrıca ayarlanması gerekebilir.
5. Dikte dosyalarında her öğeden önce sıra sözcüğü (First/Second… ya da Birinci/İkinci…) söylenir ve öğeden sonra 6 saniye boşluk bırakılır.

## Otomatik doğrulama: ne gösterir, ne göstermez?

Aşağıdaki sütun, dosyanın mp3 olarak okunup `medium` boyutlu bir tanıma modeliyle yazıya çevrilmesi ve beklenen metinle karşılaştırılmasıdır (1,000 = aynı). Bu bir **anlaşılabilirlik ölçüsü değildir**: tanıma modeli, insan kulağından farklı hata yapar.

| Dosya | Dil · ses | Hız (toplam sözcük/dk) | Süre (sn) | Ses düzeyi (LUFS) | Otomatik tanıma benzerliği (medium) |
| --- | --- | --- | --- | --- | --- |
| `calisma/ses/G02_C0_dinleme.mp3` | TR · tr_TR-dfki | 99.3 | 18.8 | -18.5 | 1.000 |
| `calisma/ses/G03_B1_dikte_tanisma.mp3` | EN · en_US-ljspeech | normal | 49.7 | -18.4 | 0.957 |
| `calisma/ses/G03_H5_tanisma.mp3` | TR · tr_TR-dfki | 105.8 | 27.8 | -18.4 | 0.996 |
| `calisma/ses/H6_dinleme_G03_G04_G07.mp3` | TR · tr_TR-dfki | 116.8 | 12.9 | -18.3 | 0.993 |
| `test_gununde_ac/ses/gun5/G05_H4_1.mp3` | TR · tr_TR-dfki | 138.0 | 14.4 | -18.4 | 0.989 |
| `test_gununde_ac/ses/gun5/G05_H4_2.mp3` | TR · tr_TR-dfki | 137.9 | 14.9 | -18.4 | 1.000 |
| `test_gununde_ac/ses/gun5/G05_H4_3.mp3` | TR · tr_TR-dfki | 131.5 | 15.6 | -18.4 | 1.000 |
| `test_gununde_ac/ses/gun6/EN_A_normal.mp3` | EN · en_US-kristin | 119.5 | 32.2 | -18.4 | 0.987 |
| `test_gununde_ac/ses/gun6/EN_B_yavas.mp3` | EN · en_US-joe | 90.0 | 40.7 | -19.2 | 1.000 |
| `test_gununde_ac/ses/gun6/EN_C_hizli.mp3` | EN · en_US-ljspeech | 152.3 | 24.9 | -18.4 | 0.995 |
| `test_gununde_ac/ses/gun6/G06_B1_dikte_1.mp3` | EN · en_US-ljspeech | yavas | 51.4 | -18.3 | 0.956 |
| `test_gununde_ac/ses/gun6/G06_B1_dikte_2.mp3` | EN · en_US-ljspeech | normal | 50.5 | -18.3 | 0.988 |
| `test_gununde_ac/ses/gun6/G06_B1_dikte_3.mp3` | EN · en_US-ljspeech | hizli | 49.8 | -18.4 | 0.963 |
| `test_gununde_ac/ses/gun6/G06_B1_dikte_TR.mp3` | TR · tr_TR-dfki | normal | 52.5 | -18.4 | 0.923 |
| `test_gununde_ac/ses/gun6/TR_L.mp3` | TR · tr_TR-dfki | 105.8 | 20.5 | -18.4 | 0.998 |
| `test_gununde_ac/ses/gun7/G07_C0_dinleme.mp3` | TR · tr_TR-dfki | 90.9 | 19.2 | -18.5 | 1.000 |
| `test_gununde_ac/ses/gun7/G07_C1.mp3` | TR · tr_TR-dfki | 91.6 | 19.1 | -18.4 | 1.000 |
| `test_gununde_ac/ses/gun7/G07_C2.mp3` | TR · tr_TR-dfki | 93.6 | 18.7 | -18.3 | 1.000 |
| `test_gununde_ac/ses/gun7/G07_H5_1.mp3` | TR · tr_TR-dfki | 108.4 | 27.7 | -18.4 | 0.992 |
| `test_gununde_ac/ses/gun7/G07_H5_2.mp3` | TR · tr_TR-dfki | 112.2 | 27.4 | -18.6 | 0.997 |
| `test_gununde_ac/ses/sonradan_calisma/EN_A_hizli.mp3` | EN · en_US-kristin | 145.2 | 26.5 | -18.4 | 0.995 |
| `test_gununde_ac/ses/sonradan_calisma/EN_A_yavas.mp3` | EN · en_US-kristin | 90.0 | 42.7 | -18.3 | 0.995 |
| `test_gununde_ac/ses/sonradan_calisma/EN_B_hizli.mp3` | EN · en_US-joe | 147.8 | 24.8 | -19.2 | 1.000 |
| `test_gununde_ac/ses/sonradan_calisma/EN_B_normal.mp3` | EN · en_US-joe | 121.1 | 30.3 | -19.1 | 1.000 |
| `test_gununde_ac/ses/sonradan_calisma/EN_C_normal.mp3` | EN · en_US-ljspeech | 118.4 | 32.0 | -18.4 | 0.992 |
| `test_gununde_ac/ses/sonradan_calisma/EN_C_yavas.mp3` | EN · en_US-ljspeech | 90.0 | 42.1 | -18.4 | 0.989 |

Dikkat edilecekler:

- 1,000'den düşük değerler çoğunlukla özel adların, sayıların/sıra sözcüklerinin tanımada farklı yazılmasının (ör. rakamla) ya da dosya sonundaki fazladan tanıma çıktılarının sonucudur; ancak tek tek **dinleyerek kontrol edilmedi**.
- Tek başına söylenen kısa öğelerde (sayılar, gün adları, sıra sözcükleri) otomatik tanıma güvenilmezdir; bir dosyanın benzerliği düşük çıkmışsa bunun nedeni ses ya da tanıma olabilir, ayırt edemiyoruz.
- Tablo hızların **karşılaştırılabilir** olduğunu da göstermez: üç İngilizce konuşmacı ve üç farklı metin vardır, bu yüzden hız, metin ve ses birlikte değişir (`08_ANAHTAR_GUN6.md`).

## Ne yapmalı?

- Gün 5'ten önce bir ses dosyasını (ör. `../calisma/ses/G02_C0_dinleme.mp3`) kullanacağın kulaklıkla çalıp ses düzeyini ayarla. Çok sessizse ya da bozuksa kaydet ve `HAFTA1\EKSIKLER.md` dosyasına yaz.
- Ses dosyalarını telefonun ses kaydedicisiyle kaydettiğin yanıtlardan ayrı klasörde tut.
- Bir dosya hiç çalışmıyorsa `../manifest.json` ve `../checksums.sha256` dosyalarıyla bütünlüğünü kontrol et (PowerShell komutu `../kayitlar/PAKETLEME_VE_YEDEK.md` içinde; komutlar denenmedi).
