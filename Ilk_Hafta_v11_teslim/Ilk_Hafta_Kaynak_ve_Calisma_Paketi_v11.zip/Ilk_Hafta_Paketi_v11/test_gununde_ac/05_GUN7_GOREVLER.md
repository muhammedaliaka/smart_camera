# Gün 7 (Test 3) — görevler

İlk dört günün ardından, **yalnız bu günün dosyasını** aç; diğer günlerin görev dosyalarına önceden bakma (sonraki günlerin soruları ve hafıza satırları orada). Bu materyal standartlaştırılmış sınav değildir. Uygulama puanı, yüzde veya tıbbi sonuç üretilmez. Yanıt yerine **bilmiyorum** denebilir. Yardım, metni açma ve tekrar dinleme ayrı yazılır. İlk bağımsız yanıt kaybolmaz.

Her soruda: kimlik → deneme no → kendi yanıtın → yardım kodu (A0–A4) ve anahtar durumu → zaman → varsa ses adı. Bu belgeyle yapılan çalışma **elle kayıt**tır (alanlar için `../kayitlar/YANIT_SABLONU.md`; adlandırma için `../calisma/01_GUN_0_HAZIRLIK.md`). Görev kodlarındaki “G05, G06, G07” **Gün**dür; ana rapordaki G01–G26 karar kodlarıyla karıştırma.

**Dosya düzeni.** Bu günün anahtarı `08_ANAHTAR_GUN7.md`; yalnız **bu günün görevlerini bitirince** aç. H6 için ayrı anahtar `08_ANAHTAR_GUN8_H6.md` dosyasıdır ve Gün 8 kontrolü bitince açılır. Sesler `ses/gun7` klasöründedir (H6 duyurusu `../calisma/ses/` içindedir); seslerin yazılı metni anahtardadır. Okuma metinleri `07_OKUMA_METINLERI.md` dosyasındadır; önce bu dosyadaki yönergeyi oku, sonra metinleri aç. Anahtarı açınca saatini ve “elle” ya da “üçüncü gönderimde” diye yaz.

## Gün 7 — Okuma takibi, kombinasyon, ders başı ve haftayı kapatma

Önce **G06-H2-B'nin ertesi gün kontrolünü** yap (“B bilgileri neydi?”, satıra bakmadan).

### G07-H6: Tekrar dinleme (kontrol 2, 3. dinleme, kontrol 3)

Duyuru dosyası `../calisma/ses/H6_dinleme_G03_G04_G07.mp3`. Gün 3'te bir, Gün 4'te ikinci kez dinledin. Bugün:

1. Dosyayı **açmadan** “Duyuruda neler vardı?” sorusuna yanıt ver; yardım kullanma. Bu **kontrol 2** (iki dinlemeden sonra, birkaç gün gecikmeli).
2. Sonra duyuruyu bir kez daha (3. dinleme) dinle.
3. Birkaç dakika sonra, yeniden açmadan aynı soruya yanıt ver: **kontrol 3**.
4. Ertesi gün (Gün 8) bir kez daha, açmadan: **kontrol 4**. Duyuru metni ve anahtar `08_ANAHTAR_GUN8_H6.md` dosyasındadır; kontrol 4 bitmeden açma.

Her kontrolün saatini, kaçıncı dinlemeden sonra olduğunu ve kendi yanıtını aynen yaz. Aralıklı soruların kendisi öğrenmeyi etkileyebilir; bu görev “3+ kez dinleyince kalıyor” gözlemini kendi verinle sınamak içindir, hüküm vermek için değil.

### G07-O: Okuma sırası

Ardından `07_OKUMA_METINLERI.md` dosyasındaki dört metni kullan. Koşul A = normal okuma; koşul B = satır altında parmak/cetvel kılavuzu. **A–B–B–A** sırasıyla dört farklı metin oku (O1 = A, O2 = B, O3 = B, O4 = A). Aynı cihaz, yazı boyutu ve mümkün olduğunca benzer ortamı koru. Dört metni de **aynı ortamda** oku (öneri: telefon ekranı); ortamı kayda yaz. Kitap, PDF ve ders dışı metin karşılaştırması bu hafta yapılmaz; Hafta 2+ pratiğinde aynı iki koşulla ortam notuyla sürdürülebilir. Metinleri bir kağıda aktarırsan bütününü aynı biçimde aktar; sadece bir metni farklı ortamda okumak koşulları karıştırır.

Her metinden sonra satır kaybı ve geri dönüş için kendi sayımını yaz; sayamadıysan **sayamadım** de. Sonra metni kapat ve **dört metinde de aynı** üç soruyu kendi cümlelerinle yanıtla (yazı ya da ses): (1) Ne oldu, ana olay nedir? (2) Hangi sorun ya da değişen bilgi çıktı? (3) En sonunda ne yapıldı ya da ne kaydedildi? Sorular metne göre özelleştirilmedi; böylece sonraki metni okurken neye bakacağını önceden bilmezsin. Sayım yapmak da ek dikkat yüküdür; sayıyı nesnel göz ölçümü sayma. Metinler yaklaşık 155 sözcüktür ve aynı zorlukta doğrulanmadı; kısa metinde satır sayısı az olduğundan sayımlar kabadır.

Her metin için beklenen noktalar `08_ANAHTAR_GUN7.md` dosyasındadır; dört metni de bitirmeden açma.

### G07-H5: Ders başı — iki deneme (A/B strateji)

Fikir: bir mini dersin **başında söylenen** şeyi, ders ilerledikten sonra da söyleyebilmek. İki kısa Türkçe mini ders var: `ses/gun7/G07_H5_1.mp3` ve `G07_H5_2.mp3`. Her biri bir kez dinlenir, tekrar yok.

1. **H5-1, strateji A:** Dinlerken zihninde tek cümlelik bir başlık tut: “konu + kaç parça”. Not alma. Dosya bitince “Dersin başında ne söylendi?” sorusuna yanıt ver (yazı ya da ses).
2. **H5-2, strateji B:** Aynı soru; bu kez özel bir strateji kullanma, serbest dinle. Not alma. Dosya bitince aynı soruya yanıt ver.

Hangi sırayla yaptığını, yanıtlarını ve kendi izlenimini yaz. İki farklı mini ders ve sabit sıra (A sonra B) olduğundan karşılaştırma hüküm vermez; sırayı dengeleme Hafta 2+ pratiğinde farklı günlere yayılır.

### G07-C: Kombinasyon haritası

Türkçe sesler hazır: `ses/gun7/G07_C0_dinleme.mp3`, `G07_C1.mp3`, `G07_C2.mp3`. Bu sesler Türkçe nöral sentetik sestir; gerçek insan sesi değildir. Her dosyayı mümkünse bir kez dinle, tekrar açarsan sayısını yaz. Önceden görmediğin üç ayrı metindir; metinler eş yapılıdır ama eşdeğerliği kanıtlanmış değildir.

1. **C0-yazma:** Bir günlük planı 4 cümleyle yaz. Başka görev yok.
2. **C0-konuşma:** Metni okumadan kendi fikrini 3 cümleyle anlat. Başka görev yok.
3. **C0-dinleme:** `G07_C0_dinleme.mp3` dosyasını oturarak dinle, sonra kendi sözlerinle anlat.
4. **C1:** `G07_C1.mp3` dosyasını, sağlam destek yanında rahat yerinde adım atarken dinle; sonra anlat. Trafik, merdiven, ağırlık veya yürürken yazma yok.
5. **C2:** `G07_C2.mp3` dosyasını oturarak dinlerken yalnız üç anahtar sözcük yaz; sonra bunlardan yola çıkarak anlat.
6. **C3-tanışma:** Bir konuda kendi düşüncen söylerken aynı düşüncenin kısa anahtarlarını yaz. İki farklı konuyu aynı anda yürütmek bu ilk denemeye dahil değil.

Aynı içeriği önce tek başına sonra birlikte yapmak ikinci durumda öğrenilmiş içerik avantajı oluşturur. Burada farklı örnekler kullanıldı; onlar da tam denk değildir. Sonuçlar puanlanmış genel çoklu görev yeteneği sayılmaz. Kayda dil, içerik, koşul, yardım ve yapılan çıktı yazılır.

### Gün sonu paketi

Yazılar, sesler, her deneme, anahtar açma kayıtları ve **eksik kalan parçaları** aynı klasörde birleştir. `../kayitlar/PAKETLEME_VE_YEDEK.md` adımlarıyla ZIP oluştur, bir kopyayı Windows bilgisayara aktar, ikinci kopyayı al. Dış değerlendiriciye şu sorularla ver: “Hangi beceride hangi gözlem var? Hangi açıklamalar belirsiz? İkinci haftanın çalışma yükünü hangi somut kayda göre değiştirmeliyiz?”

## Gün 8 ve sonrası

- **Gün 8:** H6 kontrol 4 (açmadan), sonra `08_ANAHTAR_GUN8_H6.md`. Taşan test varsa burada. Hafta paketini yedekle.
- **Gün 12:** G05-H2-A satırının bir haftalık kontrolü; yalnız “A bilgisi neydi?” sorusu, satıra bakmadan.
- **Gün 13:** G06-H2-B'nin bir haftalık kontrolü (isteğe bağlı).

Bu takipler ilk haftanın dışında kaldığı için ilk hafta raporunda tamamlanmış gösterilmez. Hafta 2+ genel yeniden test başlatmak anlamına gelmez; bunlar ilk hafta görevlerinin gecikmiş takip noktalarıdır.
