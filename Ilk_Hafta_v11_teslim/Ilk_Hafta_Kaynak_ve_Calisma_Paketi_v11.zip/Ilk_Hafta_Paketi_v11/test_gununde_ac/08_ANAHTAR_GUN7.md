# Gün 7 anahtarı — yalnız Gün 7 görevlerini bitirince aç

Bu anahtar **puan, yüzde, doğru/yanlış hükmü veya tanı üretmez**. Beklenen içerik bir kontrol listesidir; serbest yanıtlarda başka ifadeler de aynı noktayı taşıyabilir. İlk bağımsız yanıtın (A0) kayıtta aynen kalır; anahtara baktıktan sonra yaptığın düzeltme ayrı satırdır ve A2 olarak kodlanır. Anahtarı açınca **saatini** ve “elle” ya da “üçüncü gönderimde” diye yaz (`../kayitlar/YANIT_SABLONU.md`).

Hafıza görevi G06-H2-B için anahtar yoktur (kontrol edilecek bilgiler `05_GUN6_GOREVLER.md` içinde gördüğün satırdır). H6 duyurusunun anahtarı **bu dosyada değildir**: Gün 8 kontrolü bitmeden duyuru metnine bakma; anahtar `08_ANAHTAR_GUN8_H6.md` dosyasındadır.

## G07-H5 — duyduğun mini dersler

**H5-1, strateji A (`G07_H5_1.mp3`):** Bugün mercan resiflerinin neden önemli olduğunu anlatacağım. Konuyu üç parçada ele alacağız: önce yaşam alanı, sonra kıyı koruması, en sonunda besin zinciri. Resifler birçok balığa barınak sağlar. Dalgaları yavaşlatarak kıyıyı korur. Küçük canlılar resiflerde beslenir ve onları daha büyük balıklar avlar. Sıcaklık yükselirse mercanlar renk kaybedebilir; bu duruma ağarma denir.

**H5-2, strateji B (`G07_H5_2.mp3`):** Bugün arıların çiçekleri neden ziyaret ettiğini anlatacağım. Konuyu üç parçada ele alacağız: önce nektar, sonra polen, en sonunda tozlaşma. Arılar çiçeklerden şekerli bir sıvı toplar. Ayrıca bacaklarına yapışan sarı toz taneciklerini taşır. Bu tanecikler başka bir çiçeğe değince meyve ve tohum oluşumuna yardım eder. Bir kovan günde binlerce çiçeği ziyaret edebilir.

Beklenen içerik (“Dersin başında ne söylendi?”):

- **H5-1:** konu, mercan resiflerinin neden önemli olduğu; üç parça: yaşam alanı, kıyı koruması, besin zinciri.
- **H5-2:** konu, arıların çiçekleri neden ziyaret ettiği; üç parça: nektar, polen, tozlaşma.

İki parça farklı içeriktedir ve sıra sabittir (A sonra B); sonuçlar bir stratejinin üstünlüğünü kanıtlamaz, yalnız kendi gözlemini kaydeder.

## G07-C — duyduğun metinler

- **C0-dinleme, `G07_C0_dinleme.mp3`:** Bir okul kulübü küçük bir sergi hazırlıyor. Fotoğraflar girişteki masaya, çizimler pencere yanındaki panoya konacak. Sergiden önce masadaki eski kağıtlar kaldırılacak. Kulüp üyeleri önce salonu düzenleyip sonra konukları karşılayacak.
- **C1, `G07_C1.mp3`:** Bir arkadaş grubu kitap değişim günü hazırlıyor. Romanlar kapıya yakın masaya, dergiler köşedeki rafa konacak. Etkinlikten önce rafın üzerindeki kutular kaldırılacak. Grup önce kitapları yerleştirip sonra gelen kişileri karşılayacak.
- **C2, `G07_C2.mp3`:** Bir atölye ekibi tanışma günü düzenliyor. Kalemler büyük kutuya, boş kağıtlar yanındaki sepete konacak. Çalışmadan önce masanın üzerindeki eski afişler kaldırılacak. Ekip önce malzemeleri hazırlayıp sonra yeni katılanları karşılayacak.

Beklenen içerik:

- **C0-dinleme:** sergi; fotoğraflar giriş masasına, çizimler pencere panosuna; eski kâğıtlar kaldırılacak; önce düzenleme sonra konuk karşılama.
- **C1:** kitap değişimi; romanlar kapıya yakın masaya, dergiler köşe rafına; raftaki kutular kaldırılacak; önce yerleştirme sonra karşılama.
- **C2:** atölye tanışma günü; kalemler büyük kutuya, kâğıtlar sepete; eski afişler kaldırılacak; önce hazırlık sonra karşılama.

Bu formlar eşdeğerliği kanıtlanmış ölçme araçları değildir; tek görev ile birleşik görev farkından genel beceri ya da yalnız hareket etkisi çıkarılmaz. Yazma, konuşma ve C3 görevlerinde anahtar yoktur; yanıtlar aynen saklanır.

## G07-O — okuma sonrası anlatım

Üç ortak soru: (1) ana olay, (2) çıkan sorun ya da değişen bilgi, (3) sonunda yapılan şey ya da tutulan kayıt.

- **O1 (A):** Okulun boş odası çalışma alanı yapılıyor. Önce masalar pencereye yaklaştırılıyor, öğleden sonra ışık ekranlarda yansıma yapıyor; masalar yan duvara çevriliyor, geçiş yolu daralıyor, açık bir yol bırakılıyor. Panoya kısa kurallar asılıyor. İlk kullananlardan görüş alınıyor; çanta yeri eksik olduğu için bir köşeye çanta rafı ekleniyor. İlk plan tümüyle atılmıyor; öneri kâğıdı bırakılıyor.
- **O2 (B):** Kulüp defteri yerinde yok. Aynı yerler yeniden aranmak yerine bakılan yerler yazılıyor (sınıf dolabı, sergi kutuları). Bir öğrencinin “masada iki benzer defter vardı” hatırlaması aramayı etkinlik odasına yöneltiyor; defter hoparlör çantasında. Belirsiz hatırlama ile kesin olay ayrımı vurgulanıyor. Ödünç alma kartı: kim aldı, nereye götürdü; gereksiz kişisel bilgi yazılmayacak.
- **O3 (B):** İki afiş: canlı renkli ve büyük fotoğraflı olan ile sade olan. Sade afişte bilgi daha kolay bulunuyor. Fotoğraf kaldırılmıyor, küçültülüyor; yer ve başlama bilgisi fotoğrafın altına aynı boyutta konuyor. Deneme grubu küçük; “herkes daha iyi anlayacak” denmiyor. Telefon ve basılı kâğıtta görünüm farklı olabilir; iki ortamda yeniden inceleniyor, küçük yazı büyütülüyor, değişiklikler listeleniyor.
- **O4 (A):** Okul bahçesi: ilk gün herkes toprak taşıyor ama fidan yerleri belli değil, toprağın bir kısmı yeniden taşınıyor. İkinci gün sıra: alan işaretleme, toprak hazırlama, bitki yerleştirme; görevler panoda. Sulama kabı eksik; sulama yapılmış gibi işaretlenmiyor, tamamlanan ve bekleyen işler ayrı yazılıyor. Ertesi gün önce bekleyen sulama yapılıyor.

Satır kaybı ve geri dönüş sayıları senin beyanındır; anahtarda olması gereken bir sayı yoktur.

## Gün 8 ve sonrası

- **Gün 8:** H6 kontrol 4 (açmadan), sonra `08_ANAHTAR_GUN8_H6.md`.
- **Gün 12:** G05-H2-A satırının bir haftalık kontrolü; yalnız “A bilgisi neydi?” sorusu.
- **Gün 13 (isteğe bağlı):** G06-H2-B'nin bir haftalık kontrolü.
