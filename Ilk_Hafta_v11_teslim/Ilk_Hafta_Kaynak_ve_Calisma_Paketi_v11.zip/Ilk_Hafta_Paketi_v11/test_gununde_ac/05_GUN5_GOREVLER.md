# Gün 5 (Test 1) — görevler

İlk dört günün ardından, **yalnız bu günün dosyasını** aç; diğer günlerin görev dosyalarına önceden bakma (sonraki günlerin soruları ve hafıza satırları orada). Bu materyal standartlaştırılmış sınav değildir. Uygulama puanı, yüzde veya tıbbi sonuç üretilmez. Yanıt yerine **bilmiyorum** denebilir. Yardım, metni açma ve tekrar dinleme ayrı yazılır. İlk bağımsız yanıt kaybolmaz.

Her soruda: kimlik → deneme no → kendi yanıtın → yardım kodu (A0–A4) ve anahtar durumu → zaman → varsa ses adı. Bu belgeyle yapılan çalışma **elle kayıt**tır (alanlar için `../kayitlar/YANIT_SABLONU.md`; adlandırma için `../calisma/01_GUN_0_HAZIRLIK.md`). Görev kodlarındaki “G05, G06, G07” **Gün**dür; ana rapordaki G01–G26 karar kodlarıyla karıştırma.

**Dosya düzeni.** Bu günün anahtarı `08_ANAHTAR_GUN5.md`; yalnız **bu günün görevlerini bitirince** aç. Sesler `ses/gun5` klasöründedir; seslerin yazılı metni anahtardadır (dinlemeden önce açma). Seslerin nasıl üretildiği ve nelerin doğrulanmadığı `06_SES_VE_LISANS_NOTU.md` dosyasındadır (hiçbir yanıtı açmaz). Anahtarı açınca saatini ve “elle” ya da “üçüncü gönderimde” diye yaz.

## Gün 5 — Yazılı İngilizce profili, görsel ve çok kısa gecikme

### G05-W1: Serbest yazı

İngilizce, yeni tanıştığın birine kendini tanıtan ve birlikte yapabileceğiniz bir etkinlik öneren 5–8 cümle yaz. Nerede yaşadığın, bir ilgin ve karşı tarafa yönelttiğin bir soru yer alsın. Bu sayıya ulaşamıyorsan yazabildiğin kadar yaz; sırf tamamlamak için çeviri aracına geçmek zorunda değilsin.

### G05-R1: Okuma

**A different plan**

My name is Nora. I live in a small town with my brother. On Saturdays, we usually visit our grandmother. This Saturday, she is staying with a friend, so we have a different plan. My brother wants to go to the sports center, but I want to join a science activity at the library. We decide to visit the library first and go to the sports center later.

The activity starts at ten in the morning. We leave home early because the first bus does not stop near the library. We take a second bus from the station. I bring a notebook, a pencil, and a bottle of water. My brother forgets his notebook, so we share mine. After the activity, we meet a student named Leo. He tells us about another event next month. Before we leave, I write the date in my notebook because I want to remember it.

Metin açıkken şu soruları yanıtla; istersen Türkçe kullanabilirsin:

1. Nora ve kardeşi cumartesileri genellikle ne yapıyor?
2. Bu cumartesi plan neden değişiyor?
3. Önce nereye, sonra nereye gitmeye karar veriyorlar?
4. Neden ikinci bir otobüse biniyorlar?
5. Defterini kim unutuyor; ne çözüm buluyorlar?
6. Metinde sonraki etkinliğin kesin tarihi verilmiş mi?

Ardından metni kapat ve ana olayı İngilizce anlatabildiğin kadar, yetmediği yerde Türkçe anlat. Hangi dilde olduğunu belirt. Açık metin yanıtıyla kapalı anlatım ayrı kayıttır.

### G05-T1: Çeviri

1. “I want to learn English because I like meeting new people.” cümlesini Türkçeye aktar.
2. “The meeting is after school, but I can come later.” cümlesini Türkçeye aktar.
3. “Bu kelimeyi anlamıyorum. Tekrar eder misin, lütfen?” ifadesini İngilizce söyle veya yaz.
4. “Arkadaşım bugün burada değil.” ifadesini İngilizce yaz.

### G05-G1: Kısa dil kullanımı — isteğe bağlı küçük bölüm

1. My sister ___ a student. (am / is / are)
2. I ___ in Türkiye. (live / lives)
3. There ___ two books on the table. (is / are)
4. She ___ like coffee. (don't / doesn't)
5. We ___ at home yesterday. (are / were)
6. Can you ___ me? (help / helps)

Bilmediğin yapıda **bilmiyorum** yaz. İlk dört günde öğretilmeyen yapıların çıkması bir başarısızlık hükmü değildir; başlangıç profilinin kapsamını görmeye yarar.

### G05-H2-A: Gecikmeli bilgi — görsel kip

Aşağıdaki satırı bir kez oku ve kapat: **“Hayalî atölyenin giriş sözcüğü: menekşe.”**

Bu satırı gördüğün zamanı yaz. Kısa, orta ve birkaç saatlik kontrol için önerilen protokol **5 dakika, 30 dakika ve 2 saat**; ertesi gün (Gün 6) de bir kontrol; ayrıca bir hafta sonra (Gün 12). Bunlar çalışma süreleri değil ölçüm aralıklarıdır. Telefon Saat alarmını kullan. Her kontrolde yalnız “A bilgisi neydi?” sorusuna yanıt ver; satırı tekrar gösterme. Yanıtı hatırlayamazsan bunu kaydet; sonraki kontrol yine yapılabilir. Yeniden bakarsan onun zamanını ve hangi kontrolden önce olduğunu belirt.

Bu görev görsel sunumdur; işitsel hafıza ölçümü gibi yazılmaz. Aralıklı soruların kendisi öğrenmeyi etkileyebilir. Son hatırlanan ve ilk hatırlanmayan kontrol arasındaki aralık raporlanır; kesin unutma anı bulunmuş sayılmaz.

### G05-H4: Çok kısa gecikme (3 deneme)

Bu görev, bir şeyi duyduktan **birkaç saniye** sonra aklında tutabilmeyi gözler (ana rapor 9.3, görev H4). Üç ayrı ses dosyası var: `ses/gun5/G05_H4_1.mp3`, `G05_H4_2.mp3`, `G05_H4_3.mp3`. Sırayla, her biri için:

1. Telefonun ses kaydedicisini başlat (kayıt sürerken başka uygulamaya geçme).
2. Dosyayı bir kez çal ve sonuna kadar dinle. Üç adım söylenir; adımlar **hayalîdir**, gerçekten yapma. Dosya senden sesli olarak on'dan geriye doğru saymanı ve sayma bitince üç adımı sırayla söylemeni ister.
3. Dosya bitince yönergeye uy: geriye doğru say, sonra adımları söyle. Hatırlayamadığında “bilmiyorum” de.
4. Kaydı durdur; dosya adını `G05_H4_n_...` biçiminde ver.

Denemeler arasında birkaç dakika ara ver. Sayma süresi sonradan ses kaydından okunur; sen ayrıca “yaklaşık kaç saniye geçti” diye yazabilirsin. Tekrar çalma yok; çaldıysan belirt.
