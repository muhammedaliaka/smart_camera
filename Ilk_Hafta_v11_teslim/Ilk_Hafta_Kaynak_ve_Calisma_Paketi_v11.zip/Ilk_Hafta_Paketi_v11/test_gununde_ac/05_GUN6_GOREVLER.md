# Gün 6 (Test 2) — görevler

İlk dört günün ardından, **yalnız bu günün dosyasını** aç; diğer günlerin görev dosyalarına önceden bakma (sonraki günlerin soruları ve hafıza satırları orada). Bu materyal standartlaştırılmış sınav değildir. Uygulama puanı, yüzde veya tıbbi sonuç üretilmez. Yanıt yerine **bilmiyorum** denebilir. Yardım, metni açma ve tekrar dinleme ayrı yazılır. İlk bağımsız yanıt kaybolmaz.

Her soruda: kimlik → deneme no → kendi yanıtın → yardım kodu (A0–A4) ve anahtar durumu → zaman → varsa ses adı. Bu belgeyle yapılan çalışma **elle kayıt**tır (alanlar için `../kayitlar/YANIT_SABLONU.md`; adlandırma için `../calisma/01_GUN_0_HAZIRLIK.md`). Görev kodlarındaki “G05, G06, G07” **Gün**dür; ana rapordaki G01–G26 karar kodlarıyla karıştırma.

**Dosya düzeni.** Bu günün anahtarı `08_ANAHTAR_GUN6.md`; yalnız **bu günün görevlerini ve A'nın ertesi gün kontrolünü bitirince** aç. Sesler `ses/gun6` klasöründedir; seslerin yazılı metni anahtardadır (dinlemeden önce açma). `ses/sonradan_calisma` klasörünü bu günün L1 görevini bitirene kadar açma; orası yalnız sonradan çalışma içindir. Ses üretimi ve sınırlar için `06_SES_VE_LISANS_NOTU.md`. Anahtarı açınca saatini ve “elle” ya da “üçüncü gönderimde” diye yaz.

## Gün 6 — Sesli üretim, dinleme, dikte ve ikinci hafıza bilgisi

Önce **G05-H2-A'nın ertesi gün kontrolü**: satıra yeniden bakmadan “A bilgisi neydi?” sorusuna yanıt ver ve saatini yaz.

### G06-S1: Sesli okuma

Aşağıdaki metni kendi sesinle oku. Takıldığında kaydı silmek yerine durup devam edebilirsin. Yeni kayıt açarsan öncekini koru.

**Today I am visiting a new study group. I do not know everyone, but I want to ask a question. I bring my notebook and sit near the window. The room is quiet. A student shows me the plan for the afternoon. I ask her to repeat one sentence. Then I tell the group what I enjoy learning.**

### G06-S2: Serbest konuşma (network başlangıç kaydı)

Metne bakmadan İngilizce kendini tanıt, ilgini söyle ve bir soru sor. Ardından “Karşındaki kişiyi anlamadın” durumunda nasıl tekrar isteyeceğini söyle. Bu aynı zamanda network başlangıç kaydındır. Okunmuş ses ile serbest konuşma farklı kayıtlardır. Kayıtların anlaşılabilirliğini daha sonra dış değerlendirici dinler; transkript tek başına yeterli değildir.

### G06-B1: Dikte — duyduğunu yakalayıp yazma

Dört ses dosyası: `ses/gun6/G06_B1_dikte_1.mp3`, `G06_B1_dikte_2.mp3`, `G06_B1_dikte_3.mp3` (İngilizce) ve `G06_B1_dikte_TR.mp3` (Türkçe kontrol). Her dosyada altı kısa öğe var; her öğeden sonra yazman için boşluk bırakılır.

- İlk turda yazılı kaynaklara bakma, çeviri aracı kullanma.
- Duyduğunu **duyduğun gibi** yaz; bilmediğin sözcüğü sesine göre yazabilirsin ya da boş bırakıp “bilmiyorum” yaz.
- Dosyayı yeniden çalabilirsin; her dosya için **kaç kez** çaldığını yaz.
- Sıra: dikte 1 → 2 → 3 → Türkçe. İngilizce dosyalar sırayla **yavaş, normal ve hızlı** konuşma hızındadır; her dosyanın öğeleri farklıdır. Hız, sıra ve öğe farkı birbirinden ayrılamaz (tek hafta, tek sıra); fark görürsen onu yalnız hıza bağlama. Türkçe dosyadaki öğeler, ilk İngilizce dosyanın öğelerinin Türkçe karşılığına yakındır; bu yüzden Türkçe dosya **en sona** bırakıldı.

Bu görev işitme testi değildir.

### G06-L1: İngilizce dinleme

`ses/gun6` klasöründeki **EN_A_normal.mp3**, **EN_B_yavas.mp3**, **EN_C_hizli.mp3** dosyalarını bu sırayla dinle. İlk turda yazılı ses metinlerine bakma. Dosyalar yapay (nöral) Amerikan İngilizcesi sesiyle üretilmiştir; üç ayrı konuşmacı sesi kullanıldı ama gerçek insan konuşması çeşitliliğini temsil etmez. Dinlediğini tekrar açman serbest; açma sayısını yaz.

Her parça için:

1. Kişi ne yapmayı planlıyor?
2. Söylenen yer, zaman veya nesnelerden aklında kalanları yaz.
3. Bir değişiklik ya da sorun var mı? Kendi cümlenle anlat.
4. Hiç anlayamadığın kısım varsa bunu belirt; duyduğun ama anlamını bilmediğin ifadeyi ayrıca yazabilirsin.

A, B ve C farklı metinlerdir ve her biri tek bir hızda verilir. Zorlukları eşitlenmiş değildir; aralarındaki fark yalnız konuşma hızından kaynaklanmış sayılmaz. Aynı metnin başka hızları `ses/sonradan_calisma` klasöründedir; onları bu görevleri bitirdikten sonra çalışma için açabilirsin, bu yeni bağımsız test olmaz.

### G06-TR-L: Türkçe dinleme kontrolü

`ses/gun6/TR_L.mp3` dosyasını dinle ve **aynı dört soruyu** yanıtla (Türkçe). Tekrar açma sayısını yaz. Türkçe ve İngilizce parçalar anlam bakımından yakın olsa da ölçülmüş eşdeğer formlar değildir; bu parça dil ya da hız etkisini tek başına ayırmaz. Ses, Türkçe nöral bir sentetik sestir; gerçek bir insan sesi değildir ve **Türkçe sesin anlaşılabilirliği cihazında sen dinleyerek doğrulanır**. Bir bölümü anlayamazsan “ses anlaşılmadı” ile “içeriği anlamadım” ayrımını yaz.

İngilizce dinleme sonucu işitme ya da yalnız dil düzeyi olarak yorumlanmaz.

### G06-H2-B: İki bilgi — görsel kip

A'nın ertesi gün kontrolünü (yukarıda) zaten yaptın. Şimdi yeni B bilgisine geç:

**“Hayalî turuncu şemsiye dolapta. Hayalî buluşma pazar günü.”**

Bir kez oku, kapat, ilk sunum zamanını yaz. Aynı 5 dakika / 30 dakika / 2 saat ve ertesi gün (Gün 7) kontrolleri; ayrıca bir hafta sonra (Gün 13) isteğe bağlı. Her kontrolde “B bilgileri neydi?” sorusu sorulur. İki bilgi olduğu kayda girer. Birini hatırlayıp diğerini çıkaramıyorsan verdiğin yanıt aynen saklanır; puan yazılmaz.

Gün sonunda Gün 6 paketini hazırla (`../kayitlar/PAKETLEME_VE_YEDEK.md`).
