# Dört okuma metni — Gün 7'de aç

Bu dosya yalnız metinleri içerir. Okuma sırası ve her metinden sonra yanıtlayacağın üç ortak soru `05_GUN7_GOREVLER.md` dosyasındaki **G07-O** bölümündedir; soruların dördü de aynıdır ve metne göre özelleştirilmemiştir. Önce `05_GUN7_GOREVLER.md` dosyasındaki yönergeyi bir kez oku, sonra bu dosyayı aç; metinlerin altında soru ya da yönerge yoktur.

Uygulama sırası: **O1 koşul A, O2 koşul B, O3 koşul B, O4 koşul A.** A = normal okuma; B = satır altında parmak veya cetvel kılavuzu. Dört metin de aynı ortamda (aynı cihaz, aynı yazı boyutu) okunur.

Metinler özgün kurmacadır ve bilimsel iddia içermez. Sözcük sayıları birbirine yakındır (aşağıda, otomatik sayımla); dilsel zorlukları ölçülerek eşitlenmiş değildir ve metinler kısadır (yaklaşık 155 sözcük), bu yüzden satır sayımları kaba kalır.

| Metin | Sözcük | Cümle |
| --- | --- | --- |
| O1 | 156 | 16 |
| O2 | 154 | 17 |
| O3 | 154 | 16 |
| O4 | 153 | 17 |

Sözcük sayısı boşlukla ayrılan sözcükler üzerindendir; sayımın ayrıntısı (kesme işareti, tire) küçük farklar yaratabilir.

## O1 — Sessiz odanın düzeni

Okulun boş bir odasını çalışma alanı yapmak isteyen öğrenciler önce odadaki eşyaları listeledi. İki büyük masa, birkaç sandalye ve kullanılmayan bir pano vardı. İlk öneri, bütün masaları pencereye yaklaştırmaktı. Fakat öğleden sonra gelen ışık ekranlarda yansıma oluşturuyordu. Bunun üzerine öğrenciler masaları yan duvara çevirmeyi denedi.

Bir grup, yeni düzende geçiş yolunun daraldığını fark etti. Masaların yerini yeniden değiştirip kapıdan arka köşeye kadar açık bir yol bıraktılar. Panoya oda kurallarını asmak istediler. Uzun bir liste yerine, eşyaları yerine koymak ve diğer çalışanları rahatsız etmemek gibi birkaç kısa madde yazdılar.

Odayı ilk kullanan kişilerden ertesi gün görüş alındı. Bir öğrenci ışığı, başka biri sandalye aralıklarını uygun buldu. Ancak çantaları koyacak yerin eksik olduğu söylendi. Öğrenciler, düzeni tamamlanmış saymak yerine bir köşeye çanta rafı eklemeyi kararlaştırdı. İlk planlarını bütünüyle atmadılar; kullanırken görülen bir eksikliği giderdiler.

Kapının yanına küçük bir öneri kağıdı bıraktılar. Bundan sonra değişiklik yapılmadan önce sorunun nerede yaşandığını yazmak, hemen bütün odayı yeniden taşımaktan daha kullanışlı görünüyordu.

## O2 — Kayıp defterin izi

Bir öğrenci kulübü, yıl boyunca yapılan toplantıları tek bir defterde tutuyordu. Defter genellikle kitaplığın üst rafında bulunurdu. Yeni toplantı başladığında defterin yerinde olmadığı görüldü. Herkes son toplantıda kimin kullandığını hatırlamaya çalıştı. Bir kişi, defteri sınıfa götürdüğünü düşündüğünü söyledi; fakat bundan emin değildi.

Kulüp üyeleri aynı yeri tekrar tekrar aramak yerine, bakılan yerleri bir kağıda yazdı. Önce sınıfın dolabı kontrol edildi. Sonra geçen haftaki sergide kullanılan malzemelerin kutularına bakıldı. Defter buralarda bulunamadı. Tam aramayı bırakacaklarken başka bir öğrenci, toplantı sonunda masanın üzerinde iki benzer defter gördüğünü hatırladı.

Bu bilgi aramayı okulun etkinlik odasına yöneltti. Defter, ödünç alınan hoparlörün taşıma çantasına yanlışlıkla konmuştu. Onu bulan kişi, belirsiz hatırlamalarla kesin görülen olayların aynı şey olmadığını söyledi. Bundan sonra defter ödünç alındığında küçük bir karta kimin aldığı ve nereye götürdüğü yazılacaktı.

Yeni düzen geçmişte yaşanan olayı değiştirmedi. Ancak bir sonraki aramada yalnız hafızaya güvenmek yerine izlenebilecek bir kayıt bırakmayı sağladı. Kulüp, karta gereksiz kişisel bilgi eklememeyi de kararlaştırdı.

## O3 — İki farklı afiş

Mahalledeki bir etkinlik için iki afiş hazırlandı. Birinci afişin renkleri canlıydı ve büyük bir fotoğrafı vardı. İkinci afiş daha sadeydi; etkinliğin adı, yeri ve başlama bilgisi belirgin görünüyordu. Hazırlayanlar hangisinin daha kullanışlı olduğuna karar vermek için birkaç kişiye iki tasarımı gösterdi.

İlk afişe bakanlar fotoğrafı hemen fark etti, fakat bazıları etkinliğin nerede olduğunu aramak zorunda kaldı. İkinci afişte ise bilgi daha kolay bulundu. Bunun üzerine tasarım ekibi fotoğrafı tamamen kaldırmak yerine küçülttü. Yer ve başlama bilgisini de fotoğrafın altına aynı boyutta yerleştirdi. Böylece görseli korurken gerekli bilgilerin bulunmasını kolaylaştırmaya çalıştılar.

Denemeye katılan kişi sayısı azdı. Ekip, herkesin yeni afişi daha iyi anlayacağını kesin olarak söylemedi. Yalnızca bu küçük grupta hangi bilginin kolay bulunduğunu not etti. Ayrıca afişin telefonda ve basılı kağıtta farklı görünebileceğini fark ettiler.

Son baskıdan önce tasarım iki ortamda da yeniden incelendi. Küçük yazılardan biri büyütüldü. Yapılan değişiklikler bir listeye işlendi; böylece sonraki etkinlik için çalışırken hangi kararın hangi gözleme dayandığı görülebilecekti.

## O4 — Bahçedeki görev paylaşımı

Okul bahçesindeki küçük alanı düzenlemek için bir öğrenci grubu toplandı. İlk gün herkes aynı anda toprağı taşımaya çalıştı. Fakat fidanların konacağı yerler henüz belirlenmemişti. Taşınan toprağın bir kısmı yeniden başka yere götürüldü. Grup, hareketli olmanın her zaman işi ilerletmek anlamına gelmediğini gördü.

İkinci gün işe başlamadan önce kısa bir sıra belirlendi. Önce alan işaretlenecek, sonra toprak hazırlanacak, en son bitkiler yerleştirilecekti. Bir öğrenci malzemeleri dağıtmayı, iki kişi de hazırlanan alanı kontrol etmeyi üstlendi. Görevler yazılı olarak panoya kondu. Böylece sonradan gelenler de neyin bittiğini ve neyin beklediğini görebildi.

Öğleden sonra sulama kabının eksik olduğu anlaşıldı. Grup programı tamamen bırakmadı; bir kişi kabı ararken diğerleri bitkilerin etrafını düzenlemeye devam etti. Ancak sulamayı yapılmış gibi işaretlemediler. Günün sonunda tamamlanan işler ile bekleyen iş ayrı yazıldı.

Ertesi gün çalışmaya gelen ekip, önce bekleyen sulamayı tamamladı. Sonra yeni yapılacaklara geçti. Bu kayıt sayesinde bir önceki günün görünürde tamamlanmış olan çalışmasının içinde eksik bir adım kaldığı açıkça görülebildi.
