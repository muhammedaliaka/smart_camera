# Gün 5 anahtarı — yalnız Gün 5 görevlerini bitirince aç

Bu anahtar **puan, yüzde, doğru/yanlış hükmü veya tanı üretmez**. Beklenen içerik bir kontrol listesidir; serbest yanıtlarda başka ifadeler de aynı noktayı taşıyabilir. İlk bağımsız yanıtın (A0) kayıtta aynen kalır; anahtara baktıktan sonra yaptığın düzeltme ayrı satırdır ve A2 olarak kodlanır. Anahtarı açınca **saatini** ve “elle” ya da “üçüncü gönderimde” diye yaz (`../kayitlar/YANIT_SABLONU.md`).

Gün 5 hafıza görevi (G05-H2-A) için **anahtar yoktur**: kontrol edilecek bilgi, `05_GUN5_GOREVLER.md` içinde gördüğün tek satırdır. Gün 12 kontrolü yapılmadan o satıra bir daha bakma; baktıysan saatini ve hangi kontrolden önce olduğunu yaz.

## G05-W1

Beklenen noktalar: kişinin tanıtılması, yaşadığı yer, bir ilgi, ortak etkinlik önerisi ve karşı tarafa soru. Örnek (kopyalamak gerekmez): **Hi, I'm Ada. I live in Türkiye. I like science and music. I want to join a study group. We can read a short article together. What do you like learning?** Daha kısa yanıt da kayıtta aynen korunur.

## G05-R1

1. Büyükannelerini ziyaret ediyorlar.
2. Büyükanne bir arkadaşında kalıyor.
3. Önce kütüphane, sonra spor merkezi.
4. İlk otobüs kütüphanenin yakınında durmuyor.
5. Kardeşi defterini unutuyor; Nora'nın defterini paylaşıyorlar.
6. Hayır; yalnız “gelecek ay” başka bir etkinlik olduğu söyleniyor.

Ana olay: iki kardeşin değişen cumartesi planı, kütüphanedeki etkinlik ve sonraki etkinlik tarihinin not edilmesi. Kapalı anlatımın bu noktaları hangi dilde içerdiği dış değerlendirici tarafından yorumlanır; anlatımın dili (İngilizce / Türkçe / karışık) kayıtta açıkça yazılır.

## G05-T1

1. Yeni insanlarla tanışmayı sevdiğim için İngilizce öğrenmek istiyorum.
2. Buluşma/toplantı okuldan sonra ama daha geç gelebilirim.
3. **I don't understand this word. Can you repeat it/that, please?** Anlamı koruyan başka ifade de olabilir.
4. **My friend isn't here today. / My friend is not here today.**

## G05-G1

Beklenen biçimler sırasıyla: **is, live, are, doesn't, were, help**. Bu liste cevap anahtarıdır; sistemin ya da raporun senin hakkında vereceği bir hüküm değildir.

## G05-H4 — duyduğun metinler

Üç deneme; her dosyada üç adım ve ardından geriye sayma yönergesi duyuldu. Hayalî adımlar şunlardı (ses, adımları bir kez söyler):

- **H4-1** (`G05_H4_1.mp3`): önce mavi kutuyu aç, sonra iki kâğıt al, en son lambayı kapat.
- **H4-2** (`G05_H4_2.mp3`): önce yeşil dosyayı al, sonra üçüncü rafa koy, en son kapıyı kontrol et.
- **H4-3** (`G05_H4_3.mp3`): önce kırmızı kalemi bul, sonra defterin ilk sayfasına yaz, en son pencereyi kapat.

Tam metin her dosyada: “Şu üç adımı aklında tut: … Şimdi sesli olarak on, dokuz, sekiz diye geriye doğru say; sayma bitince üç adımı sırayla söyle.”

Kayıtta aranan noktalar: adımların **sırası**, her adımdaki nesne ve eylem (örn. “mavi kutu”, “iki kâğıt”), sayma boyunca geçen süre (ses kaydından okunur). Eksik, yer değiştirmiş ya da yaklaşık söylenen adımlar kayıtta aynen kalır; “bilmiyorum” da geçerli bir kayıttır. Bu anahtardan puan çıkmaz ve üç deneme tek bir “bellek düzeyi” sayısına indirgenmez.
