# H6 anahtarı — yalnız Gün 8 kontrolünü (kontrol 4) yaptıktan sonra aç

Bu anahtar **puan, yüzde, doğru/yanlış hükmü veya tanı üretmez**. Beklenen içerik bir kontrol listesidir; serbest yanıtlarda başka ifadeler de aynı noktayı taşıyabilir. İlk bağımsız yanıtın (A0) kayıtta aynen kalır; anahtara baktıktan sonra yaptığın düzeltme ayrı satırdır ve A2 olarak kodlanır. Anahtarı açınca **saatini** ve “elle” ya da “üçüncü gönderimde” diye yaz (`../kayitlar/YANIT_SABLONU.md`).

Duyuru (`H6_dinleme_G03_G04_G07.mp3`), Gün 3'te bir, Gün 4'te ikinci, Gün 7'de üçüncü kez dinlendi:

> Gezi cumartesi sabahı saat dokuzda, okulun arka kapısında toplanacak. Yanına bir şapka ve kırmızı bir su şişesi al. Otobüs yeşil renkli ve numarası on iki.

Kayıtta aranan **yedi ayrıntı**: (1) gezi, (2) cumartesi sabahı, (3) saat dokuz, (4) okulun arka kapısı, (5) şapka, (6) kırmızı su şişesi, (7) yeşil otobüs, numara on iki. Yedi ayrıntı kaydı okumak için kullanılan bir listedir; bir “puan” değildir.

Kontrollerin sırası ve ne anlama geldiği (hepsi açmadan, yardımsız):

| Kontrol | Gün | Ondan önceki dinleme sayısı | Önceki dinlemeden beri |
| --- | --- | --- | --- |
| 1 | 4 | 1 | yaklaşık bir gün |
| 2 | 7 | 2 | yaklaşık üç gün |
| 3 | 7 | 3 | birkaç dakika |
| 4 | 8 | 3 | yaklaşık bir gün |

Kontrol 1 ile kontrol 4 aynı gecikmede (bir gün) ama farklı dinleme sayısındadır; bu karşılaştırma “3+ kez dinleyince kalıyor” gözlemini kendi verinde sınamak içindir. Sınırlar: her kontrol soru olarak bir hatırlama alıştırmasıdır (retrieval); yani kontrolün kendisi sonraki kontrolü kolaylaştırabilir. İçerik tek, kişi tek, hafta tektir; bu yüzden sonuç genellenemez ve hüküm çıkarılmaz.
